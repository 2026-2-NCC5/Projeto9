import React from "react";
import { ListOrdered } from "lucide-react";

interface StepsCardProps {
  steps?: string[];
}

export const StepsCard: React.FC<StepsCardProps> = ({ steps }) => {
  if (!steps || steps.length === 0) return null;

  return (
    <div className="bg-primary-50/50 border border-primary-100 rounded-xl p-3.5 mt-3 text-xs">
      <div className="flex items-center gap-2 font-semibold text-primary-900 mb-2">
        <ListOrdered className="w-4 h-4 text-primary-600" />
        <span>Passo a Passo Recomendado</span>
      </div>
      <ol className="space-y-2 list-none">
        {steps.map((step, idx) => (
          <li key={idx} className="flex gap-2.5 text-slate-700">
            <span className="flex items-center justify-center w-5 h-5 rounded-full bg-primary-500 text-white font-bold text-[10px] shrink-0 shadow-xs">
              {idx + 1}
            </span>
            <span className="pt-0.5 leading-relaxed">{step}</span>
          </li>
        ))}
      </ol>
    </div>
  );
};