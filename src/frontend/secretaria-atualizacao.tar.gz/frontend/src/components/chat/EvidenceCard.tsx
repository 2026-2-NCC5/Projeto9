import React from "react";
import { FileText } from "lucide-react";

interface EvidenceCardProps {
  source?: string;
  version?: string;
  updated_at?: string;
}

export const EvidenceCard: React.FC<EvidenceCardProps> = ({
  source = "Secretaria Acadêmica — Guia de Procedimentos",
}) => {
  return (
    <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs mt-3">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-slate-700">
          <FileText className="w-4 h-4 text-primary-500 shrink-0" />
          <span className="font-semibold text-slate-800">{source}</span>
        </div>
        <span className="text-[10px] font-medium text-slate-400 bg-white px-2 py-0.5 rounded-full border border-slate-200">
          Base Acadêmica Oficial
        </span>
      </div>
    </div>
  );
};