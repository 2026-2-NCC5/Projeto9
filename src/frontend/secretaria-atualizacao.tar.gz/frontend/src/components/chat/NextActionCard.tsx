import React from "react";
import { ArrowRightCircle } from "lucide-react";

interface NextActionCardProps {
  action?: string;
}

export const NextActionCard: React.FC<NextActionCardProps> = ({ action }) => {
  if (!action) return null;

  return (
    <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3 mt-3 text-xs">
      <div className="flex items-center gap-2 font-semibold text-amber-900 mb-1">
        <ArrowRightCircle className="w-4 h-4 text-amber-600" />
        <span>Próxima Ação</span>
      </div>
      <p className="text-amber-950 font-medium leading-relaxed pl-6">{action}</p>
    </div>
  );
};