import React from "react";
import { Bot, User, LifeBuoy, ThumbsUp, ThumbsDown, FileText } from "lucide-react";
import type { ChatMessage as ChatMessageType } from "@/types";
import { StepsCard } from "./StepsCard";
import { NextActionCard } from "./NextActionCard";
import { Button } from "@/components/ui/Button";
import { useNavigate } from "react-router-dom";

interface ChatMessageProps {
  message: ChatMessageType;
  onFeedback?: (runId: string, rating: "positive" | "negative") => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, onFeedback }) => {
  const navigate = useNavigate();
  const isUser = message.role === "user";
  const agentResponse = message.agent_response;

  return (
    <div className={`flex gap-3 my-4 ${isUser ? "flex-row-reverse" : "flex-row"}`}>
      <div
        className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 shadow-xs font-bold text-xs ${
          isUser
            ? "bg-[#004225] text-white border border-[#00E676]/30"
            : "bg-[#00E676] text-[#002B18] border border-[#00C853]/40"
        }`}
      >
        {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
      </div>

      <div className={`max-w-[88%] sm:max-w-[78%] ${isUser ? "text-right" : "text-left"}`}>
        <div
          className={`p-4 text-sm leading-relaxed ${
            isUser ? "user-bubble" : "agent-bubble"
          }`}
        >
          <p className="whitespace-pre-wrap">{message.content}</p>

          {!isUser && agentResponse && (
            <div className="mt-3.5 text-left space-y-3">
              {agentResponse.steps && agentResponse.steps.length > 0 && (
                <StepsCard steps={agentResponse.steps} />
              )}

              {agentResponse.next_action && (
                <NextActionCard action={agentResponse.next_action} />
              )}

              {agentResponse.requires_human && (
                <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-medium">
                  ⚠️ Orientação com baixa evidência oficial — recomendamos encaminhamento à Secretaria Acadêmica.
                </div>
              )}

              {/* Metadados transparentes no rodapé da resposta */}
              <div className="bg-[#F4F8F5] border border-[#E1EBE4] rounded-xl p-2.5 text-xs text-[#4A6354] flex items-center justify-between gap-2 flex-wrap mt-3">
                <div className="flex items-center gap-1.5 font-medium">
                  <FileText className="w-3.5 h-3.5 text-[#004225] shrink-0" />
                  <span>📌 <strong>Fonte:</strong> {agentResponse.source || "Secretaria Acadêmica (Base Demo)"}</span>
                </div>
                <div className="text-[11px] text-gray-500">
                  <span>Versão {agentResponse.version || "1.0-DEMO"}</span>
                  {agentResponse.confidence !== undefined && (
                    <> • <span>Confiança: {Math.round(agentResponse.confidence * 100)}%</span></>
                  )}
                </div>
              </div>

              {/* Botões de Microinteração */}
              <div className="pt-2.5 border-t border-gray-100 flex items-center justify-between text-xs text-gray-600 flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onFeedback && agentResponse.id && onFeedback(agentResponse.id, "positive")}
                    className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 transition-colors flex items-center gap-1 font-medium text-[11px] border border-emerald-200"
                    title="Foi útil"
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    <span>👍 Foi útil</span>
                  </button>
                  <button
                    onClick={() => onFeedback && agentResponse.id && onFeedback(agentResponse.id, "negative")}
                    className="px-2.5 py-1 rounded-lg bg-red-50 hover:bg-red-100 text-red-800 transition-colors flex items-center gap-1 font-medium text-[11px] border border-red-200"
                    title="Não esclareceu"
                  >
                    <ThumbsDown className="w-3.5 h-3.5" />
                    <span>👎 Não esclareceu</span>
                  </button>
                </div>

                <button
                  onClick={() => navigate("/handoff")}
                  className="px-2.5 py-1 rounded-lg bg-[#004225]/10 hover:bg-[#004225]/20 text-[#004225] font-semibold text-[11px] flex items-center gap-1 transition-colors border border-[#004225]/20"
                >
                  <LifeBuoy className="w-3.5 h-3.5 text-[#004225]" />
                  <span>💬 Solicitar Suporte Humano</span>
                </button>
              </div>
            </div>
          )}
        </div>

        <span className="text-[10px] text-gray-400 mt-1 inline-block px-1">
          {new Date(message.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </span>
      </div>
    </div>
  );
};