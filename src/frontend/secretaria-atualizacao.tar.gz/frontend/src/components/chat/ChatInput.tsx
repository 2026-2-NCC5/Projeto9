import React, { useState } from "react";
import { Send } from "lucide-react";

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading?: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading = false }) => {
  const [text, setText] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || isLoading) return;
    onSendMessage(text.trim());
    setText("");
  };

  return (
    <form onSubmit={handleSubmit} className="p-3 bg-white border-t border-[#E1EBE4] sticky bottom-0 z-30 shadow-md">
      <div className="flex items-center gap-2 max-w-md sm:max-w-2xl mx-auto">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Digite sua dúvida sobre a FECAP (rematrícula, boletos, comprovantes)..."
          className="flex-1 input-field py-3 text-sm rounded-2xl bg-[#F4F8F5] border-[#E1EBE4] focus:bg-white"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={!text.trim() || isLoading}
          className="w-11 h-11 rounded-2xl bg-[#00E676] hover:bg-[#00C853] active:bg-[#00A844] text-[#002B18] font-bold flex items-center justify-center transition-all shadow-xs disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
          title="Enviar pergunta"
        >
          {isLoading ? (
            <span className="w-5 h-5 border-2 border-[#002B18] border-t-transparent rounded-full animate-spin" />
          ) : (
            <Send className="w-5 h-5 ml-0.5" />
          )}
        </button>
      </div>
    </form>
  );
};