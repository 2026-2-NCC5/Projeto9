import React from "react";

interface FecapLogoProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

export const FecapLogo: React.FC<FecapLogoProps> = ({ size = "md", className = "" }) => {
  const sizeClasses = {
    sm: "px-2 py-0.5 text-xs rounded-md",
    md: "px-2.5 py-1 text-sm rounded-lg shadow-xs",
    lg: "px-4 py-2 text-xl rounded-xl shadow-md",
  };

  return (
    <div
      className={`bg-[#00E676] text-[#002B18] font-black italic tracking-tighter inline-flex items-center justify-center select-none shadow-xs border border-[#00C853]/40 ${sizeClasses[size]} ${className}`}
      title="FECAP — Fundação Escola de Comércio Álvares Penteado"
    >
      <span className="transform -skew-x-6 tracking-tight leading-none text-shadow-xs font-sans">
        FECAP
      </span>
    </div>
  );
};