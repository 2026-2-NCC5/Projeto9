import { useEffect, useMemo, useState } from "react";
import {
  BoletoItem,
  describeBoletoError,
  downloadBoletoPdf,
  fetchPendingBoletos,
  issueSecondCopies,
  simulatePayment,
} from "@/services/boletoService";
import { competenceMonth, formatBRL, sumSelected } from "@/services/boletoIntent";

export const BOLETO_STAMP =
  "DOCUMENTO FICTÍCIO — AMBIENTE DE DEMONSTRAÇÃO ACADÊMICA — SEM VALIDADE FINANCEIRA OU BANCÁRIA";

interface Props {
  /** Mês (1-12) a pré-selecionar (ex.: "boleto de setembro"). */
  preselectMonth?: number;
  /** Apenas para testes/pré-visualização estática: evita a chamada de rede. */
  initialBoletos?: BoletoItem[];
}

export function BoletoPicker({ preselectMonth, initialBoletos }: Props) {
  const [boletos, setBoletos] = useState<BoletoItem[] | null>(initialBoletos ?? null);
  const [loading, setLoading] = useState(!initialBoletos);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const [info, setInfo] = useState<string | null>(null);
  const [confirmSim, setConfirmSim] = useState(false);

  useEffect(() => {
    if (initialBoletos) return;
    let alive = true;
    fetchPendingBoletos()
      .then((d) => {
        if (!alive) return;
        setBoletos(d.boletos);
        if (preselectMonth) {
          const match = d.boletos.filter((b) => competenceMonth(b.competence) === preselectMonth);
          setSelected(new Set(match.map((b) => b.id)));
        }
      })
      .catch((e) => alive && setError(describeBoletoError(e)))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [initialBoletos, preselectMonth]);

  const total = useMemo(() => sumSelected(boletos ?? [], selected), [boletos, selected]);

  const toggle = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const handleIssue = async () => {
    if (selected.size === 0) return;
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      const docs = await issueSecondCopies(Array.from(selected));
      let ok = 0;
      for (const d of docs) {
        const r = await downloadBoletoPdf(d.id);
        if (!r.ok) throw new Error(r.errorMessage || "Falha ao baixar o PDF.");
        ok += 1;
      }
      setInfo(`${ok} arquivo(s) PDF baixado(s). O status financeiro não foi alterado.`);
    } catch (e) {
      setError(e instanceof Error && !("response" in e) ? e.message : describeBoletoError(e));
    } finally {
      setBusy(false);
    }
  };

  const handleSimulate = async () => {
    const id = Array.from(selected)[0];
    if (!id) return;
    setBusy(true);
    setError(null);
    try {
      setInfo(await simulatePayment(id));
      setConfirmSim(false);
    } catch (e) {
      setError(describeBoletoError(e));
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <div data-testid="boleto-loading" className="mt-3 text-xs text-slate-500" role="status">
        Consultando seus boletos de demonstração…
      </div>
    );
  }

  return (
    <div data-testid="boleto-picker" className="mt-3 w-full max-w-full bg-white border border-slate-200 rounded-xl p-3 space-y-2.5">
      <div className="text-[10px] font-bold text-red-700 leading-snug break-words">{BOLETO_STAMP}</div>

      {error && (
        <div role="alert" className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg p-2">
          {error}
        </div>
      )}

      {boletos && boletos.length === 0 && !error && (
        <div className="text-xs text-slate-700">Você não possui boletos pendentes na sua conta de demonstração.</div>
      )}

      {boletos && boletos.length > 0 && (
        <ul className="space-y-2" aria-label="Boletos pendentes">
          {boletos.map((b) => (
            <li key={b.id}>
              <label className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 p-2.5 min-h-[44px] rounded-lg border border-slate-200 hover:bg-emerald-50 cursor-pointer text-xs">
                <span className="flex items-center gap-2 sm:w-auto">
                  <input
                    type="checkbox"
                    className="w-5 h-5 accent-[#059669] shrink-0"
                    checked={selected.has(b.id)}
                    onChange={() => toggle(b.id)}
                    aria-label={`Selecionar boleto ${b.competence_label}`}
                  />
                  <strong className="text-slate-900">{b.competence_label}</strong>
                </span>
                <span className="text-slate-600 sm:flex-1">Venc. {b.due_date}</span>
                <span className="font-bold text-slate-900">{b.amount_label}</span>
                <span
                  className={`inline-block self-start sm:self-auto px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    b.status === "vencido" ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"
                  }`}
                >
                  {b.status_label}
                </span>
              </label>
            </li>
          ))}
        </ul>
      )}

      {boletos && boletos.length > 0 && (
        <>
          <div className="flex items-center justify-between text-xs font-bold text-slate-800" data-testid="boleto-total">
            <span>
              {selected.size} selecionado(s)
            </span>
            <span>Total: {formatBRL(total)}</span>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              disabled={selected.size === 0 || busy}
              onClick={handleIssue}
              className="min-h-[44px] sm:min-h-0 bg-[#059669] hover:bg-[#004D34] disabled:opacity-50 text-white text-xs font-bold px-3 py-2 rounded-lg"
            >
              {busy ? "Processando…" : "Emitir segunda via"}
            </button>
            <button
              type="button"
              disabled={selected.size === 0 || busy}
              onClick={() => setSelected(new Set())}
              className="min-h-[44px] sm:min-h-0 border border-slate-300 text-slate-700 text-xs font-bold px-3 py-2 rounded-lg disabled:opacity-50"
            >
              Limpar seleção
            </button>
            <button
              type="button"
              disabled={selected.size !== 1 || busy}
              onClick={() => setConfirmSim(true)}
              className="min-h-[44px] sm:min-h-0 border border-amber-300 text-amber-800 text-xs font-bold px-3 py-2 rounded-lg disabled:opacity-50"
              title="Selecione um único boleto para simular"
            >
              Simular pagamento
            </button>
          </div>

          {confirmSim && (
            <div role="dialog" aria-label="Confirmar simulação" className="text-xs bg-amber-50 border border-amber-200 rounded-lg p-2.5 space-y-2">
              <p>
                Isto é apenas uma <strong>simulação</strong>: nenhuma transação financeira será executada e a situação
                do boleto não será alterada.
              </p>
              <div className="flex gap-2">
                <button type="button" onClick={handleSimulate} disabled={busy} className="bg-amber-600 text-white font-bold px-3 py-1.5 rounded-lg">
                  Confirmar simulação
                </button>
                <button type="button" onClick={() => setConfirmSim(false)} className="border border-slate-300 px-3 py-1.5 rounded-lg">
                  Cancelar
                </button>
              </div>
            </div>
          )}
        </>
      )}

      {info && (
        <div role="status" className="text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg p-2">
          {info}
        </div>
      )}
    </div>
  );
}
