import { describe, it, expect } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { BoletoPicker, BOLETO_STAMP } from "./BoletoPicker";
import type { BoletoItem } from "@/services/boletoService";

const mk = (id: string, comp: string, status: "vencido" | "pendente"): BoletoItem => ({
  id,
  competence: comp,
  competence_label: comp,
  due_date: "10/09/2026",
  amount_cents: 85000,
  amount_label: "R$ 850,00",
  status,
  status_label: status === "vencido" ? "Vencido" : "A vencer",
  document_id: `BOL-${id}`,
});

describe("BoletoPicker (renderização estática, layout móvel)", () => {
  const html = renderToStaticMarkup(
    <BoletoPicker initialBoletos={[mk("1", "2026-08", "vencido"), mk("2", "2026-09", "vencido")]} />
  );

  it("mostra aviso fictício, checkboxes e botões exigidos", () => {
    expect(html).toContain(BOLETO_STAMP);
    expect((html.match(/type="checkbox"/g) || []).length).toBe(2);
    expect(html).toContain("Emitir segunda via");
    expect(html).toContain("Limpar seleção");
    expect(html).toContain("Simular pagamento");
    expect(html).toContain("Total: R$ 0,00");
  });

  it("usa layout responsivo: empilha no celular e alvos de toque >= 44px", () => {
    expect(html).toContain("flex-col sm:flex-row");
    expect(html).toContain("min-h-[44px]");
    expect(html).toContain("max-w-full");
    expect(html).toContain("break-words");
  });

  it("estado vazio mostra mensagem sem botões de emissão", () => {
    const empty = renderToStaticMarkup(<BoletoPicker initialBoletos={[]} />);
    expect(empty).toContain("não possui boletos pendentes");
    expect(empty).not.toContain("Emitir segunda via");
  });
});
