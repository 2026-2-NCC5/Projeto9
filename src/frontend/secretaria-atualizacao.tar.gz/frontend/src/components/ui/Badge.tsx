import React from "react";

interface BadgeProps {
  children: React.ReactNode;
  variant?: "primary" | "accent" | "success" | "warning" | "danger" | "gray";
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ children, variant = "primary", className = "" }) => {
  const variants = {
    primary: "bg-primary-50 text-primary-700 border-primary-200 font-medium",
    accent: "bg-amber-50 text-amber-800 border-amber-300 font-semibold",
    success: "bg-emerald-50 text-emerald-700 border-emerald-200 font-medium",
    warning: "bg-amber-50 text-amber-800 border-amber-200 font-medium",
    danger: "bg-red-50 text-red-700 border-red-200 font-medium",
    gray: "bg-gray-100 text-gray-700 border-gray-200 font-medium",
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs border ${variants[variant]} ${className}`}>
      {children}
    </span>
  );
};