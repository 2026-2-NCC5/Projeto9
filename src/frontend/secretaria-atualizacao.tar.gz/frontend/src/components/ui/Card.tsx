import React from "react";

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export const Card: React.FC<CardProps> = ({ children, className = "", onClick }) => {
  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-2xl shadow-xs border border-gray-100 p-4 transition-all ${
        onClick ? "cursor-pointer hover:shadow-md hover:border-gray-200" : ""
      } ${className}`}
    >
      {children}
    </div>
  );
};