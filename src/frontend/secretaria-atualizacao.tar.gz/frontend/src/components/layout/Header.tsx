import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { User, LogOut, ArrowLeft, HelpCircle } from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { FecapLogo } from "@/components/common/FecapLogo";

export const Header: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, profile, logout } = useAuthStore();

  const isHome = location.pathname === "/home";
  const isAuthPage = ["/login", "/forgot-password", "/splash", "/admin/login"].includes(location.pathname);

  if (isAuthPage) return null;

  const isAdmin = user?.role === "admin";

  return (
    <header className="bg-[#004225] text-white sticky top-0 z-40 shadow-md border-b border-[#00361E]">
      <div className="max-w-md md:max-w-5xl mx-auto px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {!isHome && (
            <button
              onClick={() => navigate(-1)}
              className="p-1.5 rounded-lg hover:bg-[#00361E] transition-colors text-white/90"
              aria-label="Voltar"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div
            onClick={() => navigate(isAdmin ? "/admin/dashboard" : "/home")}
            className="flex items-center gap-2.5 cursor-pointer select-none"
          >
            <FecapLogo size="md" />
            <div className="hidden xs:block sm:block">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-sm tracking-tight text-white leading-none">FECAP Guia</span>
                <span className="text-[10px] text-[#00E676] font-medium leading-none">• Orientação Acadêmica</span>
              </div>
              <div className="flex items-center gap-1 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00E676] animate-pulse" />
                <span className="text-[9px] text-emerald-200 font-medium leading-none">IA On-line • Base Oficial</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!isAdmin && (
            <button
              onClick={() => navigate("/help")}
              className="p-2 rounded-lg hover:bg-[#00361E] text-emerald-100 hover:text-white transition-colors"
              title="Ajuda e Informações"
              aria-label="Ajuda"
            >
              <HelpCircle className="w-5 h-5" />
            </button>
          )}
          <button
            onClick={() => navigate(isAdmin ? "/admin/dashboard" : "/profile")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:bg-[#00361E] transition-colors text-xs font-semibold bg-[#002B18]/60 border border-emerald-500/20 text-white"
          >
            <User className="w-3.5 h-3.5 text-[#00E676]" />
            <span className="hidden sm:inline">{profile?.name.split(" ")[0] || (isAdmin ? "Admin" : "Perfil")}</span>
          </button>
          <button
            onClick={() => {
              logout();
              navigate("/login");
            }}
            className="p-2 rounded-lg hover:bg-red-600/80 text-white/80 hover:text-white transition-colors"
            title="Sair"
            aria-label="Sair"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};