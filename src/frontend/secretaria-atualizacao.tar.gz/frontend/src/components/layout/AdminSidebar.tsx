import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { LayoutDashboard, BookOpen, MessageSquareX, ThumbsUp, LifeBuoy, FileText, ArrowLeft } from "lucide-react";

export const AdminSidebar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { path: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { path: "/admin/knowledge", label: "Base de Conhecimento", icon: BookOpen },
    { path: "/admin/unanswered", label: "Perguntas sem Resposta", icon: MessageSquareX },
    { path: "/admin/feedbacks", label: "Feedbacks", icon: ThumbsUp },
    { path: "/admin/handoffs", label: "Encaminhamentos", icon: LifeBuoy },
    { path: "/admin/audit", label: "Auditoria", icon: FileText },
  ];

  return (
    <aside className="w-full md:w-64 bg-primary-900 text-white flex-shrink-0 p-4 border-b md:border-b-0 md:border-r border-primary-800">
      <div className="flex items-center justify-between mb-6 px-2">
        <h2 className="text-xs font-semibold tracking-wider text-accent uppercase">Área Administrativa</h2>
        <button
          onClick={() => navigate("/home")}
          className="text-xs flex items-center gap-1 text-primary-200 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" /> Visão Estudante
        </button>
      </div>
      <nav className="flex flex-row md:flex-col gap-1 overflow-x-auto pb-2 md:pb-0">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs md:text-sm font-medium whitespace-nowrap transition-colors ${
                isActive
                  ? "bg-primary-500 text-white shadow-sm font-semibold"
                  : "text-primary-200 hover:bg-primary-800 hover:text-white"
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
    </aside>
  );
};