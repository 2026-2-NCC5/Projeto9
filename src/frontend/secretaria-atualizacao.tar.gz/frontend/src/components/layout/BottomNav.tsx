import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Home, MessageSquare, History, User } from "lucide-react";
import { useAuthStore } from "@/store/authStore";

export const BottomNav: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuthStore();

  const isAuthPage = ["/login", "/forgot-password", "/splash", "/admin/login"].includes(location.pathname);
  const isAdmin = user?.role === "admin" || location.pathname.startsWith("/admin");

  if (isAuthPage || isAdmin) return null;

  const items = [
    { path: "/home", label: "Início", icon: Home },
    { path: "/chat", label: "Perguntar", icon: MessageSquare },
    { path: "/history", label: "Histórico", icon: History },
    { path: "/profile", label: "Perfil", icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40 md:hidden shadow-lg">
      <div className="max-w-md mx-auto grid grid-cols-4 h-16">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path || (item.path === "/chat" && location.pathname.startsWith("/chat"));
          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center justify-center gap-1 transition-colors ${
                isActive ? "text-primary-500 font-semibold" : "text-gray-500 hover:text-gray-700"
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? "scale-110" : ""} transition-transform`} />
              <span className="text-[11px]">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};