/**
 * Tipos TypeScript Centrais — FECAP Guia
 * Agente Inteligente de Orientação ao Estudante
 */

// ----- Auth -----
export interface User {
  id: string;
  email: string;
  role: "student" | "admin";
}

export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: string;
  user: User;
}

// ----- Estudante -----
export interface StudentProfile {
  id: string;
  name: string;
  ra: string;
  course: string;
  period: string;
  email: string;
}

// ----- Agente -----
export interface AgentEvidence {
  chunk: string;
  document: string;
  relevance_score?: number;
}

export interface AgentResponse {
  id?: string;
  conversation_id?: string;
  answer: string;
  steps?: string[];
  next_action?: string;
  source?: string;
  version?: string;
  updated_at?: string;
  evidence?: AgentEvidence[];
  confidence?: number;
  requires_human?: boolean;
}

export interface AgentQuery {
  question: string;
  student_id?: string;
  conversation_id?: string;
}

// ----- Chat -----
export type MessageRole = "user" | "assistant" | "system";

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  created_at: string;
  agent_response?: AgentResponse;
  requires_human?: boolean;
}

export interface Conversation {
  id: string;
  title?: string;
  created_at?: string;
  updated_at?: string;
  started_at?: string;
  messages: ChatMessage[];
}


// ----- Histórico -----
export interface HistoryItem {
  id: string;
  question: string;
  answer: string;
  requires_human: boolean;
  created_at: string;
  feedback?: "positive" | "negative";
  handoff_protocol?: string;
}

// ----- Feedback -----
export type FeedbackRating = "positive" | "negative";

export interface FeedbackPayload {
  agent_run_id: string;
  rating: FeedbackRating;
  comment?: string;
}

export interface FeedbackItem {
  id: string;
  message_id?: string;
  user_id?: string;
  rating: string;
  rating_value?: number;
  comment?: string;
  question_context?: string;
  answer_context?: string;
  needs_review?: boolean;
  created_at: string;
}

// ----- Encaminhamento Humano -----
export type HandoffPriority = "normal" | "priority" | "urgent";
export type HandoffCategory =
  | "academico"
  | "financeiro"
  | "documentos"
  | "portal"
  | "outro";

export interface HandoffPayload {
  conversation_id: string;
  reason: string;
  category: HandoffCategory;
  priority: HandoffPriority;
  summary?: string;
}

export interface HandoffResult {
  protocol: string;
  status: string;
  message?: string;
}

export interface HandoffAdminItem {
  id: string;
  protocol: string;
  conversation_id?: string;
  user_id?: string;
  category: string;
  priority: string;
  reason: string;
  summary?: string;
  status: string;
  attendant?: string;
  created_at: string;
  updated_at: string;
}

// ----- Validação Humana (RF08) e Abstenções -----
export type ValidationDecision = "confirm" | "adjust" | "reject" | "complement";

export interface HumanValidationPayload {
  message_id: string;
  decision: ValidationDecision;
  justification?: string;
  adjusted_answer?: string;
  classification?: string;
  response_version?: string;
}

export interface HumanValidationResponse {
  id: string;
  message_id: string;
  reviewer_id: string;
  decision: ValidationDecision;
  justification?: string;
  adjusted_answer?: string;
  classification?: string;
  response_version: string;
  created_at: string;
}

export interface UnansweredQuestionItem {
  message_id: string;
  conversation_id: string;
  question: string;
  agent_answer: string;
  confidence: number;
  created_at: string;
  validation_status: "pending" | "reviewed";
  validation_decision?: ValidationDecision;
  classification?: string;
  justification?: string;
}

// ----- Base de Conhecimento -----
export type DocumentCategory =
  | "portal_sistemas"
  | "documentos_certidoes"
  | "atendimento_suporte"
  | "procedimentos"
  | "faq"
  | "financeiro"
  | "biblioteca"
  | "estagios";

export type DocumentStatus = "active" | "inactive" | "draft";

export interface KnowledgeDocument {
  id: string;
  title: string;
  category: DocumentCategory | string;
  origin: string;
  version: string;
  status: DocumentStatus;
  chunks_count?: number;
  published_at: string;
  updated_at: string;
  created_by?: string;
}

export interface KnowledgeDocumentDetail extends KnowledgeDocument {
  content: string;
  chunks_count: number;
}

// ----- Dashboard Admin -----
export interface DashboardMetrics {
  total_questions: number;
  total_answers: number;
  answers_with_evidence_rate: number;
  positive_feedback_rate: number;
  handoffs_count: number;
  unanswered_count: number;
  avg_response_time_ms: number;
  active_documents_count?: number;
  validations_count?: number;
  top_categories: Array<{ category: string; count: number }>;
  questions_per_day: Array<{ date: string; count: number }>;
}

// ----- Auditoria -----
export interface AuditLog {
  id: string;
  user_id: string;
  action: string;
  resource: string;
  detail: string;
  created_at: string;
}