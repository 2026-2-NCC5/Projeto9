/**
 * FECAP Guia — Design System & Design Tokens
 * Identidade Visual Oficial FECAP
 */

export const theme = {
  colors: {
    brandGreen: "#00E676",      // Verde vibrante oficial do fundo da logo
    darkGreen: "#002B18",       // Tom escuro da tipografia "FECAP"
    primary: "#004225",         // Verde institucional para cabeçalhos e navegação
    primaryHover: "#00331D",
    background: "#F4F8F5",      // Fundo geral suave
    surface: "#FFFFFF",         // Cards limpos com cantos arredondados
    textPrimary: "#0B2513",     // Texto escuro de alto contraste
    textSecondary: "#4A6354",   // Texto de suporte
    border: "#E1EBE4",          // Bordas suaves
    userBubbleGradient: "linear-gradient(135deg, #004225 0%, #002B18 100%)",
    agentBubble: "#FFFFFF",
    accentGold: "#C8A951",      // Destaque secundário
  },
  borderRadius: {
    card: "16px",
    bubble: "18px",
    button: "12px",
  },
};

export default theme;