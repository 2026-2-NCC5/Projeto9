/**
 * Store de autenticacao (Zustand).
 * Gerencia estado e sessao do usuario logado.
 */
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { User, StudentProfile } from "@/types";

interface AuthState {
  user: User | null;
  profile: StudentProfile | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  setAuth: (user: User, accessToken: string, refreshToken?: string) => void;
  setProfile: (profile: StudentProfile) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      profile: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,

      setAuth: (user, accessToken, refreshToken) => {
        localStorage.setItem("access_token", accessToken);
        if (refreshToken) {
          localStorage.setItem("refresh_token", refreshToken);
        }
        set({ user, accessToken, refreshToken: refreshToken || null, isAuthenticated: true });
      },

      setProfile: (profile) => set({ profile }),

      logout: () => {
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        set({
          user: null,
          profile: null,
          accessToken: null,
          refreshToken: null,
          isAuthenticated: false,
        });
      },
    }),
    { name: "fecap-guia-auth" }
  )
);
