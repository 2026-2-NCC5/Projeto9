﻿/**
 * Store de chat (Zustand).
 * Gerencia mensagens da conversa atual.
 */
import { create } from "zustand";
import type { ChatMessage } from "@/types";

interface ChatState {
  messages: ChatMessage[];
  conversationId: string | null;
  isLoading: boolean;
  addMessage: (message: ChatMessage) => void;
  setLoading: (loading: boolean) => void;
  clearChat: () => void;
  setConversationId: (id: string) => void;
}

export const useChatStore = create<ChatState>()((set) => ({
  messages: [],
  conversationId: null,
  isLoading: false,

  addMessage: (message) =>
    set((state) => ({ messages: [...state.messages, message] })),

  setLoading: (isLoading) => set({ isLoading }),

  clearChat: () => set({ messages: [], conversationId: null }),

  setConversationId: (conversationId) => set({ conversationId }),
}));
