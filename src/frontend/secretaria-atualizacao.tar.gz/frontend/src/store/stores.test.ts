import { describe, it, expect, beforeEach } from "vitest";

const store: Record<string, string> = {};
const mockLocalStorage = {
  getItem: (key: string) => store[key] || null,
  setItem: (key: string, value: string) => {
    store[key] = value.toString();
  },
  removeItem: (key: string) => {
    delete store[key];
  },
  clear: () => {
    for (const key in store) {
      delete store[key];
    }
  },
};

Object.defineProperty(globalThis, "localStorage", {
  value: mockLocalStorage,
  writable: true,
  configurable: true,
});

import { useAuthStore } from "./authStore";
import { useChatStore } from "./chatStore";

describe("Frontend Stores Integration", () => {
  beforeEach(() => {
    globalThis.localStorage.clear();
    useAuthStore.getState().logout();
    useChatStore.getState().clearChat();
  });


  it("authStore armazena usuario, tokens e persiste sessao", () => {
    const user = {
      id: "std-001",
      email: "estudante@demo.fecap.br",
      role: "student" as const,
    };

    useAuthStore.getState().setAuth(user, "access-token-123", "refresh-token-456");

    const state = useAuthStore.getState();
    expect(state.isAuthenticated).toBe(true);
    expect(state.user?.email).toBe("estudante@demo.fecap.br");
    expect(state.accessToken).toBe("access-token-123");
    expect(state.refreshToken).toBe("refresh-token-456");
    expect(localStorage.getItem("access_token")).toBe("access-token-123");
    expect(localStorage.getItem("refresh_token")).toBe("refresh-token-456");
  });

  it("authStore logout limpa tokens e sessao", () => {
    const user = {
      id: "std-001",
      email: "estudante@demo.fecap.br",
      role: "student" as const,
    };

    useAuthStore.getState().setAuth(user, "access-token-123", "refresh-token-456");
    useAuthStore.getState().logout();

    const state = useAuthStore.getState();
    expect(state.isAuthenticated).toBe(false);
    expect(state.user).toBeNull();
    expect(localStorage.getItem("access_token")).toBeNull();
    expect(localStorage.getItem("refresh_token")).toBeNull();
  });

  it("chatStore gerencia mensagens e conversationId do RAG", () => {
    useChatStore.getState().setConversationId("conv-123");
    expect(useChatStore.getState().conversationId).toBe("conv-123");

    useChatStore.getState().addMessage({
      id: "msg-1",
      role: "user",
      content: "Como solicitar declaracao?",
      created_at: new Date().toISOString(),
    });

    useChatStore.getState().addMessage({
      id: "msg-2",
      role: "assistant",
      content: "Para solicitar declaracao acesse o portal.",
      created_at: new Date().toISOString(),
      agent_response: {
        id: "msg-2",
        answer: "Para solicitar declaracao acesse o portal.",
        confidence: 0.82,
        requires_human: false,
      },
    });

    const msgs = useChatStore.getState().messages;
    expect(msgs.length).toBe(2);
    expect(msgs[0].role).toBe("user");
    expect(msgs[1].agent_response?.confidence).toBe(0.82);

    useChatStore.getState().clearChat();
    expect(useChatStore.getState().messages.length).toBe(0);
    expect(useChatStore.getState().conversationId).toBeNull();
  });

  it("authStore suporta perfil administrador (RBAC) e preserva role admin", () => {
    const adminUser = {
      id: "adm-001",
      email: "admin@demo.fecap.br",
      role: "admin" as const,
    };

    useAuthStore.getState().setAuth(adminUser, "admin-access-789", "admin-refresh-999");

    const state = useAuthStore.getState();
    expect(state.isAuthenticated).toBe(true);
    expect(state.user?.role).toBe("admin");
    expect(localStorage.getItem("access_token")).toBe("admin-access-789");
  });
});

