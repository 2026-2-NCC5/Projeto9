import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { LogIn, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { useAuthStore } from "@/store/authStore";
import { api } from "@/services/api";
import { FecapLogo } from "@/components/common/FecapLogo";
import type { AuthTokens, StudentProfile } from "@/types";

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { setAuth, setProfile } = useAuthStore();

  const [email, setEmail] = useState("estudante@demo.fecap.br");
  const [password, setPassword] = useState("demo1234");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email || !password) {
      setError("Preencha todos os campos.");
      return;
    }

    setIsLoading(true);

    try {
      const response = await api.post<AuthTokens>("/auth/login", {
        email,
        password,
      });

      const { user, access_token, refresh_token } = response.data;
      setAuth(user, access_token, refresh_token);

      if (user.role === "admin") {
        navigate("/admin/dashboard");
      } else {
        // Carrega os dados reais do estudante autenticado
        try {
          const profileRes = await api.get<StudentProfile>("/student/profile");
          setProfile(profileRes.data);
        } catch {
          // Se perfil nao estiver vinculado de imediato, prossegue normalmente
        }
        navigate("/home");
      }
    } catch (err: any) {
      const msg =
        err.response?.data?.detail || "Erro ao conectar com o servidor. Verifique suas credenciais.";
      setError(typeof msg === "string" ? msg : "Credenciais inválidas.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F8F5] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="mb-4">
          <FecapLogo size="lg" />
        </div>
        <h1 className="text-2xl font-extrabold text-[#0B2513] tracking-tight">FECAP Guia</h1>
        <p className="mt-1 text-xs text-[#4A6354] font-medium">Orientação Acadêmica Inteligente ao Estudante</p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 shadow-xs border border-[#E1EBE4] rounded-[16px] sm:px-10">
          <form className="space-y-4" onSubmit={handleLogin}>
            {error && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <Input
              label="E-mail Institucional"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="ex: estudante@demo.fecap.br"
              required
            />

            <Input
              label="Senha"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />

            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Portal Acadêmico</span>
              <Link to="/forgot-password" className="font-semibold text-[#004225] hover:underline">
                Esqueci minha senha
              </Link>
            </div>

            <Button type="submit" className="w-full btn-primary" isLoading={isLoading}>
              <LogIn className="w-4 h-4 mr-1" /> Entrar no Portal
            </Button>
          </form>

          <div className="mt-6 pt-4 border-t border-[#E1EBE4] text-center">
            <button
              type="button"
              onClick={() => {
                setEmail("admin@demo.fecap.br");
                setPassword("admin1234");
              }}
              className="text-xs text-[#4A6354] hover:text-[#004225] font-semibold transition-colors"
            >
              Preencher com credenciais do Administrador
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};