import React, { useEffect, useState } from "react";
import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";
import { useAuthStore } from "@/store/authStore";
import { ShieldCheck, LogOut, RefreshCw, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { useNavigate } from "react-router-dom";
import { api } from "@/services/api";
import type { StudentProfile } from "@/types";

export const ProfilePage: React.FC = () => {
  const { profile, setProfile, logout, user } = useAuthStore();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const fetchProfile = async () => {
    setIsLoading(true);
    setError("");
    try {
      const res = await api.get<StudentProfile>("/student/profile");
      setProfile(res.data);
    } catch (err: any) {
      setError("Não foi possível carregar os dados cadastrais.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-20 md:pb-6">
      <Header />

      <main className="flex-1 max-w-md sm:max-w-xl mx-auto w-full px-4 pt-6 space-y-5">
        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center justify-between text-xs text-red-700">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
            <button onClick={fetchProfile} className="text-primary-700 font-semibold flex items-center gap-1 hover:underline">
              <RefreshCw className="w-3 h-3" /> Tentar novamente
            </button>
          </div>
        )}

        <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs text-center space-y-3">
          <div className="w-20 h-20 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center mx-auto text-2xl font-bold shadow-xs">
            {profile?.name ? profile.name.charAt(0) : user?.email?.charAt(0).toUpperCase() || "E"}
          </div>
          <h1 className="text-lg font-bold text-gray-900">
            {isLoading ? "Carregando perfil..." : profile?.name || "Estudante FECAP"}
          </h1>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary-50 text-primary-700 border border-primary-200 text-xs font-semibold">
            {user?.role === "admin" ? "ADMINISTRADOR" : "ESTUDANTE REGULAR"}
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Dados Acadêmicos Reais</h2>
            {isLoading && <RefreshCw className="w-3.5 h-3.5 animate-spin text-gray-400" />}
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-gray-400 block mb-0.5">RA</span>
              <strong className="text-gray-800 text-sm">{profile?.ra || "—"}</strong>
            </div>
            <div>
              <span className="text-gray-400 block mb-0.5">Curso</span>
              <strong className="text-gray-800 text-sm">{profile?.course || "—"}</strong>
            </div>
            <div>
              <span className="text-gray-400 block mb-0.5">Período</span>
              <strong className="text-gray-800 text-sm">{profile?.period || "—"}</strong>
            </div>
            <div>
              <span className="text-gray-400 block mb-0.5">E-mail Institucional</span>
              <strong className="text-gray-800 text-xs truncate block">{profile?.email || user?.email || "—"}</strong>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-3 text-xs">
          <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Privacidade e Proteção de Dados</h2>
          <div className="flex items-center gap-2.5 text-slate-700">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>Dados protegidos pelo backend e associados com segurança ao seu cadastro.</span>
          </div>
        </div>

        <Button
          variant="outline"
          className="w-full text-red-600 border-red-200 hover:bg-red-50"
          onClick={() => {
            logout();
            navigate("/login");
          }}
        >
          <LogOut className="w-4 h-4 mr-1" /> Sair da Conta
        </Button>
      </main>

      <BottomNav />
    </div>
  );
};