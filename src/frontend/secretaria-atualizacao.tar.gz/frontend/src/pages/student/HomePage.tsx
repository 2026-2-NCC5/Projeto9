import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Sparkles, ChevronRight, FileText, CreditCard, Calendar, UserCheck } from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { api } from "@/services/api";
import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";
import type { StudentProfile } from "@/types";

export const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { profile, setProfile, isAuthenticated, user } = useAuthStore();
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (isAuthenticated && user?.role === "student" && !profile) {
      api
        .get<StudentProfile>("/student/profile")
        .then((res) => setProfile(res.data))
        .catch(() => {});
    }
  }, [isAuthenticated, user, profile, setProfile]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    navigate(`/chat?q=${encodeURIComponent(searchQuery.trim())}`);
  };

  const quickActionChips = [
    { title: "Emitir Comprovante de Matrícula", query: "Como solicitar declaração de matrícula?", icon: FileText, badge: "📄" },
    { title: "2ª Via de Boleto / Rematrícula", query: "Dúvidas sobre o financeiro e boletos?", icon: CreditCard, badge: "💳" },
    { title: "Prazos de Trancamento e Atividades", query: "Como consultar o calendário acadêmico?", icon: Calendar, badge: "📅" },
    { title: "Falar com Atendimento Humano", query: "handoff", icon: UserCheck, badge: "👨💼" },
  ];

  const faqs = [
    "Como emitir o comprovante de matrícula oficial?",
    "Como acessar as ferramentas do Portal do Aluno?",
    "Quais são os prazos para requisições e secretaria?",
    "Como consultar notas e faltas das disciplinas?",
  ];

  return (
    <div className="min-h-screen bg-[#F4F8F5] flex flex-col pb-20 md:pb-6">
      <Header />

      <main className="flex-1 max-w-md sm:max-w-xl mx-auto w-full px-4 pt-5 space-y-5">
        {/* Hero Section */}
        <div className="bg-gradient-to-br from-[#004225] via-[#00361E] to-[#002B18] text-white rounded-2xl p-5 shadow-md relative overflow-hidden border border-[#004225]">
          <div className="relative z-10">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-[#00E676] text-[#002B18] mb-3 shadow-xs">
              <Sparkles className="w-3.5 h-3.5" /> Orientação Acadêmica FECAP
            </span>
            <h1 className="text-xl font-bold tracking-tight text-white leading-tight">
              Olá, {profile?.name ? profile.name.split(" ")[0] : "Estudante"}! Como posso te ajudar hoje na FECAP? 👋
            </h1>
            <p className="text-xs text-emerald-100/90 mt-1.5 max-w-xs leading-relaxed">
              Tire dúvidas sobre matrículas, boletos, prazos acadêmicos e requerimentos.
            </p>
          </div>
        </div>

        {/* Campo de Busca Principal */}
        <form onSubmit={handleSearchSubmit} className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Digite sua dúvida (ex: matrícula, boleto, prazos)..."
            className="w-full pl-11 pr-24 py-3.5 bg-white rounded-2xl border border-[#E1EBE4] shadow-xs text-sm focus:outline-none focus:border-[#004225] focus:ring-2 focus:ring-[#00E676]/30 transition-all placeholder:text-gray-400"
          />
          <Search className="w-5 h-5 text-[#004225] absolute left-4 top-1/2 -translate-y-1/2" />
          <button
            type="submit"
            className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-2 bg-[#00E676] hover:bg-[#00C853] text-[#002B18] text-xs font-bold rounded-xl transition-all shadow-xs"
          >
            Perguntar
          </button>
        </form>

        {/* Carrossel de Atalhos Rápidos (Quick Action Chips) */}
        <section className="space-y-2">
          <h2 className="text-xs font-bold text-[#004225] tracking-wider uppercase px-1">Atalhos Rápidos</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {quickActionChips.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => {
                  if (chip.query === "handoff") {
                    navigate("/handoff");
                  } else {
                    navigate(`/chat?q=${encodeURIComponent(chip.query)}`);
                  }
                }}
                className="bg-white p-3.5 rounded-2xl border border-[#E1EBE4] shadow-xs flex items-center gap-3 text-left hover:border-[#00E676] hover:shadow-md transition-all active:scale-[0.98]"
              >
                <div className="w-10 h-10 rounded-xl bg-[#F4F8F5] flex items-center justify-center text-lg shrink-0 border border-[#E1EBE4]">
                  {chip.badge}
                </div>
                <div>
                  <h3 className="text-xs font-bold text-[#0B2513] leading-snug">{chip.title}</h3>
                  <span className="text-[10px] text-[#4A6354] font-medium">Toque para consultar</span>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Perguntas Frequentes */}
        <section className="space-y-2">
          <h2 className="text-xs font-bold text-[#004225] tracking-wider uppercase px-1">Dúvidas Mais Frequentes</h2>
          <div className="bg-white rounded-2xl border border-[#E1EBE4] shadow-xs divide-y divide-[#E1EBE4] overflow-hidden">
            {faqs.map((faq, idx) => (
              <button
                key={idx}
                onClick={() => navigate(`/chat?q=${encodeURIComponent(faq)}`)}
                className="w-full px-4 py-3.5 text-left flex items-center justify-between text-xs text-[#0B2513] hover:bg-[#F4F8F5] transition-colors font-medium"
              >
                <span>{faq}</span>
                <ChevronRight className="w-4 h-4 text-[#004225] shrink-0" />
              </button>
            ))}
          </div>
        </section>
      </main>

      <BottomNav />
    </div>
  );
};