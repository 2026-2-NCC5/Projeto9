import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";
import { Badge } from "@/components/ui/Badge";
import { History, LifeBuoy, RefreshCw, MessageSquare, ChevronRight, AlertCircle } from "lucide-react";
import { api } from "@/services/api";
import { useChatStore } from "@/store/chatStore";
import type { Conversation, ChatMessage } from "@/types";

export const HistoryPage: React.FC = () => {
  const navigate = useNavigate();
  const { setConversationId, addMessage, clearChat } = useChatStore();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchConversations = async () => {
    setIsLoading(true);
    setError("");
    try {
      const res = await api.get<Conversation[]>("/history/");
      setConversations(res.data);
    } catch (err: any) {
      setError("Não foi possível carregar o histórico de atendimentos.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchConversations();
  }, []);

  const handleOpenConversation = async (convId: string) => {
    try {
      const res = await api.get<Conversation>(`/history/${convId}`);
      const conv = res.data;
      clearChat();
      setConversationId(conv.id);

      // Carregar as mensagens na tela de chat
      conv.messages.forEach((msg: any) => {
        const chatMsg: ChatMessage = {
          id: msg.id,
          role: msg.role,
          content: msg.content,
          created_at: msg.created_at,
          agent_response:
            msg.role === "assistant"
              ? {
                  id: msg.id,
                  answer: msg.content,
                  steps: msg.steps,
                  next_action: msg.next_action,
                  source: msg.source,
                  version: msg.document_version,
                  evidence: msg.evidence,
                  confidence: msg.confidence,
                  requires_human: msg.requires_human,
                }
              : undefined,
        };
        addMessage(chatMsg);
      });

      navigate("/chat");
    } catch {
      // Se falhar o carregamento da conversa especifica, navega normalmente
      navigate("/chat");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-20 md:pb-6">
      <Header />

      <main className="flex-1 max-w-md sm:max-w-xl mx-auto w-full px-4 pt-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-primary-500" />
            <h1 className="text-base font-bold text-gray-900">Histórico de Atendimentos</h1>
          </div>
          <span className="text-xs text-gray-500">
            {isLoading ? "Carregando..." : `${conversations.length} conversas`}
          </span>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center justify-between text-xs text-red-700">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
            <button onClick={fetchConversations} className="text-primary-700 font-semibold flex items-center gap-1 hover:underline">
              <RefreshCw className="w-3 h-3" /> Tentar novamente
            </button>
          </div>
        )}

        {isLoading ? (
          <div className="py-12 text-center text-xs text-gray-500 flex flex-col items-center justify-center gap-2">
            <RefreshCw className="w-6 h-6 animate-spin text-primary-600" />
            <span>Consultando atendimentos no servidor...</span>
          </div>
        ) : conversations.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 border border-gray-100 shadow-xs text-center space-y-3">
            <MessageSquare className="w-10 h-10 text-gray-300 mx-auto" />
            <h2 className="text-sm font-semibold text-gray-700">Nenhum atendimento registrado</h2>
            <p className="text-xs text-gray-400 max-w-xs mx-auto">
              Suas conversas com o assistente acadêmico serão arquivadas aqui para consulta futura.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {conversations.map((item) => {
              const lastMsg = item.messages?.[item.messages.length - 1];
              const requiresHuman = item.messages?.some((m) => m.requires_human);

              return (
                <div
                  key={item.id}
                  onClick={() => handleOpenConversation(item.id)}
                  className="bg-white rounded-2xl p-4 border border-gray-100 shadow-xs space-y-2 hover:border-primary-300 hover:shadow-sm cursor-pointer transition-all active:scale-[0.99]"
                >
                  <div className="flex items-start justify-between gap-2">
                    <h2 className="text-xs font-bold text-gray-800 leading-snug line-clamp-1">
                      {item.title || "Atendimento Acadêmico"}
                    </h2>
                    <Badge variant={requiresHuman ? "warning" : "success"}>
                      {requiresHuman ? "Suporte Humano" : "Resolvido"}
                    </Badge>
                  </div>

                  {lastMsg && (
                    <p className="text-xs text-gray-600 line-clamp-2 leading-relaxed">
                      {lastMsg.content}
                    </p>
                  )}

                  <div className="pt-2 border-t border-gray-50 flex items-center justify-between text-[11px] text-gray-400">
                    <span>
                      {new Date(item.created_at || (item as any).started_at).toLocaleDateString("pt-BR")}
                    </span>

                    <span className="flex items-center gap-1 text-primary-700 font-semibold">
                      Continuar conversa <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};