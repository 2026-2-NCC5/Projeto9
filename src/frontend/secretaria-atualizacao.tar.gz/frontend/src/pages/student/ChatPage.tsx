import React, { useEffect, useRef, useCallback, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";
import { ChatMessage } from "@/components/chat/ChatMessage";
import { ChatInput } from "@/components/chat/ChatInput";
import { useChatStore } from "@/store/chatStore";
import { api } from "@/services/api";
import type { ChatMessage as ChatMessageType, AgentResponse, AgentQuery } from "@/types";
import {
  Sparkles,
  RefreshCw,
  BookOpen,
  FileText,
  LifeBuoy,
  CreditCard,
  Calendar,
  GraduationCap,
  AlertCircle,
} from "lucide-react";

export const ChatPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const initialQuery = searchParams.get("q");

  const {
    messages,
    addMessage,
    isLoading,
    setLoading,
    conversationId,
    setConversationId,
  } = useChatStore();

  const [apiError, setApiError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const processedQueryRef = useRef<string | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = useCallback(
    async (userQuestion: string) => {
      const q = userQuestion.trim();
      if (!q) return;

      setApiError(null);

      const userMsg: ChatMessageType = {
        id: `msg-${Date.now()}-${Math.random()}`,
        role: "user",
        content: q,
        created_at: new Date().toISOString(),
      };

      addMessage(userMsg);
      setLoading(true);

      try {
        const payload: AgentQuery = {
          question: q,
          conversation_id: conversationId || undefined,
        };

        const res = await api.post<AgentResponse>("/agent/query", payload);
        const data = res.data;

        if (data.conversation_id && !conversationId) {
          setConversationId(data.conversation_id);
        }

        const assistantMsg: ChatMessageType = {
          id: data.id || `msg-asst-${Date.now()}`,
          role: "assistant",
          content: data.answer,
          created_at: data.updated_at || new Date().toISOString(),
          agent_response: data,
        };

        addMessage(assistantMsg);
      } catch (err: any) {
        const errorMsg =
          err.response?.data?.detail ||
          "Não foi possível obter resposta do agente no momento. Tente novamente.";
        setApiError(typeof errorMsg === "string" ? errorMsg : "Erro ao consultar o agente.");
      } finally {
        setLoading(false);
      }
    },
    [addMessage, conversationId, setConversationId, setLoading]
  );

  useEffect(() => {
    if (initialQuery && processedQueryRef.current !== initialQuery) {
      processedQueryRef.current = initialQuery;
      handleSend(initialQuery);
    }
  }, [initialQuery, handleSend]);

  const handleFeedback = (runId: string, rating: "positive" | "negative") => {
    navigate(`/feedback/${runId}?rating=${rating}`);
  };

  const promptSuggestions = [
    { title: "Emitir Comprovante de Matrícula", query: "Como solicitar declaração de matrícula?", icon: FileText },
    { title: "2ª Via de Boleto / Rematrícula", query: "Dúvidas sobre o financeiro e boletos?", icon: CreditCard },
    { title: "Prazos de Trancamento e Atividades", query: "Como consultar o calendário acadêmico?", icon: Calendar },
    { title: "Como acessar o Portal do Aluno?", query: "Como acessar o Portal do Aluno?", icon: BookOpen },
    { title: "Canais de Atendimento da FECAP", query: "Quais são os canais de atendimento?", icon: LifeBuoy },
    { title: "Solicitar Segunda Via de Documentos", query: "Como solicitar segunda via de documentos?", icon: GraduationCap },
  ];

  return (
    <div className="min-h-screen bg-[#F4F8F5] flex flex-col pb-20 md:pb-0">
      <Header />

      <main className="flex-1 max-w-md sm:max-w-2xl mx-auto w-full px-4 py-4 flex flex-col justify-between overflow-y-auto">
        <div className="flex-1 space-y-4">
          {apiError && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{apiError}</span>
            </div>
          )}

          {messages.length === 0 ? (
            <div className="py-6 px-2 text-center space-y-5">
              <div className="w-14 h-14 rounded-2xl bg-[#00E676] text-[#002B18] flex items-center justify-center mx-auto shadow-xs font-bold">
                <Sparkles className="w-7 h-7" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-[#0B2513]">Assistente Acadêmico FECAP</h1>
                <p className="text-xs text-[#4A6354] mt-1 max-w-xs mx-auto leading-relaxed">
                  Selecione uma dúvida frequente ou digite sua pergunta abaixo.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left pt-2">
                {promptSuggestions.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={idx}
                      onClick={() => handleSend(item.query)}
                      className="p-3.5 rounded-2xl bg-white border border-[#E1EBE4] hover:border-[#00E676] hover:shadow-xs transition-all text-xs font-semibold text-[#0B2513] flex items-center gap-2.5 active:scale-[0.98]"
                    >
                      <Icon className="w-4 h-4 text-[#004225] shrink-0" />
                      <span className="line-clamp-2">{item.title}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            messages.map((msg) => (
              <ChatMessage key={msg.id} message={msg} onFeedback={handleFeedback} />
            ))
          )}

          {isLoading && (
            <div className="flex gap-3 my-4">
              <div className="w-8 h-8 rounded-full bg-[#00E676] text-[#002B18] font-bold flex items-center justify-center text-xs animate-pulse shadow-xs">
                IA
              </div>
              <div className="p-4 rounded-2xl bg-white border border-[#E1EBE4] text-xs text-[#4A6354] flex items-center gap-2 shadow-xs">
                <RefreshCw className="w-4 h-4 animate-spin text-[#004225]" />
                <span>Buscando instrução oficial na base FECAP...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      <ChatInput onSendMessage={handleSend} isLoading={isLoading} />
      <BottomNav />
    </div>
  );
};