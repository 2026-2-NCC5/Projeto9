import React, { useState } from "react";
import { useNavigate, useSearchParams, useParams } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";
import { Button } from "@/components/ui/Button";
import { ThumbsUp, ThumbsDown, CheckCircle2, AlertCircle } from "lucide-react";
import { api } from "@/services/api";

export const FeedbackPage: React.FC = () => {
  const { runId } = useParams<{ runId: string }>();
  const [searchParams] = useSearchParams();
  const initialRating = searchParams.get("rating") === "negative" ? "negative" : "positive";
  const navigate = useNavigate();

  const [rating, setRating] = useState<"positive" | "negative">(initialRating);
  const [comment, setComment] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading || isSubmitted) return;

    setError("");
    setIsLoading(true);

    try {
      await api.post("/feedback/", {
        message_id: runId && runId !== "undefined" ? runId : null,
        rating,
        rating_value: rating === "positive" ? 5 : 1,
        comment: comment.trim() || undefined,
      });

      setIsSubmitted(true);
    } catch (err: any) {
      const msg = err.response?.data?.detail || "Erro ao registrar avaliação. Tente novamente.";
      setError(typeof msg === "string" ? msg : "Falha ao registrar feedback.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-20 md:pb-6">
      <Header />

      <main className="flex-1 max-w-md sm:max-w-xl mx-auto w-full px-4 pt-6 space-y-4">
        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {!isSubmitted ? (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-5">
            <h1 className="text-base font-bold text-gray-900 text-center">Avalie esta orientação</h1>
            <p className="text-xs text-gray-500 text-center">
              Sua avaliação ajuda a aprimorar o agente de orientação acadêmica.
            </p>

            <div className="flex justify-center gap-4">
              <button
                type="button"
                onClick={() => setRating("positive")}
                className={`p-4 rounded-2xl border flex flex-col items-center gap-2 w-28 transition-all ${
                  rating === "positive"
                    ? "border-emerald-500 bg-emerald-50 text-emerald-700 shadow-xs font-semibold"
                    : "border-gray-200 text-gray-500 hover:bg-gray-50"
                }`}
              >
                <ThumbsUp className="w-6 h-6" />
                <span className="text-xs">Resolveu 👍</span>
              </button>

              <button
                type="button"
                onClick={() => setRating("negative")}
                className={`p-4 rounded-2xl border flex flex-col items-center gap-2 w-28 transition-all ${
                  rating === "negative"
                    ? "border-red-500 bg-red-50 text-red-700 shadow-xs font-semibold"
                    : "border-gray-200 text-gray-500 hover:bg-gray-50"
                }`}
              >
                <ThumbsDown className="w-6 h-6" />
                <span className="text-xs">Não resolveu 👎</span>
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Comentário adicional (opcional)
                </label>
                <textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={3}
                  placeholder="Conte o que achou da resposta ou o que poderia melhorar..."
                  className="w-full input-field py-2.5 text-sm resize-none"
                />
              </div>

              <Button type="submit" className="w-full" isLoading={isLoading} disabled={isSubmitted}>
                Enviar Avaliação
              </Button>
            </form>
          </div>
        ) : (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs text-center space-y-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
            <h2 className="text-lg font-bold text-gray-900">Obrigado pelo seu feedback!</h2>
            <p className="text-xs text-gray-500">Sua opinião é fundamental para aprimorar nossas orientações.</p>

            <Button onClick={() => navigate("/home")} className="w-full">
              Voltar ao Início
            </Button>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};