import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { GraduationCap } from "lucide-react";

export const SplashPage: React.FC = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate("/login");
    }, 1800);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-primary-900 flex flex-col items-center justify-center p-6 text-white text-center">
      <div className="w-20 h-20 rounded-3xl bg-accent flex items-center justify-center text-primary-950 shadow-xl mb-6 animate-bounce">
        <GraduationCap className="w-10 h-10" />
      </div>

      <h1 className="text-3xl font-bold tracking-tight text-white mb-2">FECAP Guia</h1>
      <p className="text-accent-light text-sm font-medium">Agente Inteligente de Orientação ao Estudante</p>

      <div className="absolute bottom-8 text-[11px] text-primary-300">
        Projeto Interdisciplinar de Inteligência Artificial
      </div>
    </div>
  );
};