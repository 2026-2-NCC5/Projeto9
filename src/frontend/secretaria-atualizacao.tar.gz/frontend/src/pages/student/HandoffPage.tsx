import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";
import { Button } from "@/components/ui/Button";
import { LifeBuoy, CheckCircle2, ShieldAlert, AlertCircle } from "lucide-react";
import { api } from "@/services/api";
import { useChatStore } from "@/store/chatStore";
import type { HandoffResult } from "@/types";

export const HandoffPage: React.FC = () => {
  const navigate = useNavigate();
  const { conversationId } = useChatStore();

  const [reason, setReason] = useState("");
  const [category, setCategory] = useState("academico");
  const [priority, setPriority] = useState<"normal" | "priority" | "urgent">("normal");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [protocol, setProtocol] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;

    setError("");
    setIsLoading(true);

    try {
      const res = await api.post<HandoffResult>("/handoff/", {
        conversation_id: conversationId || undefined,
        category,
        priority,
        reason: reason.trim(),
      });

      setProtocol(res.data.protocol);
      setIsSubmitted(true);
    } catch (err: any) {
      const msg = err.response?.data?.detail || "Erro ao registrar encaminhamento. Tente novamente.";
      setError(typeof msg === "string" ? msg : "Falha ao encaminhar atendimento.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-20 md:pb-6">
      <Header />

      <main className="flex-1 max-w-md sm:max-w-xl mx-auto w-full px-4 pt-6 space-y-5">
        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {!isSubmitted ? (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs space-y-5">
            <div className="flex items-center gap-3 border-b border-gray-100 pb-4">
              <div className="w-10 h-10 rounded-xl bg-primary-100 text-primary-700 flex items-center justify-center shrink-0">
                <LifeBuoy className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-base font-bold text-gray-900">Encaminhamento para Atendimento Humano</h1>
                <p className="text-xs text-gray-500">Sua solicitação será analisada pela Secretaria Acadêmica.</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Categoria da Solicitação</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="input-field py-2.5 text-sm bg-white"
                >
                  <option value="academico">Acadêmico / Matrícula</option>
                  <option value="documentos">Documentos / Certidões</option>
                  <option value="financeiro">Financeiro / Boletos</option>
                  <option value="portal">Portal / Acessos</option>
                  <option value="outro">Outros Assuntos</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Prioridade</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: "normal", label: "Normal" },
                    { id: "priority", label: "Alta" },
                    { id: "urgent", label: "Urgente" },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setPriority(p.id as any)}
                      className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all ${
                        priority === p.id
                          ? "border-primary-500 bg-primary-50 text-primary-700 font-semibold shadow-xs"
                          : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Descrição da Solicitação
                </label>
                <textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  rows={4}
                  placeholder="Explique detalhadamente sua dúvida ou procedimento que precisa de suporte..."
                  className="w-full input-field py-2.5 text-sm resize-none"
                  required
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-[11px] text-slate-600 space-y-1">
                <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                  <ShieldAlert className="w-4 h-4 text-primary-600 shrink-0" />
                  <span>Resumo do Diálogo</span>
                </div>
                <p>O histórico de orientação será vinculado ao seu atendimento para agilizar a resposta.</p>
              </div>

              <Button type="submit" className="w-full" isLoading={isLoading}>
                Confirmar e Gerar Protocolo Real
              </Button>
            </form>
          </div>
        ) : (
          <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-xs text-center space-y-4">
            <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto" />
            <h2 className="text-lg font-bold text-gray-900">Solicitação Encaminhada!</h2>
            <p className="text-xs text-gray-600 max-w-xs mx-auto">
              Sua solicitação foi registrada com sucesso na fila da Secretaria Acadêmica ASA.
            </p>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1 max-w-xs mx-auto">
              <span className="text-[11px] text-gray-500 uppercase tracking-wider font-semibold block">Número de Protocolo</span>
              <span className="text-xl font-bold font-mono text-primary-600 block">{protocol}</span>
            </div>

            <div className="pt-4 flex flex-col gap-2">
              <Button onClick={() => navigate("/history")} variant="primary" className="w-full">
                Ver Meus Atendimentos
              </Button>
              <Button onClick={() => navigate("/home")} variant="outline" className="w-full">
                Voltar ao Início
              </Button>
            </div>
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
};