import React from "react";
import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";
import { HelpCircle, AlertTriangle } from "lucide-react";

export const HelpPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-20 md:pb-6">
      <Header />

      <main className="flex-1 max-w-md sm:max-w-xl mx-auto w-full px-4 pt-6 space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <HelpCircle className="w-5 h-5 text-primary-500" />
          <h1 className="text-base font-bold text-gray-900">Ajuda e Sobre o Agente</h1>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-3 text-xs text-gray-700 leading-relaxed">
          <h2 className="font-bold text-gray-900 text-sm">Como funciona o FECAP Guia?</h2>
          <p>
            O FECAP Guia é um agente de inteligência artificial projetado para orientar estudantes sobre procedimentos, documentos e serviços acadêmicos.
            Ele consulta a base oficial de orientações para fornecer respostas diretas, passo a passo numerado e próximas ações recomendadas.
          </p>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1 text-slate-800">
            <strong className="flex items-center gap-1.5 font-semibold text-primary-700">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" /> Orientação Segura
            </strong>
            <p className="text-[11px] leading-relaxed">
              Caso o agente não encontre confirmação oficial suficiente na base, ele informará claramente e oferecerá a opção de encaminhamento para atendimento humano pela Secretaria.
            </p>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-3 text-xs text-gray-700 leading-relaxed">
          <h2 className="font-bold text-gray-900 text-sm">Política de Privacidade</h2>
          <p>
            Dados tratados em conformidade com as diretrizes de privacidade e proteção de dados.
          </p>
        </div>
      </main>

      <BottomNav />
    </div>
  );
};