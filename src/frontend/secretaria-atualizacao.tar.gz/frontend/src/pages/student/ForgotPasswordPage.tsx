import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { KeyRound, ArrowLeft, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";

export const ForgotPasswordPage: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      setIsSubmitted(true);
    }, 700);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 shadow-xs border border-gray-100 rounded-2xl sm:px-10">
          <button
            onClick={() => navigate("/login")}
            className="inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-gray-800 mb-6 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Voltar ao login
          </button>

          {!isSubmitted ? (
            <>
              <div className="text-center mb-6">
                <div className="w-12 h-12 rounded-full bg-primary-50 text-primary-600 flex items-center justify-center mx-auto mb-3">
                  <KeyRound className="w-6 h-6" />
                </div>
                <h2 className="text-lg font-bold text-gray-900">Recuperar Senha</h2>
                <p className="text-xs text-gray-500 mt-1">
                  Digite seu e-mail acadêmico ou RA para receber o link de redefinição de senha.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <Input
                  label="E-mail ou RA"
                  type="text"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ex: estudante@demo.fecap.br"
                  required
                />

                <Button type="submit" className="w-full" isLoading={isLoading}>
                  Enviar Instruções
                </Button>
              </form>
            </>
          ) : (
            <div className="text-center py-4">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-gray-900">Instruções Enviadas (Simulação Demo)</h3>
              <p className="text-xs text-gray-600 my-3 leading-relaxed">
                Em ambiente acadêmico de demonstração, a solicitação para <strong>{email}</strong> foi registrada. Utilize as credenciais de demonstração na tela de login.
              </p>
              <Button onClick={() => navigate("/login")} className="w-full">
                Ir para o Login
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};