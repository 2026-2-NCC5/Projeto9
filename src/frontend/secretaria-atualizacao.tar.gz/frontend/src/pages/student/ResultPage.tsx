import React from "react";
import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";
import { MOCK_AGENT_RESPONSES } from "@/services/mockData";
import { useChatStore } from "@/store/chatStore";
import { StepsCard } from "@/components/chat/StepsCard";
import { NextActionCard } from "@/components/chat/NextActionCard";
import { EvidenceCard } from "@/components/chat/EvidenceCard";
import { Button } from "@/components/ui/Button";
import { useNavigate } from "react-router-dom";
import { LifeBuoy, MessageSquare } from "lucide-react";

export const ResultPage: React.FC = () => {
  const navigate = useNavigate();
  const { messages } = useChatStore();

  const lastAssistant = [...messages].reverse().find((m) => m.role === "assistant");
  const lastUser = [...messages].reverse().find((m) => m.role === "user");

  const isReal = Boolean(lastAssistant?.agent_response);
  const res = lastAssistant?.agent_response || MOCK_AGENT_RESPONSES.matricula;
  const questionText = lastUser?.content || "Como solicitar declaração de matrícula? (Exemplo de Demonstração)";

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-20 md:pb-6">
      <Header />

      <main className="flex-1 max-w-md sm:max-w-xl mx-auto w-full px-4 pt-6 space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-base font-bold text-gray-900">Resultado da Orientação</h1>
          {!isReal && (
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
              MODO DEMONSTRAÇÃO (EXEMPLO FICTÍCIO)
            </span>
          )}
        </div>

        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-xs space-y-4 text-xs">
          <div>
            <span className="text-gray-400 block mb-1">Pergunta:</span>
            <strong className="text-gray-800 text-sm">{questionText}</strong>
          </div>

          <div className="pt-3 border-t border-gray-100">
            <span className="text-gray-400 block mb-1">Orientação do Agente:</span>
            <p className="text-gray-700 leading-relaxed text-sm">{res.answer}</p>
          </div>

          <StepsCard steps={res.steps} />
          <NextActionCard action={res.next_action} />
          <EvidenceCard source={res.source} version={res.version} updated_at={res.updated_at} />

          <div className="flex flex-col sm:flex-row gap-2 pt-2">
            <Button
              variant="primary"
              className="flex-1 flex items-center justify-center gap-2"
              onClick={() => navigate("/chat")}
            >
              <MessageSquare className="w-4 h-4" /> Ir para o Chat RAG
            </Button>
            <Button
              variant="outline"
              className="flex-1 flex items-center justify-center gap-2"
              onClick={() => navigate("/handoff")}
            >
              <LifeBuoy className="w-4 h-4" /> Atendimento humano
            </Button>
          </div>
        </div>
      </main>

      <BottomNav />
    </div>
  );
};