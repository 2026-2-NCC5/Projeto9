import React, { useEffect, useState } from "react";
import { Header } from "@/components/layout/Header";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { api } from "@/services/api";
import {
  MessageSquare,
  ShieldCheck,
  ThumbsUp,
  LifeBuoy,
  HelpCircle,
  BookOpen,
  RefreshCw,
  AlertCircle,
} from "lucide-react";
import type { DashboardMetrics } from "@/types";

export const DashboardPage: React.FC = () => {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");

  const fetchMetrics = async () => {
    setIsLoading(true);
    setError("");
    try {
      const res = await api.get<DashboardMetrics>("/dashboard/");
      setMetrics(res.data);
    } catch (err: any) {
      setError(
        err.response?.data?.detail || "Não foi possível carregar os indicadores do dashboard."
      );
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMetrics();
  }, []);

  const d: DashboardMetrics = metrics || {
    total_questions: 0,
    total_answers: 0,
    answers_with_evidence_rate: 0,
    positive_feedback_rate: 0,
    handoffs_count: 0,
    unanswered_count: 0,
    avg_response_time_ms: 0,
    active_documents_count: 0,
    validations_count: 0,
    top_categories: [],
    questions_per_day: [],
  };

  const statCards = [
    {
      title: "Total de Orientações",
      value: d.total_questions,
      icon: MessageSquare,
      color: "text-blue-600 bg-blue-50",
    },
    {
      title: "Respostas Fundamentadas",
      value: `${d.answers_with_evidence_rate}%`,
      icon: ShieldCheck,
      color: "text-emerald-600 bg-emerald-50",
    },
    {
      title: "Feedback Positivo",
      value: `${d.positive_feedback_rate}%`,
      icon: ThumbsUp,
      color: "text-indigo-600 bg-indigo-50",
    },
    {
      title: "Encaminhamentos Humanos",
      value: d.handoffs_count,
      icon: LifeBuoy,
      color: "text-amber-600 bg-amber-50",
    },
    {
      title: "Abstenções (Sem Evidência)",
      value: d.unanswered_count,
      icon: HelpCircle,
      color: "text-red-600 bg-red-50",
    },
    {
      title: "Documentos Ativos / Validações RF08",
      value: `${d.active_documents_count ?? 0} docs • ${d.validations_count ?? 0} rev`,
      icon: BookOpen,
      color: "text-purple-600 bg-purple-50",
    },
  ];

  const maxCatCount = Math.max(1, ...d.top_categories.map((c) => c.count));
  const maxDailyCount = Math.max(1, ...d.questions_per_day.map((day) => day.count));

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        <AdminSidebar />

        <main className="flex-1 p-4 md:p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900">Dashboard Indicadores RAG</h1>
              <p className="text-xs text-gray-500">
                Métricas reais de orientação, feedback e desempenho do agente de IA (SQLite).
              </p>
            </div>
            <button
              onClick={fetchMetrics}
              disabled={isLoading}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-gray-200 text-xs font-semibold text-gray-700 hover:bg-gray-50 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
              Atualizar
            </button>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {statCards.map((card, idx) => {
              const Icon = card.icon;
              return (
                <div
                  key={idx}
                  className="bg-white p-4 rounded-2xl border border-gray-100 shadow-xs flex items-center gap-4"
                >
                  <div
                    className={`w-12 h-12 rounded-xl ${card.color} flex items-center justify-center shrink-0`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-xs text-gray-400 font-medium block">{card.title}</span>
                    <span className="text-xl font-bold text-gray-900 block">
                      {isLoading ? "..." : card.value}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs space-y-4">
              <h2 className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                Categorias Mais Consultadas
              </h2>
              {d.top_categories.length === 0 ? (
                <p className="text-xs text-gray-400 py-8 text-center">
                  Nenhuma consulta categorizada registrada até o momento.
                </p>
              ) : (
                <div className="space-y-3">
                  {d.top_categories.map((cat, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs font-medium text-gray-700">
                        <span>{cat.category}</span>
                        <span>{cat.count} registros</span>
                      </div>
                      <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-primary-500 h-2 rounded-full"
                          style={{ width: `${(cat.count / maxCatCount) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs space-y-4">
              <h2 className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                Evolução Diária (Consultas Reais)
              </h2>
              {d.questions_per_day.length === 0 ? (
                <p className="text-xs text-gray-400 py-8 text-center">
                  Nenhuma consulta diária registrada até o momento.
                </p>
              ) : (
                <div className="flex items-end justify-between h-40 gap-2 pt-4 px-2">
                  {d.questions_per_day.map((day, idx) => (
                    <div
                      key={idx}
                      className="flex-1 flex flex-col items-center gap-2 h-full justify-end"
                    >
                      <span className="text-[10px] text-gray-500 font-bold">{day.count}</span>
                      <div
                        className="w-full bg-accent rounded-t-lg transition-all"
                        style={{ height: `${Math.max(10, (day.count / maxDailyCount) * 100)}%` }}
                      />
                      <span className="text-[10px] text-gray-400">{day.date}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};