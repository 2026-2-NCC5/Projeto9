import React, { useEffect, useState } from "react";
import { Header } from "@/components/layout/Header";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { api } from "@/services/api";
import { Button } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { Plus, Edit, Power, RefreshCw, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { KnowledgeDocument } from "@/types";

export const KnowledgePage: React.FC = () => {
  const navigate = useNavigate();
  const [documents, setDocuments] = useState<KnowledgeDocument[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [togglingId, setTogglingId] = useState<string | null>(null);

  const fetchDocuments = async () => {
    setIsLoading(true);
    setError("");
    try {
      const res = await api.get<KnowledgeDocument[]>("/knowledge/");
      setDocuments(res.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Erro ao carregar base de conhecimento.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  const handleToggleStatus = async (doc: KnowledgeDocument) => {
    const nextStatus = doc.status === "active" ? "inactive" : "active";
    setTogglingId(doc.id);
    setError("");
    try {
      const res = await api.patch<KnowledgeDocument>(
        `/knowledge/${doc.id}/status?new_status=${nextStatus}`
      );
      setDocuments((prev) => prev.map((d) => (d.id === doc.id ? res.data : d)));
    } catch (err: any) {
      setError(err.response?.data?.detail || "Falha ao alterar status do documento.");
    } finally {
      setTogglingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        <AdminSidebar />

        <main className="flex-1 p-4 md:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-gray-900">Base de Conhecimento RAG</h1>
              <p className="text-xs text-gray-500">
                Gerenciamento dos procedimentos, versionamento e sincronização com ChromaDB.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={fetchDocuments}
                disabled={isLoading}
                className="p-2 rounded-xl bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
                title="Atualizar lista"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
              </button>
              <Button onClick={() => navigate("/admin/knowledge/new")} size="sm">
                <Plus className="w-4 h-4 mr-1" /> Novo Documento
              </Button>
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="bg-white rounded-2xl border border-gray-100 shadow-xs overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-gray-100 text-gray-500 uppercase tracking-wider font-semibold">
                <tr>
                  <th className="p-3.5">Título do Documento</th>
                  <th className="p-3.5">Categoria</th>
                  <th className="p-3.5">Versão</th>
                  <th className="p-3.5">Chunks</th>
                  <th className="p-3.5">Atualização</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {isLoading ? (
                  <tr>
                    <td colSpan={7} className="p-6 text-center text-gray-400">
                      Carregando documentos...
                    </td>
                  </tr>
                ) : documents.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-6 text-center text-gray-400">
                      Nenhum documento cadastrado.
                    </td>
                  </tr>
                ) : (
                  documents.map((doc) => (
                    <tr key={doc.id} className="hover:bg-slate-50/50">
                      <td className="p-3.5 font-bold text-gray-900">{doc.title}</td>
                      <td className="p-3.5 text-gray-600">{doc.category}</td>
                      <td className="p-3.5 text-gray-600 font-mono">{doc.version}</td>
                      <td className="p-3.5 text-gray-500 font-mono">{doc.chunks_count ?? 0}</td>
                      <td className="p-3.5 text-gray-500">
                        {doc.updated_at ? new Date(doc.updated_at).toLocaleDateString("pt-BR") : "-"}
                      </td>
                      <td className="p-3.5">
                        {doc.status === "active" ? (
                          <Badge variant="success">Ativo</Badge>
                        ) : doc.status === "draft" ? (
                          <Badge variant="warning">Rascunho</Badge>
                        ) : (
                          <Badge variant="danger">Inativo</Badge>
                        )}
                      </td>
                      <td className="p-3.5 text-right space-x-1">
                        <button
                          onClick={() => handleToggleStatus(doc)}
                          disabled={togglingId === doc.id}
                          className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-600"
                          title={doc.status === "active" ? "Desativar do RAG" : "Ativar no RAG"}
                        >
                          <Power
                            className={`w-4 h-4 ${
                              doc.status === "active" ? "text-emerald-600" : "text-gray-400"
                            }`}
                          />
                        </button>
                        <button
                          onClick={() => navigate(`/admin/knowledge/${doc.id}`)}
                          className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-600"
                          title="Editar"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
  );
};