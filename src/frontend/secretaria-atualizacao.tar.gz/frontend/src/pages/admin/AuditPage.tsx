import React, { useEffect, useState } from "react";
import { Header } from "@/components/layout/Header";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { api } from "@/services/api";
import { RefreshCw, AlertCircle } from "lucide-react";
import type { AuditLog } from "@/types";

export const AuditPage: React.FC = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [resourceFilter, setResourceFilter] = useState<string>("");

  const fetchLogs = async (resFilter: string = resourceFilter) => {
    setIsLoading(true);
    setError("");
    try {
      const params = resFilter ? `?resource=${encodeURIComponent(resFilter)}` : "";
      const res = await api.get<AuditLog[]>(`/audit/${params}`);
      setLogs(res.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Erro ao carregar registros de auditoria.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs("");
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        <AdminSidebar />

        <main className="flex-1 p-4 md:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                Logs de Auditoria e Conformidade
              </h1>
              <p className="text-xs text-gray-500">
                Registros reais de solicitações, alterações e validações em conformidade com diretrizes de segurança.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <select
                value={resourceFilter}
                onChange={(e) => {
                  setResourceFilter(e.target.value);
                  fetchLogs(e.target.value);
                }}
                className="input-field py-1.5 text-xs bg-white"
              >
                <option value="">Todos os Recursos</option>
                <option value="auth">Autenticação (auth)</option>
                <option value="agent">Agente RAG (agent)</option>
                <option value="knowledge_document">Base Conhecimento (knowledge)</option>
                <option value="human_validation">Validação RF08 (human_validation)</option>
                <option value="handoff">Encaminhamentos (handoff)</option>
                <option value="feedback">Feedbacks (feedback)</option>
              </select>
              <button
                onClick={() => fetchLogs(resourceFilter)}
                disabled={isLoading}
                className="p-2 rounded-xl bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
                title="Atualizar trilha"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
              </button>
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="bg-white rounded-2xl border border-gray-100 shadow-xs overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-50 border-b border-gray-100 text-gray-500 uppercase tracking-wider font-semibold font-sans">
                <tr>
                  <th className="p-3.5">Data/Hora</th>
                  <th className="p-3.5">Usuário (ID)</th>
                  <th className="p-3.5">Ação</th>
                  <th className="p-3.5">Recurso</th>
                  <th className="p-3.5">Detalhe</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {isLoading ? (
                  <tr>
                    <td colSpan={5} className="p-6 text-center text-gray-400 font-sans">
                      Carregando logs de auditoria...
                    </td>
                  </tr>
                ) : logs.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-6 text-center text-gray-400 font-sans">
                      Nenhum registro de auditoria encontrado.
                    </td>
                  </tr>
                ) : (
                  logs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="p-3.5 text-gray-500 whitespace-nowrap">
                        {new Date(log.created_at).toLocaleString("pt-BR")}
                      </td>
                      <td className="p-3.5 font-bold text-gray-800">
                        {log.user_id ? log.user_id.slice(0, 8) + "..." : "sistema"}
                      </td>
                      <td className="p-3.5 text-primary-600 font-semibold">{log.action}</td>
                      <td className="p-3.5 text-gray-600">{log.resource}</td>
                      <td className="p-3.5 text-gray-500">{log.detail}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
  );
};