import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { api } from "@/services/api";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { ArrowLeft, Save, Upload, AlertCircle } from "lucide-react";
import type { KnowledgeDocumentDetail } from "@/types";

export const KnowledgeFormPage: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEditing = Boolean(id);

  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("documentos_certidoes");
  const [origin, setOrigin] = useState("Secretaria Acadêmica ASA");
  const [content, setContent] = useState("");
  const [version, setVersion] = useState("1.0");
  const [status, setStatus] = useState("active");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (isEditing && id) {
      setIsLoading(true);
      api
        .get<KnowledgeDocumentDetail>(`/knowledge/${id}`)
        .then((res) => {
          const d = res.data;
          setTitle(d.title);
          setCategory(d.category);
          setOrigin(d.origin || "Secretaria Acadêmica ASA");
          setVersion(d.version);
          setStatus(d.status);
          setContent(d.content || "");
        })
        .catch((err) => {
          setError(err.response?.data?.detail || "Documento não encontrado.");
        })
        .finally(() => {
          setIsLoading(false);
        });
    }
  }, [id, isEditing]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      if (!isEditing && selectedFile) {
        const formData = new FormData();
        formData.append("file", selectedFile);
        if (title.trim()) formData.append("title", title.trim());
        formData.append("category", category);
        formData.append("origin", origin);
        formData.append("version", version);
        formData.append("status", status);

        await api.post("/knowledge/upload", formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });
      } else if (isEditing && id) {
        await api.put(`/knowledge/${id}`, {
          title,
          category,
          origin,
          version,
          status,
          content,
        });
      } else {
        await api.post("/knowledge/", {
          title,
          category,
          origin,
          version,
          status,
          content,
          is_demo: false,
        });
      }
      navigate("/admin/knowledge");
    } catch (err: any) {
      setError(
        err.response?.data?.detail || "Não foi possível salvar e indexar o documento."
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        <AdminSidebar />

        <main className="flex-1 p-4 md:p-6 space-y-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/admin/knowledge")}
              className="p-2 rounded-lg hover:bg-gray-200"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <h1 className="text-xl font-bold text-gray-900">
              {isEditing ? "Editar Documento Orientativo" : "Cadastrar Documento Orientativo"}
            </h1>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form
            onSubmit={handleSubmit}
            className="bg-white p-6 rounded-2xl border border-gray-100 shadow-xs space-y-4"
          >
            <Input
              label="Título do Procedimento"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required={!selectedFile}
            />

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Categoria
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="input-field py-2.5 text-sm w-full"
                >
                  <option value="portal_sistemas">Portal e Sistemas</option>
                  <option value="documentos_certidoes">Documentos e Certidões</option>
                  <option value="atendimento_suporte">Atendimento e Suporte</option>
                  <option value="procedimentos">Procedimentos Acadêmicos</option>
                  <option value="faq">FAQ</option>
                  <option value="financeiro">Financeiro</option>
                  <option value="biblioteca">Biblioteca</option>
                  <option value="estagios">Estágios e Convênios</option>
                </select>
              </div>
              <Input
                label="Versão do Documento"
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                required
              />
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                  Status de Indexação
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  className="input-field py-2.5 text-sm w-full"
                >
                  <option value="active">Ativo (Indexado no ChromaDB)</option>
                  <option value="inactive">Inativo (Fora do RAG)</option>
                  <option value="draft">Rascunho</option>
                </select>
              </div>
            </div>

            <Input
              label="Origem / Setor Responsável"
              value={origin}
              onChange={(e) => setOrigin(e.target.value)}
              required
            />

            {!isEditing && (
              <div className="p-4 rounded-xl bg-slate-50 border border-dashed border-gray-300 space-y-2">
                <label className="block text-xs font-semibold text-gray-700 flex items-center gap-1.5">
                  <Upload className="w-4 h-4 text-primary-600" />
                  Upload de Arquivo Oficial (.PDF ou .TXT) — Opcional
                </label>
                <input
                  type="file"
                  accept=".pdf,.txt"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                  className="text-xs text-gray-600"
                />
                {selectedFile && (
                  <p className="text-[11px] text-emerald-700 font-medium">
                    Arquivo selecionado: {selectedFile.name} (o texto será extraído e validado automaticamente).
                  </p>
                )}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1.5">
                Conteúdo do Procedimento (Texto Completo)
              </label>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                rows={10}
                placeholder={
                  selectedFile
                    ? "O conteúdo será extraído automaticamente do arquivo enviado..."
                    : "Insira a orientação completa com etapas e diretrizes..."
                }
                className="w-full input-field py-2.5 text-sm resize-none font-mono text-xs"
                required={!selectedFile}
                disabled={Boolean(selectedFile && !isEditing)}
              />
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/admin/knowledge")}
              >
                Cancelar
              </Button>
              <Button type="submit" isLoading={isLoading}>
                <Save className="w-4 h-4 mr-1" /> Salvar e Sincronizar ChromaDB
              </Button>
            </div>
          </form>
        </main>
      </div>
    </div>
  );
};