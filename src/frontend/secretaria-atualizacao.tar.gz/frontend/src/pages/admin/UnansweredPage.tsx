import React, { useEffect, useState } from "react";
import { Header } from "@/components/layout/Header";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { api } from "@/services/api";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { CheckCircle2, Edit3, AlertCircle, RefreshCw } from "lucide-react";
import type { UnansweredQuestionItem, ValidationDecision } from "@/types";

export const UnansweredPage: React.FC = () => {
  const [items, setItems] = useState<UnansweredQuestionItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");

  // Estado do painel de revisão e validação RF08
  const [selectedItem, setSelectedItem] = useState<UnansweredQuestionItem | null>(null);
  const [decision, setDecision] = useState<ValidationDecision>("complement");
  const [classification, setClassification] = useState<string>("documentos_certidoes");
  const [justification, setJustification] = useState<string>("");
  const [adjustedAnswer, setAdjustedAnswer] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const fetchUnanswered = async () => {
    setIsLoading(true);
    setError("");
    try {
      const res = await api.get<UnansweredQuestionItem[]>("/agent/unanswered");
      setItems(res.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Erro ao carregar abstenções do agente.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUnanswered();
  }, []);

  const openReviewModal = (item: UnansweredQuestionItem) => {
    setSelectedItem(item);
    setDecision((item.validation_decision as ValidationDecision) || "complement");
    setClassification(item.classification || "documentos_certidoes");
    setJustification(item.justification || "");
    setAdjustedAnswer(item.agent_answer || "");
  };

  const handleSaveValidation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedItem) return;
    setIsSubmitting(true);
    setError("");

    try {
      await api.post("/agent/validations", {
        message_id: selectedItem.message_id,
        decision,
        classification,
        justification,
        adjusted_answer:
          decision === "adjust" || decision === "complement" ? adjustedAnswer : undefined,
        response_version: "1.0",
      });
      setSelectedItem(null);
      await fetchUnanswered();
    } catch (err: any) {
      setError(err.response?.data?.detail || "Erro ao registrar validação humana RF08.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        <AdminSidebar />

        <main className="flex-1 p-4 md:p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                Perguntas sem Resposta (Abstenções & Revisão RF08)
              </h1>
              <p className="text-xs text-gray-500">
                Consultas em que o agente realizou abstenção por falta de evidência oficial. Revise, classifique e valide.
              </p>
            </div>
            <button
              onClick={fetchUnanswered}
              disabled={isLoading}
              className="p-2 rounded-xl bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
              title="Atualizar"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
            </button>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {selectedItem && (
            <form
              onSubmit={handleSaveValidation}
              className="bg-white p-5 rounded-2xl border-2 border-primary-500 shadow-sm space-y-4"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div>
                  <span className="text-[11px] font-bold uppercase text-primary-600">
                    Validação Humana — RF08
                  </span>
                  <h3 className="text-sm font-bold text-gray-900 mt-0.5">
                    Pergunta: "{selectedItem.question}"
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedItem(null)}
                  className="text-xs text-gray-400 hover:text-gray-600"
                >
                  Fechar
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Decisão de Validação (RF08)
                  </label>
                  <select
                    value={decision}
                    onChange={(e) => setDecision(e.target.value as ValidationDecision)}
                    className="input-field py-2 text-xs w-full"
                  >
                    <option value="confirm">Confirmar abstenção correta</option>
                    <option value="complement">Complementar orientação oficial</option>
                    <option value="adjust">Ajustar e corrigir resposta</option>
                    <option value="reject">Rejeitar resposta do agente</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Classificação Temática
                  </label>
                  <select
                    value={classification}
                    onChange={(e) => setClassification(e.target.value)}
                    className="input-field py-2 text-xs w-full"
                  >
                    <option value="documentos_certidoes">Documentos e Certidões</option>
                    <option value="portal_sistemas">Portal e Sistemas</option>
                    <option value="financeiro">Financeiro / Boletos</option>
                    <option value="procedimentos">Procedimentos Acadêmicos</option>
                    <option value="estagios">Estágios e Convênios</option>
                    <option value="fora_escopo">Fora de Escopo Institucional</option>
                  </select>
                </div>
              </div>

              {(decision === "adjust" || decision === "complement") && (
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Resposta Ajustada / Complementada (gerará nova versão auditada)
                  </label>
                  <textarea
                    value={adjustedAnswer}
                    onChange={(e) => setAdjustedAnswer(e.target.value)}
                    rows={3}
                    className="w-full input-field py-2 text-xs"
                    placeholder="Informe a orientação correta para o estudante..."
                    required
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Justificativa da Decisão {decision !== "confirm" && "*"}
                </label>
                <input
                  type="text"
                  value={justification}
                  onChange={(e) => setJustification(e.target.value)}
                  className="w-full input-field py-2 text-xs"
                  placeholder="Explique o motivo da decisão ou qual documento deve ser incluído na base..."
                  required={decision !== "confirm"}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" size="sm" onClick={() => setSelectedItem(null)}>
                  Cancelar
                </Button>
                <Button type="submit" size="sm" isLoading={isSubmitting}>
                  <CheckCircle2 className="w-4 h-4 mr-1" /> Registrar Decisão RF08
                </Button>
              </div>
            </form>
          )}

          <div className="space-y-3">
            {isLoading ? (
              <div className="bg-white p-6 rounded-2xl border border-gray-100 text-center text-xs text-gray-400">
                Carregando abstenções registradas...
              </div>
            ) : items.length === 0 ? (
              <div className="bg-white p-6 rounded-2xl border border-gray-100 text-center text-xs text-gray-400">
                Nenhuma pergunta sem resposta pendente no momento.
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.message_id}
                  className="bg-white p-4 rounded-2xl border border-gray-100 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <h2 className="text-xs font-bold text-gray-800">{item.question}</h2>
                    <p className="text-[11px] text-gray-500 line-clamp-2">{item.agent_answer}</p>
                    <div className="flex flex-wrap items-center gap-3 text-[11px] text-gray-400 pt-1">
                      <span>
                        Confiança:{" "}
                        <strong>{Math.round((item.confidence || 0) * 100)}%</strong>
                      </span>
                      <span>
                        Data: {new Date(item.created_at).toLocaleString("pt-BR")}
                      </span>
                      {item.classification && (
                        <span className="text-primary-600 font-semibold">
                          Classificação: {item.classification}
                        </span>
                      )}
                      {item.justification && (
                        <span className="italic text-gray-500">
                          Justificativa: "{item.justification}"
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {item.validation_status === "reviewed" ? (
                      <Badge variant="success">
                        Revisado ({item.validation_decision})
                      </Badge>
                    ) : (
                      <Badge variant="warning">Análise Pendente</Badge>
                    )}
                    <button
                      onClick={() => openReviewModal(item)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-gray-700 transition-colors"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Revisar RF08
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </main>
      </div>
    </div>
  );
};