import React, { useEffect, useState } from "react";
import { Header } from "@/components/layout/Header";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { api } from "@/services/api";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Edit, RefreshCw, AlertCircle, CheckCircle2 } from "lucide-react";
import type { HandoffAdminItem } from "@/types";

export const HandoffsPage: React.FC = () => {
  const [handoffs, setHandoffs] = useState<HandoffAdminItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [successMsg, setSuccessMsg] = useState<string>("");

  const [selectedTicket, setSelectedTicket] = useState<HandoffAdminItem | null>(null);
  const [statusVal, setStatusVal] = useState<string>("pending");
  const [attendant, setAttendant] = useState<string>("");
  const [summary, setSummary] = useState<string>("");
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const fetchHandoffs = async () => {
    setIsLoading(true);
    setError("");
    try {
      const res = await api.get<HandoffAdminItem[]>("/handoff/");
      setHandoffs(res.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Erro ao carregar fila de encaminhamentos.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchHandoffs();
  }, []);

  const openEdit = (ticket: HandoffAdminItem) => {
    setSelectedTicket(ticket);
    setStatusVal(ticket.status || "pending");
    setAttendant(ticket.attendant || "Secretaria Acadêmica ASA");
    setSummary(ticket.summary || "");
    setSuccessMsg("");
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket) return;
    setIsSaving(true);
    setError("");

    try {
      const res = await api.patch<HandoffAdminItem>(
        `/handoff/${selectedTicket.protocol}`,
        {
          status: statusVal,
          attendant,
          summary,
        }
      );
      setHandoffs((prev) =>
        prev.map((h) => (h.protocol === selectedTicket.protocol ? res.data : h))
      );
      setSelectedTicket(null);
      setSuccessMsg(`Protocolo ${selectedTicket.protocol} atualizado e auditado com sucesso.`);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Erro ao atualizar encaminhamento.");
    } finally {
      setIsSaving(false);
    }
  };

  const statusLabel = (s: string) => {
    if (s === "in_progress") return "Em Atendimento";
    if (s === "resolved") return "Resolvido";
    if (s === "transferred") return "Transferido";
    return "Pendente";
  };

  const priorityLabel = (p: string) => {
    if (p === "urgent") return "Urgente";
    if (p === "priority") return "Prioritário";
    return "Normal";
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        <AdminSidebar />

        <main className="flex-1 p-4 md:p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900">Fila de Encaminhamentos Humanos</h1>
              <p className="text-xs text-gray-500">
                Solicitações reais registradas para atendimento pela Secretaria Acadêmica.
              </p>
            </div>
            <button
              onClick={fetchHandoffs}
              disabled={isLoading}
              className="p-2 rounded-xl bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
              title="Atualizar fila"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
            </button>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-2 text-xs text-emerald-700">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {selectedTicket && (
            <form
              onSubmit={handleSave}
              className="bg-white p-5 rounded-2xl border-2 border-primary-500 shadow-sm space-y-4"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                <h3 className="text-sm font-bold text-gray-900">
                  Gerenciar Protocolo {selectedTicket.protocol}
                </h3>
                <button
                  type="button"
                  onClick={() => setSelectedTicket(null)}
                  className="text-xs text-gray-400 hover:text-gray-600"
                >
                  Fechar
                </button>
              </div>

              <p className="text-xs text-gray-600 bg-slate-50 p-3 rounded-xl">
                <strong>Motivo do estudante:</strong> {selectedTicket.reason}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Status do Atendimento
                  </label>
                  <select
                    value={statusVal}
                    onChange={(e) => setStatusVal(e.target.value)}
                    className="input-field py-2 text-xs w-full"
                  >
                    <option value="pending">Pendente</option>
                    <option value="in_progress">Em Atendimento</option>
                    <option value="resolved">Resolvido</option>
                    <option value="transferred">Transferido</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Responsável / Setor Atendente
                  </label>
                  <input
                    type="text"
                    value={attendant}
                    onChange={(e) => setAttendant(e.target.value)}
                    className="input-field py-2 text-xs w-full"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Observações e Providências Tomadas
                </label>
                <textarea
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  rows={3}
                  className="w-full input-field py-2 text-xs"
                  placeholder="Registre o retorno dado ao estudante..."
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedTicket(null)}
                >
                  Cancelar
                </Button>
                <Button type="submit" size="sm" isLoading={isSaving}>
                  Salvar Alterações
                </Button>
              </div>
            </form>
          )}

          <div className="bg-white rounded-2xl border border-gray-100 shadow-xs overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-gray-100 text-gray-500 uppercase tracking-wider font-semibold">
                <tr>
                  <th className="p-3.5">Protocolo</th>
                  <th className="p-3.5">Categoria</th>
                  <th className="p-3.5">Prioridade</th>
                  <th className="p-3.5">Responsável</th>
                  <th className="p-3.5">Data</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {isLoading ? (
                  <tr>
                    <td colSpan={7} className="p-6 text-center text-gray-400">
                      Carregando encaminhamentos...
                    </td>
                  </tr>
                ) : handoffs.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-6 text-center text-gray-400">
                      Nenhum encaminhamento registrado.
                    </td>
                  </tr>
                ) : (
                  handoffs.map((h) => (
                    <tr key={h.id} className="hover:bg-slate-50">
                      <td className="p-3.5 font-bold font-mono text-primary-600">
                        {h.protocol}
                      </td>
                      <td className="p-3.5 text-gray-600">{h.category}</td>
                      <td className="p-3.5">
                        <Badge
                          variant={
                            h.priority === "urgent" || h.priority === "priority"
                              ? "danger"
                              : "primary"
                          }
                        >
                          {priorityLabel(h.priority)}
                        </Badge>
                      </td>
                      <td className="p-3.5 text-gray-600">
                        {h.attendant || "Secretaria Acadêmica ASA"}
                      </td>
                      <td className="p-3.5 text-gray-500">
                        {new Date(h.created_at).toLocaleDateString("pt-BR")}
                      </td>
                      <td className="p-3.5">
                        <Badge
                          variant={
                            h.status === "resolved"
                              ? "success"
                              : h.status === "in_progress"
                              ? "primary"
                              : "warning"
                          }
                        >
                          {statusLabel(h.status)}
                        </Badge>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => openEdit(h)}
                          className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-600"
                          title="Gerenciar encaminhamento"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
  );
};