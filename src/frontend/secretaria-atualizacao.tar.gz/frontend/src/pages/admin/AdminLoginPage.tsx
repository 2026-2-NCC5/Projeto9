import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { LogIn, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { useAuthStore } from "@/store/authStore";
import { api } from "@/services/api";
import { FecapLogo } from "@/components/common/FecapLogo";
import type { AuthTokens } from "@/types";

export const AdminLoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { setAuth } = useAuthStore();

  const [email, setEmail] = useState("admin@demo.fecap.br");
  const [password, setPassword] = useState("admin1234");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const response = await api.post<AuthTokens>("/auth/login", {
        email,
        password,
      });

      const { user, access_token, refresh_token } = response.data;

      if (user.role !== "admin") {
        setError("Acesso restrito. Este usuário não possui privilégios de administrador.");
        setIsLoading(false);
        return;
      }

      setAuth(user, access_token, refresh_token);
      navigate("/admin/dashboard");
    } catch (err: any) {
      const msg =
        err.response?.data?.detail || "Erro ao conectar com o servidor administrativo.";
      setError(typeof msg === "string" ? msg : "Credenciais administrativas inválidas.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#002B18] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="mb-4">
          <FecapLogo size="lg" />
        </div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Painel Administrativo</h1>
        <p className="mt-1 text-xs text-[#00E676] font-semibold">FECAP Guia — Gestão de Base e Indicadores RAG</p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 shadow-xl border border-gray-200 rounded-[16px] sm:px-10">
          <form className="space-y-4" onSubmit={handleSubmit}>
            {error && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <Input
              label="E-mail Administrativo"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <Input
              label="Senha"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <Button type="submit" className="w-full btn-brand" isLoading={isLoading}>
              <LogIn className="w-4 h-4 mr-1" /> Acessar Painel
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
};