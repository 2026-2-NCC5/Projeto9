import React, { useEffect, useState } from "react";
import { Header } from "@/components/layout/Header";
import { AdminSidebar } from "@/components/layout/AdminSidebar";
import { api } from "@/services/api";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { AlertCircle, CheckCircle2, Edit3, RefreshCw } from "lucide-react";
import type { FeedbackItem, ValidationDecision } from "@/types";

export const FeedbacksPage: React.FC = () => {
  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>([]);
  const [filterReview, setFilterReview] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [successMsg, setSuccessMsg] = useState<string>("");

  // Estado para validação RF08 a partir de um feedback
  const [selectedFeedback, setSelectedFeedback] = useState<FeedbackItem | null>(null);
  const [decision, setDecision] = useState<ValidationDecision>("adjust");
  const [justification, setJustification] = useState<string>("");
  const [adjustedAnswer, setAdjustedAnswer] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const fetchFeedbacks = async () => {
    setIsLoading(true);
    setError("");
    try {
      const res = await api.get<FeedbackItem[]>("/feedback/");
      setFeedbacks(res.data);
    } catch (err: any) {
      setError(err.response?.data?.detail || "Erro ao carregar feedbacks dos estudantes.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFeedbacks();
  }, []);

  const openValidationModal = (f: FeedbackItem) => {
    setSelectedFeedback(f);
    setDecision(f.needs_review ? "adjust" : "confirm");
    setJustification("");
    setAdjustedAnswer(f.answer_context || "");
    setSuccessMsg("");
  };

  const handleSubmitValidation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFeedback || !selectedFeedback.message_id) return;
    setIsSubmitting(true);
    setError("");

    try {
      await api.post("/agent/validations", {
        message_id: selectedFeedback.message_id,
        decision,
        justification,
        adjusted_answer:
          decision === "adjust" || decision === "complement" ? adjustedAnswer : undefined,
        response_version: "1.0",
      });
      setSuccessMsg("Validação humana RF08 registrada com sucesso.");
      setSelectedFeedback(null);
      await fetchFeedbacks();
    } catch (err: any) {
      setError(err.response?.data?.detail || "Falha ao registrar validação humana.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const displayedFeedbacks = filterReview
    ? feedbacks.filter((f) => f.needs_review)
    : feedbacks;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header />

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        <AdminSidebar />

        <main className="flex-1 p-4 md:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-xl font-bold text-gray-900">Avaliações dos Estudantes</h1>
              <p className="text-xs text-gray-500">
                Feedbacks reais recebidos para melhoria contínua e validação humana (RF08).
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setFilterReview(!filterReview)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
                  filterReview
                    ? "bg-red-600 text-white border-red-600"
                    : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                }`}
              >
                {filterReview ? "Mostrando: Requerem Revisão" : "Filtrar: Requerem Revisão"}
              </button>
              <button
                onClick={fetchFeedbacks}
                disabled={isLoading}
                className="p-2 rounded-xl bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
                title="Atualizar"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
              </button>
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-2 text-xs text-emerald-700">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {selectedFeedback && (
            <form
              onSubmit={handleSubmitValidation}
              className="bg-white p-5 rounded-2xl border-2 border-primary-500 shadow-sm space-y-4"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                <h3 className="text-sm font-bold text-gray-900">
                  Validação Humana RF08 — Resposta Avaliada
                </h3>
                <button
                  type="button"
                  onClick={() => setSelectedFeedback(null)}
                  className="text-xs text-gray-400 hover:text-gray-600"
                >
                  Fechar
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Decisão sobre a Resposta do Agente
                </label>
                <select
                  value={decision}
                  onChange={(e) => setDecision(e.target.value as ValidationDecision)}
                  className="input-field py-2 text-xs w-full"
                >
                  <option value="confirm">Confirmar resposta original</option>
                  <option value="adjust">Ajustar resposta</option>
                  <option value="complement">Complementar resposta</option>
                  <option value="reject">Rejeitar resposta</option>
                </select>
              </div>

              {(decision === "adjust" || decision === "complement") && (
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Texto da Resposta Revisada
                  </label>
                  <textarea
                    value={adjustedAnswer}
                    onChange={(e) => setAdjustedAnswer(e.target.value)}
                    rows={3}
                    className="w-full input-field py-2 text-xs"
                    required
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Justificativa {decision !== "confirm" && "*"}
                </label>
                <input
                  type="text"
                  value={justification}
                  onChange={(e) => setJustification(e.target.value)}
                  className="w-full input-field py-2 text-xs"
                  placeholder="Informe a justificativa técnica ou normativa..."
                  required={decision !== "confirm"}
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedFeedback(null)}
                >
                  Cancelar
                </Button>
                <Button type="submit" size="sm" isLoading={isSubmitting}>
                  Salvar Validação RF08
                </Button>
              </div>
            </form>
          )}

          <div className="space-y-3">
            {isLoading ? (
              <div className="bg-white p-6 rounded-2xl border border-gray-100 text-center text-xs text-gray-400">
                Carregando avaliações...
              </div>
            ) : displayedFeedbacks.length === 0 ? (
              <div className="bg-white p-6 rounded-2xl border border-gray-100 text-center text-xs text-gray-400">
                Nenhum feedback encontrado para o filtro selecionado.
              </div>
            ) : (
              displayedFeedbacks.map((f) => {
                const isPos = f.rating === "positive" || (f.rating_value && f.rating_value >= 4);
                return (
                  <div
                    key={f.id}
                    className="bg-white p-4 rounded-2xl border border-gray-100 shadow-xs space-y-2"
                  >
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <Badge variant={isPos ? "success" : "danger"}>
                          {isPos ? "Resolveu 👍" : "Não resolveu 👎"}
                        </Badge>
                        {f.needs_review && (
                          <Badge variant="warning">Requer Revisão</Badge>
                        )}
                      </div>
                      <span className="text-[11px] text-gray-400">
                        {new Date(f.created_at).toLocaleString("pt-BR")}
                      </span>
                    </div>

                    {f.comment && (
                      <p className="text-xs text-gray-800 italic">"{f.comment}"</p>
                    )}

                    {f.question_context && (
                      <p className="text-[11px] text-gray-500">
                        <strong>Pergunta:</strong> {f.question_context}
                      </p>
                    )}

                    {f.answer_context && (
                      <p className="text-[11px] text-gray-500 line-clamp-2">
                        <strong>Resposta do Agente:</strong> {f.answer_context}
                      </p>
                    )}

                    {f.message_id && (
                      <div className="pt-2 flex justify-end">
                        <button
                          onClick={() => openValidationModal(f)}
                          className="inline-flex items-center gap-1 px-3 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-gray-700"
                        >
                          <Edit3 className="w-3.5 h-3.5" /> Validar Resposta (RF08)
                        </button>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </main>
      </div>
    </div>
  );
};