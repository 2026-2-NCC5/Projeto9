import React, { useState, useRef, useEffect } from "react";
import {
  Send,
  Sparkles,
  Search,
  FileText,
  CreditCard,
  Calendar,
  GraduationCap,
  Download,
  ThumbsUp,
  ThumbsDown,
  Clock,
  ShieldCheck,
  UserCheck,
  TrendingUp,
  Bot,
  User,
  LogOut,
  Headphones,
  CheckCircle2,
  AlertCircle,
  BarChart3,
  HelpCircle,
  ExternalLink,
  BookOpen,
  ArrowRight,
  MessageSquare,
  Plus,
  Edit3,
  Check,
  X,
  RotateCcw,
  UploadCloud,
  CheckSquare,
  AlertTriangle,
  Copy,
  Paperclip,
  Star,
  FileDown,
  Layers,
  MessageCircle,
  FileCheck2,
  Users
} from "lucide-react";
import { api } from "@/services/api";
import {
  buildSimulatedHumanReply,
  extractRelevantSubjectQuery,
  getSimulatedAttendantName,
} from "@/services/humanSupportSimulator";
import { downloadDemoPdfDocument } from "@/services/pdfDownloadService";
import { classifySubject, categoryForLabel } from "@/services/subjectClassifier";
import { detectBoletoIntent } from "@/services/boletoIntent";
import { BoletoPicker } from "@/components/BoletoPicker";

// Official FECAP Logo Component
function FecapLogo({ size = "md", className = "" }: { size?: "sm" | "md" | "lg"; className?: string }) {
  const sizeClasses = {
    sm: "px-2 py-0.5 text-xs rounded-md",
    md: "px-2.5 py-1 text-sm rounded-lg shadow-sm",
    lg: "px-4 py-2 text-xl rounded-xl shadow-md",
  };

  return (
    <div
      className={`bg-[#00E676] text-[#002B18] font-black italic tracking-tighter inline-flex items-center justify-center select-none border border-[#00C853]/40 ${sizeClasses[size]} ${className}`}
      title="FECAP — Fundação Escola de Comércio Álvares Penteado"
    >
      <span className="transform -skew-x-6 tracking-tight leading-none font-sans">
        FECAP
      </span>
    </div>
  );
}

// Data Interfaces
type Screen = "login" | "student" | "admin";
type AdminTab = "overview" | "queue" | "knowledge" | "feedbacks";

interface Message {
  id: string;
  sender: "user" | "bot" | "human";
  agentName?: string;
  text: string;
  time: string;
  steps?: string[];
  links?: Array<{ label: string; url: string }>;
  citation?: string;
  updatedAt?: string;
  hasDownload?: boolean;
  downloadTitle?: string;
  downloadSize?: string;
  attachedFile?: string;
  feedback?: "up" | "down" | null;
  allowTransfer?: boolean;
  boletoWidget?: { preselectMonth?: number };
  offerCloseAction?: boolean;
  protocol?: string;
  conversationId?: string;
}

interface QueueTicket {
  id: string;
  protocol: string;
  conversationId?: string;
  studentName: string;
  ra: string;
  subject: string;
  studentQuestion: string;
  aiDraft: string;
  priority: "Alta" | "Média" | "Baixa";
  status: "Pendente" | "Aprovado" | "Ajustado" | "Rejeitado";
  time: string;
  transferReason?: string;
  justification?: string;
  finalResponse?: string;
}

interface KnowledgeDoc {
  id: string;
  title: string;
  category: string;
  version: string;
  updatedAt: string;
  chunks: number;
  active: boolean;
}

interface FeedbackItem {
  id: string;
  student: string;
  type: "human_service" | "bot_response";
  queryOrSubject: string;
  ratingStars?: number;
  ratingType?: "positive" | "negative";
  reason?: string;
  comment: string;
  date: string;
  status: "Analisado" | "Pendente Ajuste";
}

export default function App() {
  // Screen & Auth State
  const [currentScreen, setCurrentScreen] = useState<Screen>("student");
  const [loginProfile, setLoginProfile] = useState<"student" | "admin">("student");
  const [emailInput, setEmailInput] = useState("ana.silva@fecap.br");
  const [passwordInput, setPasswordInput] = useState("••••••••");

  // Demo Mode & Conversation Context State
  const [isDemoMode, setIsDemoMode] = useState<boolean>(true);
  const [activeConversationId, setActiveConversationId] = useState<string>(() => `conv-${Date.now()}`);
  const [currentSubject, setCurrentSubject] = useState<string>("Dúvida de Matrícula ou Requerimento");
  const [humanTurnCount, setHumanTurnCount] = useState<number>(0);

  // Student Chat State
  const [isHumanConnected, setIsHumanConnected] = useState(false);
  const [currentProtocol, setCurrentProtocol] = useState<string | null>(null);
  const [inputVal, setInputVal] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [typingLabel, setTypingLabel] = useState("IA pesquisando no Regimento...");
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // File Attachment State (Simulation)
  const [attachedFileName, setAttachedFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handover Modal State
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferReason, setTransferReason] = useState("Dúvida de Matrícula ou Requerimento");
  const [transferCustomNote, setTransferCustomNote] = useState("");

  // Negative Feedback Modal State
  const [feedbackModalMessageId, setFeedbackModalMessageId] = useState<string | null>(null);
  const [feedbackReason, setFeedbackReason] = useState("Informação incompleta");
  const [feedbackCustomComment, setFeedbackCustomComment] = useState("");

  // Satisfaction Survey Modal State (1 to 5 Stars on Closing Human Service)
  const [isSurveyModalOpen, setIsSurveyModalOpen] = useState(false);
  const [surveyRating, setSurveyRating] = useState<number>(5);
  const [surveyHoverRating, setSurveyHoverRating] = useState<number>(0);
  const [surveyComment, setSurveyComment] = useState("");

  // Messages Thread
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      sender: "bot",
      text: "Olá, Ana! Sou a SecretarIA, sua agente inteligente oficial da Secretaria Acadêmica (ASA/FECAP). Como posso orientar sua vida acadêmica hoje com base nas diretrizes oficiais?",
      time: "10:00",
      citation: "Secretaria Geral & Regimento Acadêmico FECAP 2026",
      updatedAt: "15/08/2026",
      allowTransfer: true,
    },
    {
      id: "2",
      sender: "user",
      text: "Como emitir meu comprovante de matrícula para o semestre vigente?",
      time: "10:01",
    },
    {
      id: "3",
      sender: "bot",
      text: "A Declaração e Comprovante de Matrícula estão disponíveis para consulta e emissão no Portal do Aluno (ambiente de demonstração acadêmica).",
      time: "10:01",
      citation: "Regimento Geral FECAP — Título IV, Cap. II (Emissão de Documentos)",
      updatedAt: "15/08/2026",
      steps: [
        "Acesse o Portal do Aluno com seu RA (202612345) e senha institucional.",
        "No menu lateral, selecione 'Documentos' > 'Declaração de Matrícula'.",
        "Selecione o semestre '2026/1' para solicitar o documento.",
        "Abaixo você pode baixar um modelo demonstrativo em PDF (fictício, sem validade oficial).",
      ],
      links: [
        { label: "Acessar Portal do Aluno", url: "#" },
        { label: "Baixar Modelo Demonstrativo (.PDF)", url: "#" },
      ],
      hasDownload: true,
      downloadTitle: "Comprovante_Matricula_2026_1_FECAP.pdf",
      downloadSize: "148 KB",
      allowTransfer: true,
    },
  ]);

  // Admin Dashboard State
  const [adminTab, setAdminTab] = useState<AdminTab>("overview");

  // Queue State
  const [queue, setQueue] = useState<QueueTicket[]>([
    {
      id: "TICK-101",
      protocol: "#PROTOCOLO-2026-8840",
      studentName: "Lucas Ferreira",
      ra: "202598712",
      subject: "Negociação de Mensalidade Atrasada & Acordo PIX",
      studentQuestion: "Gostaria de saber como parcelar boletos em atraso da mensalidade de fevereiro.",
      aiDraft: "A Central de Negociação Financeira oferece opções de parcelamento via Portal > Financeiro > Acordos.",
      priority: "Alta",
      status: "Pendente",
      time: "10:35",
      transferReason: "Questão financeira complexa",
    },
    {
      id: "TICK-102",
      protocol: "#PROTOCOLO-2026-8841",
      studentName: "Mariana Costa",
      ra: "202634120",
      subject: "Aproveitamento de Disciplinas Externas (Transferência)",
      studentQuestion: "Como solicitar equivalência de matérias que cursei em outra faculdade?",
      aiDraft: "O protocolo de equivalência curricular deve ser submetido com histórico e ementas autenticadas até 20/03.",
      priority: "Média",
      status: "Pendente",
      time: "10:18",
      transferReason: "Análise de histórico externo",
    },
    {
      id: "TICK-103",
      protocol: "#PROTOCOLO-2026-8839",
      studentName: "Felipe Rocha",
      ra: "202411098",
      subject: "Quebra de Pré-Requisito em Contabilidade Geral",
      studentQuestion: "Posso cursar Contabilidade II sem ter concluído Contabilidade I?",
      aiDraft: "Quebras de pré-requisito são analisadas pela coordenação mediante requerimento justificado.",
      priority: "Média",
      status: "Pendente",
      time: "09:55",
      transferReason: "Requerimento especial à coordenação",
    },
  ]);

  // Modal State for Validation
  const [selectedTicket, setSelectedTicket] = useState<QueueTicket | null>(null);
  const [validationDecision, setValidationDecision] = useState<"aprovar" | "ajustar" | "rejeitar">("aprovar");
  const [justificationInput, setJustificationInput] = useState("");
  const [adjustedResponseInput, setAdjustedResponseInput] = useState("");

  // Knowledge Base State
  const [knowledgeDocs, setKnowledgeDocs] = useState<KnowledgeDoc[]>([
    { id: "DOC-1", title: "Regimento_Geral_FECAP_2026.pdf", category: "Secretaria Geral", version: "v2.4", updatedAt: "15/08/2026", chunks: 342, active: true },
    { id: "DOC-2", title: "Manual_do_Estudante_Graduacao_2026.pdf", category: "Acadêmico", version: "v1.8", updatedAt: "10/08/2026", chunks: 180, active: true },
    { id: "DOC-3", title: "Calendario_Academico_Oficial_2026_1.pdf", category: "Pró-Reitoria", version: "v1.2", updatedAt: "01/08/2026", chunks: 45, active: true },
    { id: "DOC-4", title: "Manual_Normas_AACC_Horas_Complementares.pdf", category: "Coordenações", version: "v1.5", updatedAt: "12/07/2026", chunks: 64, active: true },
    { id: "DOC-5", title: "Politica_Descontos_e_Bolsas_2026.pdf", category: "Financeiro", version: "v3.0", updatedAt: "05/01/2026", chunks: 52, active: false },
  ]);

  const [versionModalDoc, setVersionModalDoc] = useState<KnowledgeDoc | null>(null);
  const [newVersionString, setNewVersionString] = useState("");
  const [newDocModalOpen, setNewDocModalOpen] = useState(false);
  const [newDocTitle, setNewDocTitle] = useState("");
  const [newDocCategory, setNewDocCategory] = useState("Secretaria Geral");

  // Feedback State
  const [feedbacks, setFeedbacks] = useState<FeedbackItem[]>([
    {
      id: "FB-101",
      student: "Ana Silva",
      type: "human_service",
      queryOrSubject: "Atendimento Protocolo #PROTOCOLO-2026-8820 (Secretaria)",
      ratingStars: 5,
      comment: "Atendimento excepcional pelo Orientador Carlos, esclareceu todos os passos do trancamento com muita agilidade!",
      date: "Hoje às 10:20",
      status: "Analisado",
    },
    {
      id: "FB-102",
      student: "Lucas Ferreira",
      type: "human_service",
      queryOrSubject: "Negociação Financeira e Emissão de Boleto",
      ratingStars: 5,
      comment: "Muito prestativo, enviou a 2ª via atualizada na hora.",
      date: "Hoje às 09:45",
      status: "Analisado",
    },
    {
      id: "FB-1",
      student: "Ana Silva",
      type: "bot_response",
      queryOrSubject: "Emissão de comprovante de matrícula",
      ratingType: "positive",
      comment: "Instruções claras e link direto muito prático!",
      date: "Hoje às 10:05",
      status: "Analisado",
    },
    {
      id: "FB-2",
      student: "Guilherme Santos",
      type: "bot_response",
      queryOrSubject: "Segunda via de boleto",
      ratingType: "positive",
      comment: "Excelente, consegui gerar o PIX em segundos.",
      date: "Hoje às 09:30",
      status: "Analisado",
    },
    {
      id: "FB-3",
      student: "Carla Mendes",
      type: "bot_response",
      queryOrSubject: "Dispensa de disciplina",
      ratingType: "negative",
      reason: "Informação incompleta",
      comment: "Não especificou a lista de documentos necessários para transferência.",
      date: "Ontem às 16:40",
      status: "Pendente Ajuste",
    },
  ]);

  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (currentScreen === "student") {
      scrollToBottom();
    }
  }, [messages, isTyping, currentScreen]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Export Conversation History
  const handleExportHistory = () => {
    const header = `SecretarIA — Histórico de Atendimento Acadêmico\nEstudante: Ana Silva (RA: 202612345)\nData de Exportação: ${new Date().toLocaleString()}\n` + "=".repeat(60) + "\n\n";
    const body = messages
      .map((m) => `[${m.time}] ${m.sender === "user" ? "Ana" : m.agentName || "SecretarIA"}:\n${m.text}${m.steps ? "\nPasso a passo:\n" + m.steps.map((s, i) => `${i + 1}. ${s}`).join("\n") : ""}${m.citation ? "\nFonte: " + m.citation : ""}\n`)
      .join("\n" + "-".repeat(40) + "\n\n");

    const fullContent = header + body;
    const blob = new Blob([fullContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `Historico_Atendimento_FECAP_${Date.now()}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showToast("Histórico completo da conversa exportado com sucesso!");
  };

  const [downloadingDocTitle, setDownloadingDocTitle] = useState<string | null>(null);

  // Copy Message to Clipboard
  const handleCopyMessage = (msgId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(msgId);
    showToast("Texto da resposta copiado para a área de transferência!");
    setTimeout(() => setCopiedId(null), 2500);
  };

  // Real PDF Download Handler (via GET /api/v1/documents/download/{docTitle})
  const handleDownloadPdf = async (docTitle?: string) => {
    const targetTitle = (docTitle || "").trim();
    if (!targetTitle) {
      showToast("Erro: nome do documento PDF não informado.");
      return;
    }
    if (downloadingDocTitle === targetTitle) {
      return;
    }

    setDownloadingDocTitle(targetTitle);
    try {
      const result = await downloadDemoPdfDocument(targetTitle);
      if (result.ok) {
        const kb = Math.max(1, Math.round(result.sizeBytes / 1024));
        showToast(
          `Download de "${result.filename}" (${kb} KB) concluído! Documento fictício de demonstração acadêmica.`
        );
      } else {
        showToast(`Não foi possível baixar o PDF: ${result.errorMessage}`);
      }
    } catch {
      showToast("Erro inesperado ao baixar o arquivo PDF.");
    } finally {
      setDownloadingDocTitle(null);
    }
  };

  // Handle Simulated Attachment
  const handleFileAttach = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAttachedFileName(file.name);
      showToast(`Arquivo "${file.name}" anexado à mensagem.`);
    }
  };

  useEffect(() => {
    fetch("/health")
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (data && typeof data.demo_mode === "boolean") {
          setIsDemoMode(data.demo_mode);
        }
      })
      .catch(() => {
        setIsDemoMode(true);
      });
  }, []);

  // Handle Send Message
  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputVal).trim();
    if (!text && !attachedFileName) return;

    const fullUserText = text || (attachedFileName ? `Envio de documento anexo: ${attachedFileName}` : "");
    const attached = attachedFileName || undefined;

    const lastHumanMsg = [...messages].reverse().find((m) => m.sender === "human")?.text;

    const userMsg: Message = {
      id: String(Date.now()),
      sender: "user",
      text: fullUserText,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      attachedFile: attached,
      protocol: currentProtocol || undefined,
      conversationId: activeConversationId,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal("");
    setAttachedFileName(null);
    setIsTyping(true);
    setTypingLabel(
      isHumanConnected
        ? `${isDemoMode ? "Orientador Carlos (SIMULADO)" : "Orientador Carlos"} está redigindo a resposta...`
        : "IA pesquisando no Regimento Oficial..."
    );

    setTimeout(async () => {
      setIsTyping(false);

      if (isHumanConnected) {
        const simResult = buildSimulatedHumanReply({
          studentName: "Ana",
          userText: fullUserText,
          lastHumanMessageText: lastHumanMsg,
          protocol: currentProtocol || "#PROTOCOLO-2026-8842",
          subject: currentSubject || transferReason,
          conversationId: activeConversationId,
          demoMode: isDemoMode,
          turnCount: humanTurnCount,
        });

        setHumanTurnCount((c) => c + 1);

        const humanMsg: Message = {
          id: String(Date.now() + 1),
          sender: "human",
          agentName: simResult.agentName,
          text: simResult.replyText,
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          offerCloseAction: simResult.shouldOfferClose,
          protocol: simResult.protocol,
          conversationId: simResult.conversationId,
        };
        setMessages((prev) => [...prev, humanMsg]);

        if (simResult.shouldAutoPromptSurvey) {
          setIsSurveyModalOpen(true);
        }
        return;
      }

      // 0. Segunda via de boleto (interface interativa dentro do chat, dados fictícios)
      const boletoIntent = detectBoletoIntent(fullUserText);
      if (boletoIntent.matched) {
        const hasSession = typeof localStorage !== "undefined" && !!localStorage.getItem("access_token");
        const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        setMessages((prev) => [
          ...prev,
          hasSession
            ? {
                id: String(Date.now() + 1),
                sender: "bot",
                text: "Consultei os boletos fictícios da sua conta de demonstração. Selecione o(s) boleto(s) que deseja emitir (segunda via em PDF).",
                time,
                citation: "Financeiro (Ambiente de Demonstração)",
                boletoWidget: { preselectMonth: boletoIntent.month },
                allowTransfer: true,
                conversationId: activeConversationId,
              } as Message
            : {
                id: String(Date.now() + 1),
                sender: "bot",
                text: "Para consultar seus boletos de demonstração, é necessário estar autenticado. Faça login e pergunte novamente.",
                time,
                allowTransfer: true,
                conversationId: activeConversationId,
              },
        ]);
        return;
      }

      // 1. Tenta consultar o Agente RAG real do Backend FastAPI (/api/v1/agent/query)
      try {
        const ragRes = await api.post("/agent/query", {
          question: fullUserText,
          conversation_id: activeConversationId.startsWith("conv-") ? undefined : activeConversationId,
        });

        if (ragRes.status === 200 && ragRes.data?.answer) {
          const data = ragRes.data;
          if (data.conversation_id) {
            setActiveConversationId(data.conversation_id);
          }
          setMessages((prev) => [
            ...prev,
            {
              id: data.id || String(Date.now() + 1),
              sender: "bot",
              text: data.answer,
              time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
              citation:
                Array.isArray(data.evidence) && data.evidence.length > 0
                  ? Array.from(new Set<string>(data.evidence.map((e: { document: string }) => e.document))).join("; ")
                  : data.source || "Secretaria Acadêmica (Base de Demonstração)",
              updatedAt: "01/11/2026",
              steps: data.steps || undefined,
              allowTransfer: true,
              conversationId: data.conversation_id || activeConversationId,
            },
          ]);
          return;
        }
      } catch (err) {
        console.warn("Falha ao consultar o Agente RAG (/agent/query). Tentando contingência:", err);
      }

      // 2. Chamada para API Backend Serverless (/api/v1/chat)
      try {
        const res = await fetch("/api/v1/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ user_id: "202612345", message: fullUserText }),
        });

        if (res.ok) {
          const data = await res.json();
          setMessages((prev) => [
            ...prev,
            {
              id: String(Date.now() + 1),
              sender: "bot",
              text: data.reply,
              time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
              citation: data.source || "Regimento Geral ASA / Secretaria Geral FECAP",
              updatedAt: data.updated_at || "25/09/2026",
              steps: data.steps || undefined,
              links: data.links || undefined,
              hasDownload: data.has_download || false,
              downloadTitle: data.download_title || "",
              downloadSize: data.download_size || "",
              allowTransfer: true,
              conversationId: activeConversationId,
            },
          ]);
          return;
        }
      } catch (err) {
        console.warn("Backend API offline ou erro de rede. Utilizando RAG local de contingência:", err);
      }

      // Fallback RAG Local
      const lower = fullUserText.toLowerCase();
      let replyText = "Não encontrei essa informação na documentação disponível nesta demonstração. Posso encaminhar você para atendimento humano (simulado) para continuar sua solicitação.";
      let citation = "Regimento Geral ASA / Secretaria Geral FECAP";
      let updatedAt = "25/09/2026";
      let steps: string[] | undefined;
      let links: Array<{ label: string; url: string }> | undefined;
      let hasDownload = false;
      let downloadTitle = "";
      let downloadSize = "";

      if (lower.includes("boleto") || lower.includes("mensalidade") || lower.includes("financeiro") || lower.includes("2ª via") || lower.includes("segunda via")) {
        replyText = "A 2ª via do seu boleto ou a chave de pagamento PIX institucional podem ser emitidas diretamente pelo Portal do Aluno:";
        citation = "Regimento Geral ASA / Secretaria Geral FECAP — Art. 11";
        updatedAt = "25/09/2026";
        steps = [
          "Acesse Portal do Aluno > Menu Financeiro > Boletos e Mensalidades.",
          "Localize a parcela do mês vigente e selecione 'Gerar Código de Barras' ou 'Pagar com PIX'.",
          "A compensação bancária é reconhecida automaticamente em até 24 horas úteis.",
        ];
        links = [
          { label: "Abrir Central Financeira FECAP", url: "#" },
          { label: "Solicitar Recibo de Quitação", url: "#" },
        ];
        hasDownload = true;
        downloadTitle = "Boleto_Mensalidade_Marco_2026.pdf";
        downloadSize = "215 KB";
      } else if (lower.includes("histórico") || lower.includes("historico")) {
        replyText = "O Histórico Escolar pode ser solicitado pelo Portal do Aluno (abaixo está disponível um modelo demonstrativo fictício para download):";
        citation = "Regimento Geral ASA / Secretaria Geral FECAP — Art. 9º";
        updatedAt = "25/09/2026";
        steps = [
          "Acesse Portal do Aluno > Menu Documentos > Histórico Escolar.",
          "Selecione a modalidade de Histórico desejada.",
          "Abaixo você pode baixar o arquivo PDF demonstrativo (sem validade oficial).",
        ];
        links = [
          { label: "Acessar Portal do Aluno", url: "#" },
          { label: "Baixar Modelo de Histórico (.PDF)", url: "#" },
        ];
        hasDownload = true;
        downloadTitle = "Historico_Escolar_Oficial_FECAP.pdf";
        downloadSize = "192 KB";
      } else if (lower.includes("calendário") || lower.includes("calendario") || lower.includes("prazo") || lower.includes("prova") || lower.includes("avaliações") || lower.includes("avaliacoes")) {
        replyText = "O Calendário Acadêmico Demonstrativo de 2026/1 apresenta os períodos de avaliações regimentais (A1 e A2), substitutivas e rematrícula:";
        citation = "Regimento Geral ASA / Secretaria Geral FECAP — Art. 8º";
        updatedAt = "25/09/2026";
        steps = [
          "Período de Avaliações A1: 06 a 11 de Abril de 2026.",
          "Período de Avaliações A2: 08 a 13 de Junho de 2026.",
          "Avaliações Substitutivas: 22 a 26 de Junho de 2026.",
          "Limite para requerimento de Trancamento sem ônus: 30 dias após início letivo.",
        ];
        links = [
          { label: "Baixar Calendário Acadêmico Completo", url: "#" },
        ];
        hasDownload = true;
        downloadTitle = "Calendario_Academico_Graduacao_2026.pdf";
        downloadSize = "520 KB";
      } else if (lower.includes("trancar") || lower.includes("trancamento") || lower.includes("cancelamento")) {
        replyText = "O trancamento voluntário de matrícula é o ato regimental pelo qual o discente suspende temporariamente seus estudos na FECAP:";
        citation = "Regimento Geral ASA / Secretaria Geral FECAP — Cap. I";
        updatedAt = "25/09/2026";
        steps = [
          "Solicitar em até 30 dias do início do semestre letivo sem cobrança de mensalidades vincendas.",
          "Acesse Portal do Aluno > Menu Requerimentos > Solicitação de Trancamento.",
          "Limite máximo continuado de trancamento: 4 semestres letivos.",
        ];
        links = [
          { label: "Abrir Protocolo de Requerimento", url: "#" },
        ];
        hasDownload = true;
        downloadTitle = "Formulario_Trancamento_Matricula_FECAP.pdf";
        downloadSize = "145 KB";
      }

      setMessages((prev) => [
        ...prev,
        {
          id: String(Date.now() + 1),
          sender: "bot",
          text: replyText,
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          citation,
          updatedAt,
          steps,
          links,
          hasDownload,
          downloadTitle,
          downloadSize,
          allowTransfer: true,
          conversationId: activeConversationId,
        },
      ]);
    }, 500);
  };

  // Open Handover Confirmation Modal
  const handleOpenTransferModal = () => {
    if (isHumanConnected) {
      showToast("Você já está em atendimento com um orientador da Secretaria.");
      return;
    }
    const userQs = messages.filter((m) => m.sender === "user").map((m) => m.text);
    const lastQuestion = extractRelevantSubjectQuery(userQs, "");
    const detected = classifySubject(lastQuestion);
    if (detected.matched) {
      setTransferReason(detected.label);
    }
    setIsTransferModalOpen(true);
  };

  // Confirm Handover (Integrado com /api/v1/handoff e fallback /api/v1/handover)
  const handleConfirmTransfer = async () => {
    setIsTransferModalOpen(false);

    const userQuestions = messages.filter((m) => m.sender === "user").map((m) => m.text);
    const relevantQuestion = extractRelevantSubjectQuery(userQuestions, transferReason);
    const resolvedSubject = transferReason || "Orientação Acadêmica";

    let protocolNum = `#PROTOCOLO-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    // 1. Tenta persistir protocolo real no SQLite via /api/v1/handoff/
    try {
      const handoffPayload = {
        conversation_id: activeConversationId.startsWith("conv-") ? undefined : activeConversationId,
        category: categoryForLabel(resolvedSubject),
        priority: "priority",
        reason: `${resolvedSubject} — ${relevantQuestion}${transferCustomNote ? ` (Obs: ${transferCustomNote})` : ""}`,
        summary: `Assunto: ${resolvedSubject} | Pergunta: ${relevantQuestion.slice(0, 120)}`,
      };
      const res = await api.post("/handoff/", handoffPayload);
      if (res.data?.protocol) {
        protocolNum = res.data.protocol;
      }
    } catch {
      // Fallback para endpoint serverless /api/v1/handover
      try {
        fetch("/api/v1/handover", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ user_id: "202612345", reason: resolvedSubject, note: transferCustomNote }),
        }).catch((e) => console.warn("API Handover offline:", e));
      } catch (e) {
        console.warn("Handover fetch error:", e);
      }
    }

    setCurrentProtocol(protocolNum);
    setCurrentSubject(resolvedSubject);
    setHumanTurnCount(0);

    const attendantDisplay = getSimulatedAttendantName(isDemoMode);

    // 1. Mensagem de Confirmação com Protocolo e Assunto vinculados
    const transferNoticeMsg: Message = {
      id: String(Date.now()),
      sender: "bot",
      agentName: "Sistema SecretarIA • Secretaria",
      text:
        `Atendimento encaminhado para a Secretaria Acadêmica${isDemoMode ? " (Ambiente de Simulação / DEMO)" : ""}.\n` +
        `Número de Protocolo: ${protocolNum}\n` +
        `Assunto vinculado: ${resolvedSubject}\n` +
        `Conversa: ${activeConversationId}`,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      citation: "Regimento Geral ASA / Secretaria Geral FECAP",
      updatedAt: "25/09/2026",
      protocol: protocolNum,
      conversationId: activeConversationId,
    };

    setMessages((prev) => [...prev, transferNoticeMsg]);

    // 2. Atualiza badge do topo para orientador conectado
    setIsHumanConnected(true);
    setIsTyping(true);
    setTypingLabel(
      `${isDemoMode ? "Orientador Carlos (SIMULADO)" : "Orientador Carlos"} está conectando ao seu atendimento...`
    );

    // 3. Envia o caso para a Fila do Painel Admin com protocolo, conversa e assunto corretos
    const newTicket: QueueTicket = {
      id: `TICK-${Date.now().toString().slice(-3)}`,
      protocol: protocolNum,
      conversationId: activeConversationId,
      studentName: "Ana Silva",
      ra: "202612345",
      subject: resolvedSubject,
      studentQuestion: relevantQuestion + (transferCustomNote ? ` (Obs: ${transferCustomNote})` : ""),
      aiDraft: "Estudante solicitou transbordo para atendimento humano presencial/online.",
      priority: "Alta",
      status: "Pendente",
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      transferReason: resolvedSubject,
    };
    setQueue((prev) => [newTicket, ...prev]);

    // 4. Conectar orientador humano simulado
    setTimeout(() => {
      setIsTyping(false);
      const demoTag = isDemoMode
        ? " (Orientador Humano SIMULADO — Modo Demonstração: este atendimento não altera registros reais na FECAP)"
        : "";
      const humanMsg: Message = {
        id: String(Date.now() + 1),
        sender: "human",
        agentName: attendantDisplay,
        text:
          `Olá, Ana! Aqui é o Carlos da Secretaria Acadêmica${demoTag}. ` +
          `Assumi seu protocolo ${protocolNum} referente a "${resolvedSubject}" (Dúvida: "${relevantQuestion}"). ` +
          `Como posso apoiar você com essa orientação?`,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        protocol: protocolNum,
        conversationId: activeConversationId,
      };
      setMessages((prev) => [...prev, humanMsg]);
      setTransferCustomNote("");
      showToast(`Protocolo ${protocolNum} gerado e vinculado ao assunto "${resolvedSubject}"!`);
    }, 1200);
  };

  // Trigger Closing Human Service
  const handleOpenSurveyModal = () => {
    setIsSurveyModalOpen(true);
  };

  // Submit Satisfaction Survey & Restore AI Agent
  const handleSubmitSurvey = (e: React.FormEvent) => {
    e.preventDefault();
    const closedProtocol = currentProtocol || "#PROTOCOLO-2026-8842";
    const closedSubject = currentSubject || transferReason;

    setIsSurveyModalOpen(false);
    setIsHumanConnected(false);
    setIsTyping(false);
    setTypingLabel("IA pesquisando no Regimento Oficial...");

    // Integração com Backend API (Encerramento do Protocolo + Registro de Feedback)
    if (closedProtocol && closedProtocol.startsWith("FECAP-")) {
      api.post(`/handoff/${closedProtocol}/close`).catch(() => {});
    }
    try {
      fetch("/api/v1/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: "202612345",
          rating: surveyRating,
          comment:
            surveyComment ||
            `Avaliação de ${surveyRating} estrelas registrada para o protocolo ${closedProtocol} (${closedSubject}).`,
        }),
      }).catch((err) => console.warn("API Feedback offline:", err));
    } catch (err) {
      console.warn("Feedback fetch error:", err);
    }

    // Add Survey to Admin Feedbacks vinculado ao protocolo e assunto corretos
    const newFeedback: FeedbackItem = {
      id: `FB-${Date.now().toString().slice(-3)}`,
      student: "Ana Silva",
      type: "human_service",
      queryOrSubject: `Atendimento ${closedProtocol} — ${closedSubject}`,
      ratingStars: surveyRating,
      comment:
        surveyComment ||
        `Avaliação de ${surveyRating} estrelas registrada após encerramento do atendimento simulado (${closedProtocol}).`,
      date: "Agora mesmo",
      status: "Analisado",
    };
    setFeedbacks((prev) => [newFeedback, ...prev]);

    // Add Closing Message to Chat confirming AI Agent restoration
    const closeNoticeMsg: Message = {
      id: String(Date.now()),
      sender: "bot",
      agentName: "Sistema SecretarIA",
      text:
        `Atendimento humano${isDemoMode ? " simulado" : ""} (${closedProtocol} — ${closedSubject}) encerrado com sucesso. ` +
        `Sua avaliação de ${surveyRating} estrela${surveyRating > 1 ? "s" : ""} foi registrada.\n` +
        `O assistente virtual com IA e base oficial da FECAP está ativo novamente para novas orientações.`,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      citation: "Regimento Geral ASA / Secretaria Geral FECAP",
      updatedAt: "25/09/2026",
      allowTransfer: true,
      protocol: closedProtocol,
      conversationId: activeConversationId,
    };
    setMessages((prev) => [...prev, closeNoticeMsg]);

    setCurrentProtocol(null);
    setHumanTurnCount(0);
    setSurveyComment("");
    setSurveyRating(5);
    showToast("Atendimento finalizado e Agente de IA reativado!");
  };

  // Feedback Toggle for Bot Responses
  const handleFeedbackClick = (msgId: string, type: "up" | "down") => {
    if (type === "down") {
      setFeedbackModalMessageId(msgId);
      return;
    }

    setMessages((prev) =>
      prev.map((m) => {
        if (m.id === msgId) {
          showToast("Obrigado pelo feedback positivo! Isso aprimora a precisão da SecretarIA.");
          setFeedbacks((fPrev) => [
            {
              id: `FB-${Date.now().toString().slice(-3)}`,
              student: "Ana Silva",
              type: "bot_response",
              queryOrSubject: m.text.slice(0, 45) + "...",
              ratingType: "positive",
              comment: "Orientação aprovada pelo estudante.",
              date: "Agora mesmo",
              status: "Analisado",
            },
            ...fPrev,
          ]);
          return { ...m, feedback: "up" };
        }
        return m;
      })
    );
  };

  // Submit Negative Feedback for Bot
  const handleSubmitNegativeFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackModalMessageId) return;

    setMessages((prev) =>
      prev.map((m) => {
        if (m.id === feedbackModalMessageId) {
          setFeedbacks((fPrev) => [
            {
              id: `FB-${Date.now().toString().slice(-3)}`,
              student: "Ana Silva",
              type: "bot_response",
              queryOrSubject: m.text.slice(0, 45) + "...",
              ratingType: "negative",
              reason: feedbackReason,
              comment: feedbackCustomComment || feedbackReason,
              date: "Agora mesmo",
              status: "Pendente Ajuste",
            },
            ...fPrev,
          ]);
          return { ...m, feedback: "down" };
        }
        return m;
      })
    );

    showToast("Feedback registrado! Nossa equipe pedagógica revisará este conteúdo.");
    setFeedbackModalMessageId(null);
    setFeedbackCustomComment("");
  };

  // Queue Modal Actions
  const openTicketModal = (ticket: QueueTicket) => {
    setSelectedTicket(ticket);
    setValidationDecision("aprovar");
    setJustificationInput("");
    setAdjustedResponseInput(ticket.aiDraft);
  };

  const handleConcludeTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket) return;
    if (!justificationInput.trim()) {
      showToast("O campo 'Justificativa do Atendente' é obrigatório.");
      return;
    }

    const statusMap = {
      aprovar: "Aprovado" as const,
      ajustar: "Ajustado" as const,
      rejeitar: "Rejeitado" as const,
    };

    setQueue((prev) =>
      prev.map((item) => {
        if (item.id === selectedTicket.id) {
          return {
            ...item,
            status: statusMap[validationDecision],
            justification: justificationInput,
            finalResponse: validationDecision === "ajustar" ? adjustedResponseInput : item.aiDraft,
          };
        }
        return item;
      })
    );

    showToast(`Atendimento ${selectedTicket.protocol} concluído com parecer: ${statusMap[validationDecision]}!`);
    setSelectedTicket(null);
  };

  // Knowledge Base Actions
  const handleToggleDoc = (docId: string) => {
    setKnowledgeDocs((prev) =>
      prev.map((doc) => {
        if (doc.id === docId) {
          const nextState = !doc.active;
          showToast(`Documento "${doc.title}" ${nextState ? "ativado" : "desativado"}.`);
          return { ...doc, active: nextState };
        }
        return doc;
      })
    );
  };

  const openVersionModal = (doc: KnowledgeDoc) => {
    setVersionModalDoc(doc);
    setNewVersionString(`v${(parseFloat(doc.version.replace("v", "")) + 0.1).toFixed(1)}`);
  };

  const handleSaveVersion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!versionModalDoc || !newVersionString.trim()) return;

    setKnowledgeDocs((prev) =>
      prev.map((doc) => {
        if (doc.id === versionModalDoc.id) {
          return {
            ...doc,
            version: newVersionString.trim(),
            updatedAt: "Hoje (Atualizado)",
          };
        }
        return doc;
      })
    );

    showToast(`Versão do documento "${versionModalDoc.title}" atualizada para ${newVersionString}!`);
    setVersionModalDoc(null);
  };

  const handleAddDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle.trim()) return;

    const newDoc: KnowledgeDoc = {
      id: `DOC-${Date.now().toString().slice(-3)}`,
      title: newDocTitle.trim().endsWith(".pdf") ? newDocTitle.trim() : `${newDocTitle.trim()}.pdf`,
      category: newDocCategory,
      version: "v1.0",
      updatedAt: "Hoje",
      chunks: 65,
      active: true,
    };

    setKnowledgeDocs((prev) => [newDoc, ...prev]);
    setNewDocModalOpen(false);
    setNewDocTitle("");
    showToast(`Documento "${newDoc.title}" cadastrado com sucesso!`);
  };

  // ==========================================
  // VIEW 1: LOGIN
  // ==========================================
  if (currentScreen === "login") {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex flex-col justify-between font-sans text-slate-900">
        <header className="w-full bg-white border-b border-slate-200 py-3.5 px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <FecapLogo size="md" />
            <div className="border-l border-slate-300 pl-3">
              <span className="font-bold text-slate-900 text-sm tracking-tight">SecretarIA</span>
              <span className="text-xs text-emerald-800 ml-2 font-medium">Portal de Orientação</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setLoginProfile("student");
                setCurrentScreen("student");
              }}
              className="text-xs font-semibold text-emerald-800 hover:text-emerald-950 px-3 py-1.5 rounded-lg border border-emerald-300 bg-emerald-50 transition-colors cursor-pointer"
            >
              Demo: Estudante
            </button>
            <button
              onClick={() => {
                setLoginProfile("admin");
                setCurrentScreen("admin");
              }}
              className="text-xs font-semibold text-slate-700 hover:text-slate-900 px-3 py-1.5 rounded-lg border border-slate-300 bg-white transition-colors cursor-pointer"
            >
              Demo: Atendente / Admin
            </button>
          </div>
        </header>

        <main className="flex-1 flex items-center justify-center p-4 sm:p-6">
          <div className="bg-white border border-slate-200 rounded-2xl shadow-xl max-w-md w-full p-8 transition-all">
            <div className="text-center mb-6">
              <div className="inline-flex justify-center mb-3">
                <FecapLogo size="lg" />
              </div>
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                SecretarIA
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                Agente Inteligente de Orientação ao Estudante
              </p>
            </div>

            <div className="bg-slate-100 p-1 rounded-xl flex items-center mb-6 border border-slate-200">
              <button
                type="button"
                onClick={() => {
                  setLoginProfile("student");
                  setEmailInput("ana.silva@fecap.br");
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                  loginProfile === "student"
                    ? "bg-[#004D34] text-white shadow-sm"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                Estudante
              </button>
              <button
                type="button"
                onClick={() => {
                  setLoginProfile("admin");
                  setEmailInput("admin@fecap.br");
                }}
                className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                  loginProfile === "admin"
                    ? "bg-[#004D34] text-white shadow-sm"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                Administrador / Atendente
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                setCurrentScreen(loginProfile === "student" ? "student" : "admin");
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  {loginProfile === "student" ? "R.A. ou E-mail Institucional (@fecap.br)" : "E-mail Corporativo (@fecap.br)"}
                </label>
                <input
                  type="text"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#059669] focus:bg-white transition-all font-medium"
                  placeholder={loginProfile === "student" ? "ana.silva@fecap.br ou 202612345" : "admin@fecap.br"}
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Senha
                </label>
                <input
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#059669] focus:bg-white transition-all font-medium"
                  placeholder="••••••••"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full mt-2 bg-[#059669] hover:bg-[#004D34] text-white font-bold py-3 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 text-sm cursor-pointer active:scale-[0.99]"
              >
                <span>Acessar Portal</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            <div className="mt-6 pt-4 border-t border-slate-100 text-center">
              <p className="text-xs text-slate-500">
                Acesso institucional com governança e conformidade com a LGPD.
              </p>
            </div>
          </div>
        </main>

        <footer className="w-full py-4 text-center text-xs text-slate-500 border-t border-slate-200 bg-white">
          <p>© 2026 FECAP — Fundação Escola de Comércio Álvares Penteado. Todos os direitos reservados.</p>
        </footer>
      </div>
    );
  }

  // ==========================================
  // VIEW 2: ADMIN / ATENDENTE
  // ==========================================
  if (currentScreen === "admin") {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex flex-col font-sans text-slate-900">
        {toastMessage && (
          <div className="fixed top-20 right-6 z-50 bg-[#004D34] text-white text-xs font-bold px-4 py-3 rounded-xl shadow-lg border border-emerald-500 flex items-center gap-2 animate-bounce">
            <CheckCircle2 className="w-4 h-4 text-[#00E676]" />
            <span>{toastMessage}</span>
          </div>
        )}

        <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
          <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between gap-2">
            <div className="flex items-center gap-4">
              <FecapLogo size="md" />
              <div className="border-l border-slate-200 pl-4">
                <div className="flex items-center gap-2">
                  <h1 className="font-bold text-slate-900 text-sm sm:text-base tracking-tight">SecretarIA</h1>
                  <span className="hidden sm:inline bg-[#004D34] text-emerald-100 text-[11px] font-bold px-2 py-0.5 rounded-md">
                    Painel Administrativo e Gerencial
                  </span>
                </div>
                <p className="text-xs text-slate-500 hidden sm:block">
                  Governança, Fila de Atendimento e Validação do Atendente
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setCurrentScreen("student")}
                className="text-xs font-semibold text-[#004D34] hover:text-[#059669] px-3 py-1.5 rounded-lg border border-emerald-300 bg-emerald-50 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Bot className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Ver como</span> Estudante
              </button>

              <div className="flex items-center gap-2 pl-3 border-l border-slate-200">
                <div className="w-8 h-8 rounded-full bg-[#004D34] text-white flex items-center justify-center font-bold text-xs">
                  CO
                </div>
                <div className="hidden md:block text-left">
                  <div className="text-xs font-bold text-slate-900">Orientador Carlos</div>
                  <div className="text-[10px] text-slate-500">Secretaria Integrada (ASA/FECAP)</div>
                </div>
              </div>

              <button
                onClick={() => setCurrentScreen("login")}
                className="text-slate-500 hover:text-slate-800 p-2 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                title="Sair do Sistema"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 flex gap-4 sm:gap-6 border-t border-slate-100 text-xs font-semibold overflow-x-auto scrollbar-none">
            <button
              onClick={() => setAdminTab("overview")}
              className={`py-2.5 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                adminTab === "overview"
                  ? "border-[#059669] text-[#004D34]"
                  : "border-transparent text-slate-600 hover:text-slate-900"
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              1. Dashboard Gerencial
            </button>
            <button
              onClick={() => setAdminTab("queue")}
              className={`py-2.5 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                adminTab === "queue"
                  ? "border-[#059669] text-[#004D34]"
                  : "border-transparent text-slate-600 hover:text-slate-900"
              }`}
            >
              <Headphones className="w-4 h-4" />
              2. Fila de Atendimento Humano
              <span className="ml-1 bg-emerald-100 text-[#004D34] text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                {queue.filter(q => q.status === "Pendente").length}
              </span>
            </button>
            <button
              onClick={() => setAdminTab("knowledge")}
              className={`py-2.5 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                adminTab === "knowledge"
                  ? "border-[#059669] text-[#004D34]"
                  : "border-transparent text-slate-600 hover:text-slate-900"
              }`}
            >
              <BookOpen className="w-4 h-4" />
              3. Base de Conhecimento Oficial
            </button>
            <button
              onClick={() => setAdminTab("feedbacks")}
              className={`py-2.5 border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                adminTab === "feedbacks"
                  ? "border-[#059669] text-[#004D34]"
                  : "border-transparent text-slate-600 hover:text-slate-900"
              }`}
            >
              <Star className="w-4 h-4 text-emerald-600" />
              4. Avaliações & Feedbacks
            </button>
          </div>
        </header>

        <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 space-y-4 sm:space-y-6">
          {/* TAB 1: DASHBOARD GERENCIAL */}
          {adminTab === "overview" && (
            <>
              <div className="bg-gradient-to-r from-[#004D34] to-[#059669] text-white p-6 rounded-2xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold tracking-tight">Painel de Governança e Métricas Institucionais</h2>
                  <p className="text-emerald-100 text-sm mt-1">
                    Monitoramento contínuo de fundamentação documental, precisão das respostas e contenção de dúvidas.
                  </p>
                </div>
                <div className="flex items-center gap-2 bg-white/10 backdrop-blur-xs px-3.5 py-2 rounded-xl border border-white/20 text-xs font-semibold">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#00E676] animate-pulse"></div>
                  <span>Base Oficial ASA/FECAP Atualizada</span>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3 sm:gap-4">
                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs hover:border-emerald-300 transition-all">
                  <div className="flex items-center justify-between text-slate-500 mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider">Total Orientações</span>
                    <MessageSquare className="w-4 h-4 text-[#059669]" />
                  </div>
                  <div className="text-2xl font-black text-slate-900">142</div>
                  <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-700 mt-1">
                    <TrendingUp className="w-3 h-3" />
                    <span>+18% no período</span>
                  </div>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs hover:border-emerald-300 transition-all">
                  <div className="flex items-center justify-between text-slate-500 mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider">Fundamentadas</span>
                    <ShieldCheck className="w-4 h-4 text-[#059669]" />
                  </div>
                  <div className="text-2xl font-black text-slate-900">90.1%</div>
                  <div className="text-[11px] text-slate-500 mt-1">128 c/ citação oficial</div>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs hover:border-emerald-300 transition-all">
                  <div className="flex items-center justify-between text-slate-500 mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider">Feedback Positivo</span>
                    <ThumbsUp className="w-4 h-4 text-[#059669]" />
                  </div>
                  <div className="text-2xl font-black text-slate-900">94.5%</div>
                  <div className="text-[11px] text-emerald-700 font-bold mt-1">134 aprovações discentes</div>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs hover:border-emerald-300 transition-all">
                  <div className="flex items-center justify-between text-slate-500 mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider">Encaminhamentos</span>
                    <Headphones className="w-4 h-4 text-[#004D34]" />
                  </div>
                  <div className="text-2xl font-black text-slate-900">14</div>
                  <div className="text-[11px] text-slate-500 mt-1">Transbordos para atendente</div>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs hover:border-emerald-300 transition-all">
                  <div className="flex items-center justify-between text-slate-500 mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider">Abstenções da IA</span>
                    <AlertCircle className="w-4 h-4 text-[#059669]" />
                  </div>
                  <div className="text-2xl font-black text-slate-900">5</div>
                  <div className="text-[11px] text-slate-500 mt-1">Contenção por segurança</div>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-xs hover:border-emerald-300 transition-all">
                  <div className="flex items-center justify-between text-slate-500 mb-2">
                    <span className="text-xs font-bold uppercase tracking-wider">Tempo Médio</span>
                    <Clock className="w-4 h-4 text-[#059669]" />
                  </div>
                  <div className="text-2xl font-black text-slate-900">1250ms</div>
                  <div className="text-[11px] text-emerald-700 font-bold mt-1">Latência de resposta</div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-slate-900 text-sm">Categorias Mais Consultadas</h3>
                    <span className="text-xs text-slate-500">Distribuição por setor</span>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-xs font-semibold mb-1">
                        <span className="text-slate-700">Secretaria Acadêmica (Documentos e Matrícula)</span>
                        <span className="text-[#004D34] font-bold">45% (64 consultas)</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                        <div className="bg-[#004D34] h-2.5 rounded-full" style={{ width: "45%" }}></div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-semibold mb-1">
                        <span className="text-slate-700">Financeiro & Bolsas (Boletos, PIX e Prazos)</span>
                        <span className="text-[#059669] font-bold">30% (43 consultas)</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                        <div className="bg-[#059669] h-2.5 rounded-full" style={{ width: "30%" }}></div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-semibold mb-1">
                        <span className="text-slate-700">Biblioteca & Recursos Acadêmicos</span>
                        <span className="text-emerald-500 font-bold">15% (21 consultas)</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                        <div className="bg-emerald-500 h-2.5 rounded-full" style={{ width: "15%" }}></div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-semibold mb-1">
                        <span className="text-slate-700">Estágios, Carreiras & AACC</span>
                        <span className="text-emerald-400 font-bold">10% (14 consultas)</span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                        <div className="bg-emerald-400 h-2.5 rounded-full" style={{ width: "10%" }}></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-slate-900 text-sm">Evolução Diária de Consultas (Últimos 7 dias)</h3>
                    <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md">Total: 142</span>
                  </div>

                  <div className="h-44 flex items-end justify-between gap-2 pt-4 px-2">
                    {[
                      { day: "Seg", val: 18, h: "58%" },
                      { day: "Ter", val: 24, h: "77%" },
                      { day: "Qua", val: 29, h: "93%" },
                      { day: "Qui", val: 31, h: "100%" },
                      { day: "Sex", val: 22, h: "70%" },
                      { day: "Sáb", val: 11, h: "35%" },
                      { day: "Dom", val: 7, h: "22%" },
                    ].map((item, idx) => (
                      <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end">
                        <span className="text-[10px] font-bold text-slate-600">{item.val}</span>
                        <div
                          className="w-full bg-[#059669] hover:bg-[#004D34] rounded-t-md transition-all cursor-pointer"
                          style={{ height: item.h }}
                          title={`${item.day}: ${item.val} consultas`}
                        ></div>
                        <span className="text-[11px] font-semibold text-slate-500">{item.day}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}

          {/* TAB 2: FILA DE ATENDIMENTO HUMANO */}
          {adminTab === "queue" && (
            <div className="space-y-6">
              <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
                <div className="p-4 sm:p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="font-bold text-slate-900 text-base">Fila de Atendimento Humano & Validação</h3>
                    <p className="text-xs text-slate-500">
                      Chamados encaminhados pelo estudante ou retidos para conferência técnica do atendente.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-slate-500 font-medium">Prioridade:</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-800">Alta</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">Média</span>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider">
                      <tr>
                        <th className="py-3.5 px-4">Protocolo / Hora</th>
                        <th className="py-3.5 px-4">Nome do Aluno (RA)</th>
                        <th className="py-3.5 px-4">Assunto / Motivo</th>
                        <th className="py-3.5 px-4">Prioridade</th>
                        <th className="py-3.5 px-4">Status</th>
                        <th className="py-3.5 px-4 text-right">Ação</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {queue.map((ticket) => (
                        <tr key={ticket.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3.5 px-4">
                            <div className="font-mono font-bold text-[#004D34]">{ticket.protocol}</div>
                            <div className="text-[10px] text-slate-400">{ticket.time}</div>
                          </td>
                          <td className="py-3.5 px-4">
                            <div className="font-bold text-slate-900">{ticket.studentName}</div>
                            <div className="text-[11px] text-slate-500">RA: {ticket.ra}</div>
                          </td>
                          <td className="py-3.5 px-4 max-w-xs">
                            <div className="font-medium text-slate-900 truncate">{ticket.subject}</div>
                            <div className="text-[11px] text-slate-500 truncate">{ticket.studentQuestion}</div>
                          </td>
                          <td className="py-3.5 px-4">
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                ticket.priority === "Alta"
                                  ? "bg-red-50 text-red-700 border border-red-200"
                                  : "bg-amber-50 text-amber-700 border border-amber-200"
                              }`}
                            >
                              {ticket.priority}
                            </span>
                          </td>
                          <td className="py-3.5 px-4">
                            <span
                              className={`px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 ${
                                ticket.status === "Pendente"
                                  ? "bg-amber-50 text-amber-800 border border-amber-200"
                                  : "bg-emerald-100 text-emerald-800 border border-emerald-300"
                              }`}
                            >
                              {ticket.status === "Pendente" ? <Clock className="w-3 h-3" /> : <CheckCircle2 className="w-3 h-3" />}
                              {ticket.status}
                            </span>
                            {ticket.justification && (
                              <div className="text-[10px] text-slate-500 mt-1 italic truncate max-w-[150px]" title={ticket.justification}>
                                Justif: {ticket.justification}
                              </div>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <button
                              onClick={() => openTicketModal(ticket)}
                              className="bg-[#059669] hover:bg-[#004D34] text-white font-bold px-3 py-1.5 rounded-lg transition-colors text-xs flex items-center gap-1 ml-auto cursor-pointer shadow-xs active:scale-95"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                              <span>Analisar / Responder</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Modal de Validação Humana */}
              {selectedTicket && (
                <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
                  <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-xl w-full p-6 space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                      <div>
                        <h4 className="text-base font-bold text-slate-900">
                          Painel de Validação Humana — {selectedTicket.protocol}
                        </h4>
                        <p className="text-xs text-slate-500">
                          Aluno: {selectedTicket.studentName} • RA: {selectedTicket.ra} • Assunto: {selectedTicket.subject}
                        </p>
                      </div>
                      <button
                        onClick={() => setSelectedTicket(null)}
                        className="text-slate-400 hover:text-slate-600 p-1 rounded-lg cursor-pointer"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <form onSubmit={handleConcludeTicket} className="space-y-4">
                      <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                          Pergunta / Solicitação do Aluno:
                        </span>
                        <p className="text-xs text-slate-800 font-medium leading-relaxed">
                          "{selectedTicket.studentQuestion}"
                        </p>
                      </div>

                      <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-1">
                        <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider flex items-center gap-1">
                          <Bot className="w-3 h-3 text-[#059669]" />
                          Sugestão do Assistente Virtual:
                        </span>
                        <p className="text-xs text-slate-700 leading-relaxed">
                          {selectedTicket.aiDraft}
                        </p>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                          Decisão do Atendente:
                        </label>
                        <div className="grid grid-cols-3 gap-2">
                          {[
                            { key: "aprovar", label: "Aprovar Resposta", color: "bg-emerald-700 text-white" },
                            { key: "ajustar", label: "Ajustar / Complementar", color: "bg-[#004D34] text-white" },
                            { key: "rejeitar", label: "Rejeitar", color: "bg-red-700 text-white" },
                          ].map((opt) => (
                            <button
                              key={opt.key}
                              type="button"
                              onClick={() => setValidationDecision(opt.key as any)}
                              className={`py-2 px-2 text-xs font-bold rounded-xl border transition-all text-center cursor-pointer ${
                                validationDecision === opt.key
                                  ? `${opt.color} shadow-sm border-transparent`
                                  : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"
                              }`}
                            >
                              {opt.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {validationDecision === "ajustar" && (
                        <div>
                          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                            Texto da Resposta Ajustada:
                          </label>
                          <textarea
                            rows={3}
                            value={adjustedResponseInput}
                            onChange={(e) => setAdjustedResponseInput(e.target.value)}
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#059669] focus:bg-white"
                            required
                          />
                        </div>
                      )}

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                          Justificativa do Atendente <span className="text-red-500">*</span>:
                        </label>
                        <textarea
                          rows={2}
                          value={justificationInput}
                          onChange={(e) => setJustificationInput(e.target.value)}
                          placeholder="Digite a fundamentação regulatória ou motivo da decisão técnica..."
                          className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#059669] focus:bg-white"
                          required
                        />
                      </div>

                      <div className="flex items-center justify-end gap-3 pt-2">
                        <button
                          type="button"
                          onClick={() => setSelectedTicket(null)}
                          className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                        >
                          Cancelar
                        </button>
                        <button
                          type="submit"
                          className="bg-[#059669] hover:bg-[#004D34] text-white text-xs font-bold px-5 py-2.5 rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
                        >
                          <CheckSquare className="w-4 h-4" />
                          <span>Concluir Atendimento</span>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: BASE DE CONHECIMENTO OFICIAL */}
          {adminTab === "knowledge" && (
            <div className="space-y-6">
              <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
                <div className="p-4 sm:p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-bold text-slate-900 text-base">Base de Conhecimento Oficial</h3>
                    <p className="text-xs text-slate-500">
                      Documentos institucionais cadastrados, versionamento contínuo e status de ativação.
                    </p>
                  </div>
                  <button
                    onClick={() => setNewDocModalOpen(true)}
                    className="bg-[#059669] hover:bg-[#004D34] text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Cadastrar Novo Documento</span>
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider">
                      <tr>
                        <th className="py-3.5 px-4">Nome do Documento</th>
                        <th className="py-3.5 px-4">Categoria / Setor</th>
                        <th className="py-3.5 px-4">Versão</th>
                        <th className="py-3.5 px-4">Data de Atualização</th>
                        <th className="py-3.5 px-4">Status</th>
                        <th className="py-3.5 px-4 text-right">Ações de Gestão</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {knowledgeDocs.map((doc) => (
                        <tr key={doc.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-2">
                              <FileText className={`w-4 h-4 shrink-0 ${doc.active ? "text-[#059669]" : "text-slate-400"}`} />
                              <span className="font-bold text-slate-900">{doc.title}</span>
                            </div>
                            <span className="text-[10px] text-slate-400 ml-6">{doc.chunks} fragmentos catalogados</span>
                          </td>
                          <td className="py-3.5 px-4 font-medium text-slate-700">
                            {doc.category}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="font-mono font-bold bg-slate-100 px-2 py-0.5 rounded text-slate-700 text-[11px]">
                              {doc.version}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 font-mono text-slate-500">
                            {doc.updatedAt}
                          </td>
                          <td className="py-3.5 px-4">
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold inline-flex items-center gap-1 ${
                                doc.active
                                  ? "bg-emerald-100 text-emerald-800 border border-emerald-300"
                                  : "bg-slate-100 text-slate-500 border border-slate-200"
                              }`}
                            >
                              <span className={`w-1.5 h-1.5 rounded-full ${doc.active ? "bg-[#059669]" : "bg-slate-400"}`}></span>
                              {doc.active ? "Ativo" : "Inativo"}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => handleDownloadPdf(doc.title)}
                                className="bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-[#004D34] border border-slate-200 hover:border-emerald-200 font-bold px-2.5 py-1 rounded-lg text-xs transition-colors flex items-center gap-1 cursor-pointer"
                                title="Baixar PDF Demonstrativo (Fictício)"
                              >
                                <Download className="w-3.5 h-3.5 text-[#059669]" />
                                <span>Baixar PDF</span>
                              </button>
                              <button
                                onClick={() => openVersionModal(doc)}
                                className="bg-emerald-50 hover:bg-emerald-100 text-[#004D34] border border-emerald-200 font-bold px-2.5 py-1 rounded-lg text-xs transition-colors flex items-center gap-1 cursor-pointer"
                                title="Atualizar Versão do Documento"
                              >
                                <UploadCloud className="w-3.5 h-3.5" />
                                <span>Atualizar Versão</span>
                              </button>
                              <button
                                onClick={() => handleToggleDoc(doc.id)}
                                className={`font-bold px-2.5 py-1 rounded-lg text-xs border transition-colors cursor-pointer ${
                                  doc.active
                                    ? "bg-slate-50 hover:bg-red-50 text-slate-600 hover:text-red-700 border-slate-200"
                                    : "bg-[#004D34] hover:bg-[#059669] text-white border-transparent"
                                }`}
                              >
                                {doc.active ? "Desativar" : "Ativar"}
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Modal Atualizar Versão */}
              {versionModalDoc && (
                <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
                  <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                      <h4 className="text-base font-bold text-slate-900">Atualizar Versão do Documento</h4>
                      <button onClick={() => setVersionModalDoc(null)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <form onSubmit={handleSaveVersion} className="space-y-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                          Documento Selecionado:
                        </label>
                        <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900">
                          {versionModalDoc.title} (Atual: {versionModalDoc.version})
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                          Novo Código de Versão:
                        </label>
                        <input
                          type="text"
                          value={newVersionString}
                          onChange={(e) => setNewVersionString(e.target.value)}
                          placeholder="Ex: v2.5"
                          className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#059669] focus:bg-white font-medium"
                          required
                        />
                      </div>

                      <div className="flex items-center justify-end gap-3 pt-2">
                        <button
                          type="button"
                          onClick={() => setVersionModalDoc(null)}
                          className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                        >
                          Cancelar
                        </button>
                        <button
                          type="submit"
                          className="bg-[#059669] hover:bg-[#004D34] text-white text-xs font-bold px-5 py-2.5 rounded-xl shadow-md transition-all flex items-center gap-1.5"
                        >
                          <Check className="w-4 h-4" />
                          <span>Salvar Nova Versão</span>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}

              {/* Modal Cadastrar Novo Documento */}
              {newDocModalOpen && (
                <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
                  <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                      <h4 className="text-base font-bold text-slate-900">Cadastrar Documento Oficial</h4>
                      <button onClick={() => setNewDocModalOpen(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <form onSubmit={handleAddDoc} className="space-y-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                          Título / Nome do Documento:
                        </label>
                        <input
                          type="text"
                          value={newDocTitle}
                          onChange={(e) => setNewDocTitle(e.target.value)}
                          placeholder="Ex: Calendario_Academico_2026.pdf ou Regimento_Geral.pdf"
                          className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#059669] focus:bg-white"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                          Categoria / Setor Responsável:
                        </label>
                        <select
                          value={newDocCategory}
                          onChange={(e) => setNewDocCategory(e.target.value)}
                          className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#059669]"
                        >
                          <option value="Secretaria Geral">Secretaria Geral</option>
                          <option value="Acadêmico">Acadêmico</option>
                          <option value="Financeiro">Financeiro</option>
                          <option value="Pró-Reitoria">Pró-Reitoria</option>
                          <option value="Coordenações">Coordenações</option>
                        </select>
                      </div>

                      <div className="flex items-center justify-end gap-3 pt-2">
                        <button
                          type="button"
                          onClick={() => setNewDocModalOpen(false)}
                          className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                        >
                          Cancelar
                        </button>
                        <button
                          type="submit"
                          className="bg-[#059669] hover:bg-[#004D34] text-white text-xs font-bold px-5 py-2.5 rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Cadastrar Documento</span>
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: AVALIAÇÕES E FEEDBACKS (INCLUINDO 1 A 5 ESTRELAS) */}
          {adminTab === "feedbacks" && (
            <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
              <div className="p-4 sm:p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Relatório Consolidado de Avaliações & Satisfação</h3>
                  <p className="text-xs text-slate-500">
                    Notas de satisfação discente (1 a 5 estrelas) do atendimento humano e feedback do assistente virtual.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-200 flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-emerald-600 text-emerald-600" />
                    <span>Média Geral: 4.9 / 5.0 (98% Satisfação)</span>
                  </span>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Data / Hora</th>
                      <th className="py-3 px-4">Estudante</th>
                      <th className="py-3 px-4">Canal / Assunto</th>
                      <th className="py-3 px-4">Classificação / Nota</th>
                      <th className="py-3 px-4">Comentário Discente</th>
                      <th className="py-3 px-4">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {feedbacks.map((fb) => (
                      <tr key={fb.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 text-slate-500 font-mono">{fb.date}</td>
                        <td className="py-3 px-4 font-bold text-slate-900">{fb.student}</td>
                        <td className="py-3 px-4 max-w-xs truncate">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold mr-1.5 ${
                            fb.type === "human_service" ? "bg-emerald-100 text-[#004D34]" : "bg-slate-100 text-slate-700"
                          }`}>
                            {fb.type === "human_service" ? "Secretaria Humana" : "Assistente Virtual"}
                          </span>
                          {fb.queryOrSubject}
                        </td>
                        <td className="py-3 px-4">
                          {fb.ratingStars !== undefined ? (
                            <div className="flex items-center gap-0.5 text-emerald-600">
                              {[1, 2, 3, 4, 5].map((s) => (
                                <Star
                                  key={s}
                                  className={`w-3.5 h-3.5 ${
                                    s <= fb.ratingStars! ? "fill-emerald-600 text-emerald-600" : "text-slate-300"
                                  }`}
                                />
                              ))}
                              <span className="text-[11px] font-bold text-[#004D34] ml-1">
                                {fb.ratingStars}.0
                              </span>
                            </div>
                          ) : fb.ratingType === "positive" ? (
                            <span className="inline-flex items-center gap-1 text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full">
                              <ThumbsUp className="w-3 h-3" /> Positivo
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-red-700 font-bold bg-red-50 px-2 py-0.5 rounded-full">
                              <ThumbsDown className="w-3 h-3" /> Precisa Ajuste
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-slate-600 italic">
                          {fb.reason && <strong className="text-slate-800 not-italic mr-1">[{fb.reason}]</strong>}
                          {fb.comment}
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              fb.status === "Analisado"
                                ? "bg-emerald-100 text-emerald-800"
                                : "bg-amber-100 text-amber-800"
                            }`}
                          >
                            {fb.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>
    );
  }

  // ==========================================
  // VIEW 3: AGENTE DO ESTUDANTE
  // ==========================================
  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col font-sans text-slate-900">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-[#004D34] text-white text-xs font-bold px-4 py-3 rounded-xl shadow-lg border border-emerald-500 flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-[#00E676]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Fixado */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
        <div className="max-w-5xl mx-auto px-3 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <FecapLogo size="md" />
            <div className="border-l border-slate-200 pl-3">
              <span className="font-bold text-slate-900 text-sm tracking-tight block sm:inline">SecretarIA</span>
              <span className="text-xs text-slate-500 hidden sm:inline sm:ml-2">Portal de Orientação</span>
            </div>
          </div>

          {/* Connection Status Badge */}
          <div className="flex items-center gap-2 shrink-0">
            {isHumanConnected ? (
              <div className="bg-emerald-100 text-[#004D34] border border-emerald-300 px-2 sm:px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all animate-pulse">
                <span className="w-2.5 h-2.5 rounded-full bg-[#059669]"></span>
                <Headphones className="w-3.5 h-3.5 text-[#004D34]" />
                <span className="hidden xs:inline sm:inline">
                  {isDemoMode ? "Atendente Humano Simulado (DEMO)" : "Atendente Humano Conectado"}
                </span>
              </div>
            ) : (
              <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 sm:px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 shadow-xs">
                <span className="w-2 h-2 rounded-full bg-[#00E676]"></span>
                <Bot className="w-3.5 h-3.5 text-[#059669]" />
                <span className="hidden sm:inline">IA On-line • Base Oficial ASA/FECAP</span>
              </div>
            )}
          </div>

          {/* User Profile, Export & Actions */}
          <div className="flex items-center gap-2.5">
            {/* Botão Baixar Histórico da Conversa */}
            <button
              onClick={handleExportHistory}
              className="text-xs font-semibold text-[#004D34] hover:text-[#059669] px-3 py-1.5 rounded-lg border border-emerald-200 bg-emerald-50/80 hover:bg-emerald-100 transition-colors hidden sm:flex items-center gap-1.5 cursor-pointer shadow-xs"
              title="Baixar histórico completo da conversa"
            >
              <FileDown className="w-3.5 h-3.5 text-[#059669]" />
              <span>Baixar Histórico</span>
            </button>

            <button
              onClick={() => setCurrentScreen("admin")}
              className="text-xs font-semibold text-slate-700 hover:text-slate-900 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 transition-colors hidden sm:flex items-center gap-1.5 cursor-pointer"
              title="Acessar Visão do Administrador / Atendente"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#059669]" />
              <span>Painel Admin</span>
            </button>

            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 rounded-full bg-[#059669] text-white flex items-center justify-center font-bold text-xs shadow-xs">
                AN
              </div>
              <div className="hidden md:block text-left">
                <div className="text-xs font-bold text-slate-900">Ana</div>
                <div className="text-[10px] text-slate-500">RA 202612345</div>
              </div>
            </div>

            <button
              onClick={() => setCurrentScreen("login")}
              className="text-slate-500 hover:text-red-700 p-2 rounded-lg hover:bg-slate-100 transition-colors flex items-center gap-1 text-xs cursor-pointer"
              title="Sair / Logout"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline font-medium">Sair</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-3 sm:px-4 md:px-6 py-4 sm:py-6 flex flex-col justify-between">
        {/* Top Hero & Busca Inteligente */}
        <section className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 shadow-sm mb-4 sm:mb-6">
          <div className="text-center max-w-2xl mx-auto mb-5">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-[#004D34] bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-[#059669]" />
              <span>Orientação Acadêmica Inteligente</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              Olá, Ana! Como posso ajudar você hoje?
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Consulte procedimentos oficiais, requerimentos, prazos e documentos com precisão regimental.
            </p>
          </div>

          {/* Pílulas de Perguntas Frequentes (Chips) */}
          <div className="mb-3 sm:mb-4 grid grid-cols-2 sm:flex sm:flex-wrap sm:items-center sm:justify-center gap-2">
            {[
              { label: "💡 Como trancar matéria?", query: "Como trancar matéria?" },
              { label: "📄 Emitir Histórico", query: "Como emitir histórico escolar oficial?" },
              { label: "🕒 Prazos de Avaliações", query: "Quais os prazos de provas e calendário acadêmico?" },
              { label: "💳 Segunda via de boleto", query: "Como emitir segunda via de boleto?" },
            ].map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(chip.query)}
                className="text-xs bg-slate-100 hover:bg-emerald-50 hover:text-[#004D34] hover:border-emerald-300 text-slate-700 font-medium px-3 py-1.5 rounded-lg border border-slate-200 transition-all cursor-pointer w-full sm:w-auto"
              >
                {chip.label}
              </button>
            ))}
          </div>

          {/* Barra de Busca / Prompt Principal */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="relative flex items-center bg-slate-50 border border-slate-300 rounded-2xl p-1.5 focus-within:ring-2 focus-within:ring-[#059669] focus-within:bg-white focus-within:border-transparent transition-all shadow-xs"
          >
            <div className="pl-3 text-slate-400">
              <Search className="w-5 h-5 text-slate-500" />
            </div>

            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Digite sua dúvida acadêmica (ex: Como emitir meu histórico?)..."
              className="w-full bg-transparent px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none"
            />

            {/* Hidden File Input */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileAttach}
              className="hidden"
            />

            {/* Ícone de Anexo (Clipe de Papel) */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2 text-slate-500 hover:text-[#004D34] hover:bg-slate-200/60 rounded-xl transition-colors cursor-pointer mr-1"
              title="Anexar documento ou comprovante"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            <button
              type="submit"
              disabled={!inputVal.trim() && !attachedFileName}
              className="bg-[#059669] hover:bg-[#004D34] disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer active:scale-95"
            >
              <span>Enviar</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Exibição de Anexo Selecionado */}
          {attachedFileName && (
            <div className="mt-2.5 inline-flex items-center gap-2 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl text-xs text-[#004D34] font-medium animate-fadeIn">
              <Paperclip className="w-3.5 h-3.5 text-[#059669]" />
              <span>Anexo pronto: <strong>{attachedFileName}</strong></span>
              <button
                type="button"
                onClick={() => setAttachedFileName(null)}
                className="text-slate-400 hover:text-red-700 ml-1 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </section>

        {/* Banner Superior de Atendimento Humano Ativo com Botão Encerrar */}
        {isHumanConnected && (
          <div className="mb-4 bg-emerald-50 border border-emerald-300 rounded-xl p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs animate-fadeIn">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#004D34] text-white flex items-center justify-center shrink-0 shadow-xs">
                <Headphones className="w-4 h-4 text-[#00E676]" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-[#004D34] flex flex-wrap items-center gap-1.5">
                  <span>
                    {isDemoMode
                      ? "Atendimento Humano Simulado em Andamento (Modo Demonstração)"
                      : "Atendimento Humano em Andamento"}
                  </span>
                  <span className="bg-emerald-200 text-emerald-900 text-[10px] px-2 py-0.2 rounded-full font-bold">
                    {isDemoMode ? "Orientador Carlos (SIMULADO)" : "Orientador Carlos"} • {currentProtocol || "#PROTOCOLO-2026-8842"}
                  </span>
                </h4>
                <p className="text-[11px] text-slate-600">
                  {isDemoMode
                    ? `Assunto vinculado: "${currentSubject || transferReason}" • Ambiente de demonstração acadêmica (sem validação institucional real).`
                    : "A resposta da IA está pausada. Você está em contato direto com a Secretaria Acadêmica."}
                </p>
              </div>
            </div>

            <button
              onClick={handleOpenSurveyModal}
              className="w-full sm:w-auto bg-[#004D34] hover:bg-[#059669] text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
              title="Concluir atendimento humano e responder pesquisa de satisfação"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-[#00E676]" />
              <span>Encerrar Atendimento</span>
            </button>
          </div>
        )}

        {/* Interface de Chat Conversacional */}
        <section className="space-y-4 mb-6">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1 border-b border-slate-200 pb-2">
            <span>Histórico de Atendimento</span>
            <span>Governança Institucional e Conformidade</span>
          </div>

          {messages.map((msg) => {
            const isUser = msg.sender === "user";
            const isHuman = msg.sender === "human";

            return (
              <div
                key={msg.id}
                className={`flex items-start gap-3 ${isUser ? "flex-row-reverse" : "flex-row"}`}
              >
                {/* Avatar */}
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold shadow-xs ${
                    isUser
                      ? "bg-[#059669] text-white"
                      : isHuman
                      ? "bg-[#004D34] text-[#00E676]"
                      : "bg-[#00E676] text-[#002B18]"
                  }`}
                >
                  {isUser ? <User className="w-4 h-4" /> : isHuman ? <Headphones className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Message Bubble */}
                <div
                  className={`w-[90%] sm:w-auto sm:max-w-2xl rounded-2xl p-3 sm:p-4 shadow-sm ${
                    isUser
                      ? "bg-[#059669] text-white rounded-tr-none"
                      : isHuman
                      ? "bg-emerald-50/90 border border-emerald-300 text-slate-900 rounded-tl-none shadow-xs"
                      : "bg-[#F1F5F9] border border-slate-200 text-slate-900 rounded-tl-none"
                  }`}
                >
                  {/* Sender Header */}
                  <div className="flex items-center justify-between gap-4 mb-1.5">
                    <span
                      className={`text-[11px] font-bold ${
                        isUser ? "text-emerald-100" : isHuman ? "text-[#004D34]" : "text-emerald-800"
                      }`}
                    >
                      {isUser ? "Você" : msg.agentName || "SecretarIA • Assistente Oficial"}
                    </span>
                    <span className={`text-[10px] ${isUser ? "text-emerald-100/80" : "text-slate-400"}`}>
                      {msg.time}
                    </span>
                  </div>

                  {/* Body Text */}
                  <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-line">
                    {msg.text}
                  </p>

                  {/* Botão Inline de Encerrar Atendimento quando a estudante diz "não" ou conclui */}
                  {isHuman && msg.offerCloseAction && isHumanConnected && (
                    <div className="mt-3 pt-2.5 border-t border-emerald-200 flex items-center justify-between gap-2">
                      <span className="text-[11px] text-[#004D34] font-medium">
                        Atendimento pronto para finalização:
                      </span>
                      <button
                        type="button"
                        onClick={handleOpenSurveyModal}
                        className="bg-[#004D34] hover:bg-[#059669] text-white text-xs font-bold px-3.5 py-2 rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#00E676]" />
                        <span>Encerrar Atendimento e Voltar para a IA</span>
                      </button>
                    </div>
                  )}

                  {/* Attached File Display */}
                  {msg.attachedFile && (
                    <div className="mt-2.5 p-2 rounded-lg bg-black/10 border border-white/20 text-xs flex items-center gap-2">
                      <Paperclip className="w-3.5 h-3.5" />
                      <span>Anexo enviado: <strong>{msg.attachedFile}</strong></span>
                    </div>
                  )}

                  {/* 2. Passo a Passo Numerado */}
                  {msg.steps && (
                    <div className="mt-3 p-3 bg-white border border-slate-200 rounded-xl space-y-1.5">
                      <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                        Passo a passo no Portal do Aluno:
                      </div>
                      <ol className="list-decimal list-inside space-y-1 text-xs text-slate-700">
                        {msg.steps.map((step, sIdx) => (
                          <li key={sIdx} className="leading-snug">
                            {step}
                          </li>
                        ))}
                      </ol>
                    </div>
                  )}

                  {/* 3. Links / Botões de Acesso Rápido */}
                  {msg.links && msg.links.length > 0 && (
                    <div className="mt-2.5 flex flex-wrap gap-2">
                      {msg.links.map((lnk, lIdx) => (
                        <a
                          key={lIdx}
                          href={lnk.url}
                          onClick={(e) => {
                            e.preventDefault();
                            if (
                              msg.downloadTitle &&
                              lnk.label.toLowerCase().includes("baixar")
                            ) {
                              handleDownloadPdf(msg.downloadTitle);
                            } else {
                              showToast(`Redirecionando para: ${lnk.label}`);
                            }
                          }}
                          className="inline-flex items-center gap-1 text-[11px] font-bold text-[#004D34] bg-white hover:bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 transition-colors"
                        >
                          <ExternalLink className="w-3 h-3 text-[#059669]" />
                          <span>{lnk.label}</span>
                        </a>
                      ))}
                    </div>
                  )}

                  {/* Segunda via de boleto interativa (dados fictícios) */}
                  {msg.boletoWidget && <BoletoPicker preselectMonth={msg.boletoWidget.preselectMonth} />}

                  {/* Card de Download de PDF */}
                  {msg.hasDownload && (
                    <div className="mt-3 bg-white border border-slate-200 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-emerald-100 text-[#004D34] flex items-center justify-center shrink-0">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900">{msg.downloadTitle}</div>
                          <div className="text-[10px] text-slate-500">
                            DOCUMENTO FICTÍCIO — DEMONSTRAÇÃO ACADÊMICA — SEM VALIDADE OFICIAL • {msg.downloadSize || "150 KB"}
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={downloadingDocTitle === msg.downloadTitle}
                        onClick={() => handleDownloadPdf(msg.downloadTitle)}
                        className="bg-[#059669] hover:bg-[#004D34] disabled:opacity-60 text-white text-xs font-bold px-3 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer active:scale-95"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>
                          {downloadingDocTitle === msg.downloadTitle ? "Baixando..." : "Baixar .PDF"}
                        </span>
                      </button>
                    </div>
                  )}

                  {/* 4. Bloco de Evidência e Fonte Oficial */}
                  {!isUser && (
                    <div className="mt-3 pt-2.5 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                      {msg.citation ? (
                        <div className="text-slate-500 flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2">
                          <span className="flex items-center gap-1 font-medium text-slate-700">
                            <ShieldCheck className="w-3.5 h-3.5 text-[#059669]" />
                            <span>Fonte: {msg.citation}</span>
                          </span>
                          {msg.updatedAt && (
                            <span className="text-[10px] text-slate-400 font-mono">
                              • Atualizado em: {msg.updatedAt}
                            </span>
                          )}
                        </div>
                      ) : (
                        <span></span>
                      )}

                      {/* Ações de Mensagem: Copiar Resposta & Feedback */}
                      <div className="flex items-center gap-2 text-slate-500">
                        <button
                          onClick={() => handleCopyMessage(msg.id, msg.text + (msg.steps ? `\nPasso a passo:\n${msg.steps.join("\n")}` : ""))}
                          className="flex items-center gap-1 text-[10px] hover:text-slate-900 px-1.5 py-0.5 rounded hover:bg-slate-200/60 transition-colors cursor-pointer"
                          title="Copiar Resposta em 1 clique"
                        >
                          {copiedId === msg.id ? (
                            <>
                              <Check className="w-3 h-3 text-[#059669]" />
                              <span className="text-[#059669] font-bold">Copiado</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copiar</span>
                            </>
                          )}
                        </button>

                        <span className="text-slate-300">|</span>

                        <span className="text-[10px]">Útil?</span>
                        <button
                          onClick={() => handleFeedbackClick(msg.id, "up")}
                          className={`p-1 rounded hover:bg-slate-200/60 transition-colors cursor-pointer ${
                            msg.feedback === "up" ? "text-[#059669] font-bold" : "hover:text-slate-800"
                          }`}
                          title="Sim, foi útil"
                        >
                          <ThumbsUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleFeedbackClick(msg.id, "down")}
                          className={`p-1 rounded hover:bg-slate-200/60 transition-colors cursor-pointer ${
                            msg.feedback === "down" ? "text-red-600 font-bold" : "hover:text-slate-800"
                          }`}
                          title="Não foi útil"
                        >
                          <ThumbsDown className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}

                  {/* BOTÃO DE TRANSFERÊNCIA PARA ATENDIMENTO HUMANO */}
                  {!isUser && !isHuman && !isHumanConnected && msg.allowTransfer && (
                    <div className="mt-3 pt-2.5 border-t border-slate-200 flex items-center justify-between">
                      <button
                        onClick={handleOpenTransferModal}
                        className="w-full sm:w-auto bg-[#004D34] hover:bg-[#059669] text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 border border-emerald-500/40"
                      >
                        <Headphones className="w-4 h-4 text-[#00E676]" />
                        <span>Transferir para Atendimento Humano</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {/* Typing Animation com Texto Dinâmico */}
          {isTyping && (
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-[#00E676] text-[#002B18] flex items-center justify-center shrink-0 font-bold text-xs shadow-xs">
                {isHumanConnected ? <Headphones className="w-4 h-4 text-[#004D34]" /> : <Bot className="w-4 h-4" />}
              </div>
              <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-none p-3.5 shadow-xs flex items-center gap-2 text-xs text-slate-500">
                <span className="w-2 h-2 rounded-full bg-[#059669] animate-bounce"></span>
                <span className="w-2 h-2 rounded-full bg-[#059669] animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-2 h-2 rounded-full bg-[#059669] animate-bounce [animation-delay:0.4s]"></span>
                <span className="text-slate-600 font-medium">
                  {typingLabel}
                </span>
              </div>
            </div>
          )}

          <div ref={chatEndRef} />
        </section>

        {/* Modal de Transbordo Humano (Handover) */}
        {isTransferModalOpen && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
            <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#004D34] text-white flex items-center justify-center">
                    <Headphones className="w-4 h-4 text-[#00E676]" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">
                      {isDemoMode
                        ? "Transferência para Atendimento Humano (SIMULADO)"
                        : "Transferência para Atendimento Humano"}
                    </h4>
                    <p className="text-[11px] text-slate-500">Secretaria Integrada de Atendimento ao Aluno</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsTransferModalOpen(false)}
                  className="text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Status da Fila */}
              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#059669] animate-ping"></span>
                  <span className="font-bold text-[#004D34]">Sua posição: 2º na fila</span>
                </div>
                <span className="text-slate-600 font-medium">Tempo estimado: ~3 min</span>
              </div>

              {/* Seleção do Motivo do Transbordo */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Selecione o Motivo da Transferência:
                </label>
                <select
                  value={transferReason}
                  onChange={(e) => setTransferReason(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#059669]"
                >
                  <option value="Solicitação de Documentos Acadêmicos">Solicitação de Documentos Acadêmicos</option>
                  <option value="Acesso ao Portal do Aluno">Acesso ao Portal do Aluno</option>
                  <option value="Dúvida de Matrícula ou Requerimento">Dúvida de Matrícula ou Requerimento</option>
                  <option value="Negociação ou Questão Financeira">Negociação ou Questão Financeira</option>
                  <option value="Aproveitamento de Disciplinas e Transferência">Aproveitamento de Disciplinas e Transferência</option>
                  <option value="Dúvida sobre Calendário ou Provas">Dúvida sobre Calendário ou Provas</option>
                  <option value="Outro assunto específico">Outro assunto específico</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Observação adicional (opcional):
                </label>
                <input
                  type="text"
                  value={transferCustomNote}
                  onChange={(e) => setTransferCustomNote(e.target.value)}
                  placeholder="Ex: Preciso falar sobre trancamento para o 2º semestre..."
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#059669]"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setIsTransferModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmTransfer}
                  className="bg-[#004D34] hover:bg-[#059669] text-white text-xs font-bold px-5 py-2.5 rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <Check className="w-4 h-4 text-[#00E676]" />
                  <span>Confirmar Transferência</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal de Avaliação de Satisfação (1 a 5 Estrelas) ao Encerrar Atendimento */}
        {isSurveyModalOpen && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
            <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 text-center">
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-[#004D34] flex items-center justify-center mx-auto border border-emerald-200">
                <Star className="w-6 h-6 fill-[#059669] text-[#059669]" />
              </div>

              <div>
                <h4 className="text-base font-bold text-slate-900">
                  {isDemoMode
                    ? "Como foi seu atendimento com o Orientador Carlos (SIMULADO)?"
                    : "Como foi seu atendimento com o Orientador Carlos?"}
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Sua avaliação encerra o protocolo {currentProtocol || ""} e restaura o agente de IA SecretarIA.
                </p>
              </div>

              {/* Seletor de 1 a 5 Estrelas */}
              <div className="flex items-center justify-center gap-2 py-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onMouseEnter={() => setSurveyHoverRating(star)}
                    onMouseLeave={() => setSurveyHoverRating(0)}
                    onClick={() => setSurveyRating(star)}
                    className="p-1 text-slate-300 hover:scale-110 transition-transform cursor-pointer"
                  >
                    <Star
                      className={`w-7 h-7 transition-colors ${
                        (surveyHoverRating || surveyRating) >= star
                          ? "fill-[#059669] text-[#059669]"
                          : "text-slate-300"
                      }`}
                    />
                  </button>
                ))}
              </div>

              <div className="text-xs font-bold text-[#004D34]">
                {surveyRating === 5 && "Excelente! Atendimento ágil e resolutivo."}
                {surveyRating === 4 && "Muito bom! Dúvidas esclarecidas."}
                {surveyRating === 3 && "Regular. Atendeu minhas expectativas."}
                {surveyRating === 2 && "Insatisfatório. Demorou ou ficou confuso."}
                {surveyRating === 1 && "Muito ruim. Não resolveu minha solicitação."}
              </div>

              <form onSubmit={handleSubmitSurvey} className="space-y-3 pt-1">
                <textarea
                  rows={2}
                  value={surveyComment}
                  onChange={(e) => setSurveyComment(e.target.value)}
                  placeholder="Deixe um elogio ou sugestão para o atendente (opcional)..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#059669]"
                />

                <div className="flex items-center justify-center gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsSurveyModalOpen(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                  >
                    Voltar ao Chat
                  </button>
                  <button
                    type="submit"
                    className="bg-[#059669] hover:bg-[#004D34] text-white text-xs font-bold px-6 py-2.5 rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
                  >
                    <Check className="w-4 h-4" />
                    <span>Concluir & Enviar</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal Sutil de Feedback Negativo para o Bot */}
        {feedbackModalMessageId && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
            <div className="bg-white border border-slate-200 rounded-2xl shadow-2xl max-w-sm w-full p-5 space-y-3.5">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-xs">
                  <ThumbsDown className="w-4 h-4 text-red-600" />
                  <span>Como podemos melhorar esta orientação?</span>
                </div>
                <button
                  onClick={() => setFeedbackModalMessageId(null)}
                  className="text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSubmitNegativeFeedback} className="space-y-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1.5">
                    Selecione o motivo:
                  </label>
                  <div className="space-y-1.5">
                    {[
                      "Informação incompleta",
                      "Link ou anexo desatualizado",
                      "Explicação confusa",
                      "Não respondeu minha dúvida específica",
                    ].map((reason) => (
                      <label
                        key={reason}
                        className={`flex items-center gap-2 p-2 rounded-lg border text-xs cursor-pointer transition-colors ${
                          feedbackReason === reason
                            ? "bg-emerald-50 border-emerald-300 text-[#004D34] font-semibold"
                            : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"
                        }`}
                      >
                        <input
                          type="radio"
                          name="feedbackReason"
                          checked={feedbackReason === reason}
                          onChange={() => setFeedbackReason(reason)}
                          className="text-[#059669] focus:ring-[#059669]"
                        />
                        <span>{reason}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    Comentário adicional (opcional):
                  </label>
                  <input
                    type="text"
                    value={feedbackCustomComment}
                    onChange={(e) => setFeedbackCustomComment(e.target.value)}
                    placeholder="O que faltou na resposta?"
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-[#059669]"
                  />
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setFeedbackModalMessageId(null)}
                    className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
                  >
                    Fechar
                  </button>
                  <button
                    type="submit"
                    className="bg-[#059669] hover:bg-[#004D34] text-white text-xs font-bold px-4 py-1.5 rounded-lg shadow-xs cursor-pointer"
                  >
                    Enviar Avaliação
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Bottom Input Bar */}
        <div className="sticky bottom-3 sm:bottom-4 z-30 -mx-3 sm:-mx-4 md:-mx-6 px-3 sm:px-4 md:px-6">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2 bg-white border border-slate-300 rounded-2xl p-2 shadow-lg"
          >
            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder={
                isHumanConnected
                  ? isDemoMode
                    ? "Digite sua mensagem para o Orientador Carlos (SIMULADO)..."
                    : "Digite sua mensagem para o Orientador Carlos da Secretaria..."
                  : "Digite sua dúvida acadêmica (ex: Como emitir meu histórico?)..."
              }
              className="flex-1 bg-transparent px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none font-medium"
            />
            <button
              type="submit"
              disabled={!inputVal.trim() && !attachedFileName}
              className="bg-[#059669] hover:bg-[#004D34] disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer active:scale-95"
            >
              <span>Enviar</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </main>

      {/* Footer */}
      <footer className="w-full py-4 text-center text-xs text-slate-500 border-t border-slate-200 bg-white">
        <p>© 2026 FECAP — Fundação Escola de Comércio Álvares Penteado • Em conformidade com o Regimento Acadêmico</p>
      </footer>
    </div>
  );
}