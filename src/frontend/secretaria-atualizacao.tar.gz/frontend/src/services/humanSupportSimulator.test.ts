import { describe, expect, it } from "vitest";
import {
  buildSimulatedHumanReply,
  classifyUserIntent,
  extractRelevantSubjectQuery,
  getSimulatedAttendantName,
  isFollowUpOfferInLastMessage,
} from "./humanSupportSimulator";

describe("humanSupportSimulator — Atendimento Humano Simulado (SecretarIA / FECAP Guia)", () => {
  const baseFollowUpMessage =
    "Posso ajudar em mais alguma dúvida?\n\n" +
    "Precisa de mais algum apoio neste atendimento?";

  it("1. Interpreta resposta curta 'não' após oferta de ajuda adicional e oferece encerramento sem falso deferimento", () => {
    const intent = classifyUserIntent("não", baseFollowUpMessage);
    expect(intent).toBe("close_or_decline_more_help");

    const reply = buildSimulatedHumanReply({
      userText: "não",
      studentName: "Ana",
      protocol: "FECAP-20261101-4455",
      subject: "Dúvida de Matrícula ou Requerimento — Como emitir histórico escolar oficial?",
      conversationId: "conv-1234",
      lastHumanMessageText: baseFollowUpMessage,
      turnCount: 1,
      demoMode: true,
    });

    // Não pode repetir o bug antigo ("analisei os registros de sua solicitação sobre 'não'")
    expect(reply.replyText.toLowerCase()).not.toContain('solicitação sobre "não"');
    expect(reply.replyText.toLowerCase()).not.toContain("solicitação sobre 'não'");
    expect(reply.replyText.toLowerCase()).not.toContain("validado diretamente junto à secretaria geral");

    // Deve apresentar mensagem de encerramento adequada e habilitar finalização
    expect(reply.intent).toBe("close_or_decline_more_help");
    expect(reply.shouldOfferClose).toBe(true);
    expect(reply.shouldAutoPromptSurvey).toBe(true);
    expect(reply.replyText).toContain("FECAP-20261101-4455");
    expect(reply.replyText).toContain("Como emitir histórico escolar oficial?");
    expect(reply.replyText).toContain("Encerrar Atendimento");
  });

  it("2. Interpreta respostas curtas ('sim', 'obrigada', 'encerrar') considerando o contexto da conversa", () => {
    // Caso "sim" após pergunta de apoio adicional
    const simReply = buildSimulatedHumanReply({
      userText: "sim",
      studentName: "Ana",
      protocol: "FECAP-20261101-4455",
      subject: "Negociação ou Questão Financeira",
      conversationId: "conv-1234",
      lastHumanMessageText: baseFollowUpMessage,
      turnCount: 1,
      demoMode: true,
    });
    expect(simReply.intent).toBe("accept_more_help");
    expect(simReply.shouldOfferClose).toBe(false);
    expect(simReply.replyText).toContain("qual é a sua próxima dúvida");
    expect(simReply.replyText.toLowerCase()).not.toContain('solicitação sobre "sim"');

    // Caso "obrigada" sem pergunta explícita de fechamento anterior
    const thanksReply = buildSimulatedHumanReply({
      userText: "obrigada!",
      studentName: "Ana",
      protocol: "FECAP-20261101-4455",
      subject: "Negociação ou Questão Financeira",
      conversationId: "conv-1234",
      lastHumanMessageText: "Olá, Ana! Assumi seu protocolo.",
      turnCount: 2,
      demoMode: true,
    });
    expect(thanksReply.intent).toBe("gratitude_only");
    expect(thanksReply.shouldOfferClose).toBe(true);
    expect(thanksReply.replyText).toContain("Disponha, Ana");

    // Caso "obrigada" logo após pergunta de oferta de ajuda adicional -> prepara encerramento
    const thanksAfterOffer = buildSimulatedHumanReply({
      userText: "obrigada!",
      studentName: "Ana",
      protocol: "FECAP-20261101-4455",
      subject: "Negociação ou Questão Financeira",
      conversationId: "conv-1234",
      lastHumanMessageText: baseFollowUpMessage,
      turnCount: 2,
      demoMode: true,
    });
    expect(thanksAfterOffer.intent).toBe("close_or_decline_more_help");
    expect(thanksAfterOffer.shouldOfferClose).toBe(true);

    // Caso "encerrar"
    const closeReply = buildSimulatedHumanReply({
      userText: "encerrar",
      studentName: "Ana",
      protocol: "FECAP-20261101-4455",
      subject: "Negociação ou Questão Financeira",
      conversationId: "conv-1234",
      lastHumanMessageText: baseFollowUpMessage,
      turnCount: 3,
      demoMode: true,
    });
    expect(closeReply.intent).toBe("explicit_close");
    expect(closeReply.shouldOfferClose).toBe(true);
    expect(closeReply.shouldAutoPromptSurvey).toBe(true);
  });

  it("3. Evita respostas genéricas repetitivas quando a estudante faz perguntas abertas em turnos consecutivos", () => {
    const replyTurn0 = buildSimulatedHumanReply({
      userText: "Qual o horário de atendimento presencial da secretaria?",
      studentName: "Ana",
      protocol: "FECAP-20261101-7788",
      subject: "Dúvida sobre Calendário ou Provas",
      conversationId: "conv-99",
      lastHumanMessageText: "",
      turnCount: 0,
      demoMode: true,
    });

    const replyTurn1 = buildSimulatedHumanReply({
      userText: "E posso protocolar procuração por terceiros?",
      studentName: "Ana",
      protocol: "FECAP-20261101-7788",
      subject: "Dúvida sobre Calendário ou Provas",
      conversationId: "conv-99",
      lastHumanMessageText: replyTurn0.replyText,
      turnCount: 1,
      demoMode: true,
    });

    const replyTurn2 = buildSimulatedHumanReply({
      userText: "Como acompanho o prazo de resposta do requerimento?",
      studentName: "Ana",
      protocol: "FECAP-20261101-7788",
      subject: "Dúvida sobre Calendário ou Provas",
      conversationId: "conv-99",
      lastHumanMessageText: replyTurn1.replyText,
      turnCount: 2,
      demoMode: true,
    });

    expect(replyTurn0.replyText).not.toBe(replyTurn1.replyText);
    expect(replyTurn1.replyText).not.toBe(replyTurn2.replyText);
  });

  it("4. Identifica claramente o orientador como SIMULADO quando DEMO_MODE estiver ativo", () => {
    const demoLabel = getSimulatedAttendantName(true);
    const prodLabel = getSimulatedAttendantName(false);

    expect(demoLabel).toContain("SIMULADO");
    expect(demoLabel).toContain("Orientador Carlos");
    expect(prodLabel).not.toContain("SIMULADO");

    const reply = buildSimulatedHumanReply({
      userText: "Como emitir segunda via de boleto?",
      studentName: "Ana",
      protocol: "FECAP-20261101-9000",
      subject: "Negociação ou Questão Financeira",
      conversationId: "conv-55",
      lastHumanMessageText: "",
      turnCount: 0,
      demoMode: true,
    });

    expect(reply.agentName).toContain("SIMULADO");
    expect(reply.replyText).toContain("SIMULADO");
  });

  it("5. Nunca afirma que documentos, solicitações ou processos foram realmente validados pela FECAP", () => {
    const topics = [
      "Preciso de segunda via de boleto vencido",
      "Quero trancar minha matrícula neste semestre",
      "Preciso emitir meu histórico escolar oficial",
      "Gostaria de saber sobre equivalência de disciplinas",
      "não",
    ];

    for (const msg of topics) {
      const reply = buildSimulatedHumanReply({
        userText: msg,
        studentName: "Ana",
        protocol: "FECAP-20261101-1122",
        subject: "Dúvida de Matrícula ou Requerimento",
        conversationId: "conv-88",
        lastHumanMessageText: baseFollowUpMessage,
        turnCount: 0,
        demoMode: true,
      });

      const lower = reply.replyText.toLowerCase();
      expect(lower).not.toContain("foi validado diretamente junto à secretaria geral");
      expect(lower).not.toContain("identifiquei uma cobrança em aberto vinculada ao seu ra");
      expect(lower).not.toContain("já gerei a 2ª via oficial com autenticação digital");
      expect(lower).not.toContain("sem pendências pedagógicas");
      expect(lower).toContain("simulado");
    }
  });

  it("6. Vincula o protocolo ao assunto real da conversa, ignorando respostas curtas como 'não' ou 'sim'", () => {
    const userMessages = [
      "Como trancar matéria no meio do semestre?",
      "sim",
      "não",
    ];

    const extracted = extractRelevantSubjectQuery(userMessages, "Dúvida de Matrícula");
    expect(extracted).toBe("Como trancar matéria no meio do semestre?");
    expect(isFollowUpOfferInLastMessage(baseFollowUpMessage)).toBe(true);
  });
});
