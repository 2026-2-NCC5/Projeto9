import { describe, it, expect } from "vitest";
import { classifySubject, categoryForLabel, SUBJECT_LABELS } from "./subjectClassifier";

describe("subjectClassifier", () => {
  it("classifica declaração de matrícula como documentos, não financeiro", () => {
    const r = classifySubject("Como posso solicitar uma declaração de matrícula?");
    expect(r.label).toBe(SUBJECT_LABELS.documentos);
    expect(r.category).toBe("documentos");
    expect(r.label).not.toBe("Negociação ou Questão Financeira");
  });

  it("reconhece histórico escolar e comprovantes", () => {
    expect(classifySubject("Preciso do meu histórico escolar").category).toBe("documentos");
    expect(classifySubject("Quero um comprovante").category).toBe("documentos");
  });

  it("classifica boleto como financeiro", () => {
    expect(classifySubject("Como emitir segunda via do boleto?").category).toBe("financeiro");
  });

  it("trancamento vai para matrícula/requerimento", () => {
    expect(classifySubject("Quero trancar a matrícula").label).toBe(SUBJECT_LABELS.matricula);
  });

  it("sem correspondência retorna outro", () => {
    const r = classifySubject("xyz");
    expect(r.matched).toBe(false);
    expect(r.category).toBe("outro");
  });

  it("categoryForLabel mapeia rótulos", () => {
    expect(categoryForLabel(SUBJECT_LABELS.documentos)).toBe("documentos");
    expect(categoryForLabel(SUBJECT_LABELS.calendario)).toBe("academico");
  });
});
