/**
 * Serviço de Download Real de Documentos PDF de Demonstração (SecretarIA / FECAP Guia).
 *
 * Responsabilidades:
 * 1. Realizar requisição HTTP real para `GET /api/v1/documents/download/{docName}`.
 * 2. Validar status HTTP (tratando 401/403 como erro de autenticação, 404 como arquivo inexistente
 *    e falhas de rede sem exibir falso sucesso).
 * 3. Verificar se o `Content-Type` retornado é `application/pdf` e se o blob possui assinatura `%PDF-`.
 * 4. Extrair o nome de arquivo do header `Content-Disposition` (quando presente) e disparar
 *    o download real no navegador (Edge / Chrome / Firefox).
 */

export interface PdfDownloadResult {
  ok: boolean;
  filename: string;
  sizeBytes: number;
  status: number;
  errorMessage?: string;
}

export function extractFilenameFromContentDisposition(
  contentDisposition: string | null,
  fallbackFilename: string
): string {
  if (!contentDisposition) {
    return fallbackFilename;
  }
  const match = contentDisposition.match(/filename\*?=(?:UTF-8'')?["']?([^"';]+)["']?/i);
  if (match && match[1]) {
    return match[1].trim();
  }
  return fallbackFilename;
}

export function buildPdfDownloadUrl(docTitle: string, baseUrl: string = "/api/v1"): string {
  const cleaned = (docTitle || "").trim();
  const encoded = encodeURIComponent(cleaned);
  return `${baseUrl.replace(/\/$/, "")}/documents/download/${encoded}`;
}

export async function downloadDemoPdfDocument(
  docTitle: string,
  options?: {
    accessToken?: string | null;
    baseUrl?: string;
    absoluteUrl?: string;
    fetchImpl?: typeof fetch;
    triggerBrowserDownload?: (blob: Blob, filename: string) => void;
  }
): Promise<PdfDownloadResult> {
  const cleanTitle = (docTitle || "").trim();
  if (!cleanTitle) {
    return {
      ok: false,
      filename: "",
      sizeBytes: 0,
      status: 400,
      errorMessage: "Nome de documento inválido para download.",
    };
  }

  const fetchFn = options?.fetchImpl || fetch;
  const url = options?.absoluteUrl || buildPdfDownloadUrl(cleanTitle, options?.baseUrl || "/api/v1");

  const headers: Record<string, string> = {
    Accept: "application/pdf",
  };
  if (options?.accessToken) {
    headers["Authorization"] = `Bearer ${options.accessToken}`;
  }

  let response: Response;
  try {
    response = await fetchFn(url, {
      method: "GET",
      headers,
    });
  } catch {
    return {
      ok: false,
      filename: cleanTitle,
      sizeBytes: 0,
      status: 0,
      errorMessage:
        "Falha de conexão com o servidor ao baixar o PDF. Verifique se o backend está ativo.",
    };
  }

  if (!response.ok) {
    let detail = "";
    try {
      const errJson = await response.json();
      detail = errJson?.detail || "";
    } catch {
      // ignora erro de parse JSON
    }

    if (response.status === 401 || response.status === 403) {
      return {
        ok: false,
        filename: cleanTitle,
        sizeBytes: 0,
        status: response.status,
        errorMessage:
          detail || "Sessão expirada ou sem permissão para baixar este documento. Faça login novamente.",
      };
    }

    if (response.status === 404) {
      return {
        ok: false,
        filename: cleanTitle,
        sizeBytes: 0,
        status: 404,
        errorMessage:
          detail || `O documento "${cleanTitle}" não foi encontrado no servidor.`,
      };
    }

    return {
      ok: false,
      filename: cleanTitle,
      sizeBytes: 0,
      status: response.status,
      errorMessage:
        detail || `Erro ao gerar o documento PDF (HTTP ${response.status}).`,
    };
  }

  const contentType = (response.headers.get("content-type") || "").toLowerCase();
  if (!contentType.includes("application/pdf")) {
    return {
      ok: false,
      filename: cleanTitle,
      sizeBytes: 0,
      status: response.status,
      errorMessage: "O servidor não retornou um arquivo PDF válido (Content-Type inesperado).",
    };
  }

  const arrayBuffer = await response.arrayBuffer();
  const bytes = new Uint8Array(arrayBuffer);

  // Verifica assinatura mágica "%PDF-" nos primeiros 5 bytes
  const headerStr = String.fromCharCode(...bytes.slice(0, 5));
  if (bytes.byteLength < 64 || headerStr !== "%PDF-") {
    return {
      ok: false,
      filename: cleanTitle,
      sizeBytes: bytes.byteLength,
      status: response.status,
      errorMessage: "O arquivo recebido está corrompido ou não possui cabeçalho PDF válido.",
    };
  }

  const resolvedFilename = extractFilenameFromContentDisposition(
    response.headers.get("content-disposition"),
    cleanTitle.toLowerCase().endsWith(".pdf") ? cleanTitle : `${cleanTitle}.pdf`
  );

  const pdfBlob = new Blob([arrayBuffer], { type: "application/pdf" });

  if (options?.triggerBrowserDownload) {
    options.triggerBrowserDownload(pdfBlob, resolvedFilename);
  } else if (typeof window !== "undefined" && typeof document !== "undefined") {
    const blobUrl = URL.createObjectURL(pdfBlob);
    const link = document.createElement("a");
    link.href = blobUrl;
    link.download = resolvedFilename;
    link.rel = "noopener";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);
  }

  return {
    ok: true,
    filename: resolvedFilename,
    sizeBytes: bytes.byteLength,
    status: response.status,
  };
}

/** Baixa um PDF autenticado de um caminho arbitrário da API (ex.: segunda via de boleto). */
export function downloadFromPath(
  url: string,
  fallbackName: string,
  options?: Parameters<typeof downloadDemoPdfDocument>[1]
): Promise<PdfDownloadResult> {
  return downloadDemoPdfDocument(fallbackName, { ...options, absoluteUrl: url });
}
