/**
 * Classificador de assunto para encaminhamento ao atendimento humano.
 * Baseado em palavras-chave da pergunta real do estudante (sem categoria fixa).
 */

export type SubjectCategory = "documentos" | "financeiro" | "academico" | "portal" | "outro";

export interface SubjectClassification {
  label: string;
  category: SubjectCategory;
  matched: boolean;
}

export const SUBJECT_LABELS = {
  documentos: "Solicitação de Documentos Acadêmicos",
  financeiro: "Negociação ou Questão Financeira",
  matricula: "Dúvida de Matrícula ou Requerimento",
  aproveitamento: "Aproveitamento de Disciplinas e Transferência",
  calendario: "Dúvida sobre Calendário ou Provas",
  portal: "Acesso ao Portal do Aluno",
  outro: "Outro assunto específico",
} as const;

function normalize(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

// Ordem importa: documentos antes de matrícula (ex.: "declaração de matrícula").
const RULES: Array<{ re: RegExp; label: string; category: SubjectCategory }> = [
  {
    re: /declaracao|historico escolar|historico|comprovante de matricula|comprovante|atestado|certidao|diploma|ementa|segunda via de documento|documento academico|documentos/,
    label: SUBJECT_LABELS.documentos,
    category: "documentos",
  },
  {
    re: /boleto|mensalidade|financeir|negociac|pagamento|parcela|desconto|bolsa|inadimpl|2a via|segunda via do boleto/,
    label: SUBJECT_LABELS.financeiro,
    category: "financeiro",
  },
  {
    re: /aproveitamento|equivalencia|transferencia|dispensa de disciplina/,
    label: SUBJECT_LABELS.aproveitamento,
    category: "academico",
  },
  {
    re: /calendario|prova|exame|prazo|data de/,
    label: SUBJECT_LABELS.calendario,
    category: "academico",
  },
  {
    re: /portal|senha|login|acesso|primeiro acesso/,
    label: SUBJECT_LABELS.portal,
    category: "portal",
  },
  {
    re: /matricula|rematricula|trancamento|trancar|requerimento|cancelamento/,
    label: SUBJECT_LABELS.matricula,
    category: "academico",
  },
];

export function classifySubject(text: string): SubjectClassification {
  const norm = normalize(text || "");
  for (const rule of RULES) {
    if (rule.re.test(norm)) {
      return { label: rule.label, category: rule.category, matched: true };
    }
  }
  return { label: SUBJECT_LABELS.outro, category: "outro", matched: false };
}

export function categoryForLabel(label: string): SubjectCategory {
  switch (label) {
    case SUBJECT_LABELS.documentos:
      return "documentos";
    case SUBJECT_LABELS.financeiro:
      return "financeiro";
    case SUBJECT_LABELS.portal:
      return "portal";
    case SUBJECT_LABELS.outro:
      return "outro";
    default:
      return "academico";
  }
}
