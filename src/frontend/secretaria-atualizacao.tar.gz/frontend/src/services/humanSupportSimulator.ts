/**
 * Lógica de Atendimento Humano Simulado (SecretarIA / FECAP Guia).
 *
 * Responsabilidades:
 * 1. Interpretar respostas curtas ("sim", "não", "obrigada", "encerrar", etc.)
 *    considerando o contexto da conversa (ex.: após oferta de ajuda adicional).
 * 2. Nunca afirmar que documentos, solicitações ou processos foram realmente
 *    validados pela FECAP ou Secretaria Geral sem integração institucional comprovada.
 * 3. Identificar claramente o orientador como SIMULADO quando DEMO_MODE estiver ativo.
 * 4. Evitar respostas genéricas repetitivas que ecoem cegamente a mensagem do aluno.
 * 5. Vincular o protocolo à conversa e ao assunto corretos.
 */

export type ShortIntent =
  | "close_or_decline_more_help"
  | "accept_more_help"
  | "gratitude_only"
  | "explicit_close"
  | "content_message";

export interface SimulatedHumanContext {
  studentName?: string;
  userText: string;
  lastHumanMessageText?: string;
  protocol: string;
  subject: string;
  conversationId: string;
  demoMode?: boolean;
  turnCount?: number;
}

export interface SimulatedHumanReplyResult {
  replyText: string;
  agentName: string;
  intent: ShortIntent;
  shouldOfferClose: boolean;
  shouldAutoPromptSurvey: boolean;
  protocol: string;
  subject: string;
  conversationId: string;
}

const NORMALIZE_REGEX = /[\u0300-\u036f]/g;
const PUNCT_REGEX = /[.,!?;:()[\]"']/g;

export function normalizeText(input: string): string {
  return (input || "")
    .normalize("NFD")
    .replace(NORMALIZE_REGEX, "")
    .replace(PUNCT_REGEX, " ")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

const NEGATIVE_SHORT_PATTERNS = new Set([
  "nao",
  "n",
  "nn",
  "nao obrigado",
  "nao obrigada",
  "nao preciso",
  "nao precisa",
  "so isso",
  "era so isso",
  "apenas isso",
  "mais nada",
  "nada mais",
  "nao so isso",
  "nao era so isso",
  "por enquanto nao",
  "nao por enquanto",
  "tudo certo",
  "tudo bem",
  "ja resolveu",
  "resolvido",
  "sem mais duvidas",
  "nenhuma duvida",
  "nenhuma",
]);

const EXPLICIT_CLOSE_PATTERNS = new Set([
  "encerrar",
  "encerrar atendimento",
  "finalizar",
  "finalizar atendimento",
  "concluir",
  "concluir atendimento",
  "pode encerrar",
  "pode finalizar",
  "quero encerrar",
  "fechar atendimento",
  "sair do atendimento",
]);

const AFFIRMATIVE_SHORT_PATTERNS = new Set([
  "sim",
  "s",
  "ss",
  "quero",
  "preciso",
  "sim por favor",
  "sim obrigada",
  "sim obrigado",
  "claro",
  "com certeza",
  "tenho outra duvida",
  "tenho mais uma duvida",
  "mais uma duvida",
  "outra duvida",
  "sim tenho",
  "preciso de ajuda",
  "ainda tenho duvida",
]);

const GRATITUDE_SHORT_PATTERNS = new Set([
  "obrigada",
  "obrigado",
  "muito obrigada",
  "muito obrigado",
  "valeu",
  "agradecida",
  "agradecido",
  "grata",
  "grato",
  "ok obrigada",
  "ok obrigado",
  "perfeito obrigada",
  "perfeito obrigado",
  "entendi obrigada",
  "entendi obrigado",
  "ok",
  "certo",
  "entendi",
  "perfeito",
]);

/**
 * Verifica se a última mensagem do orientador continha uma oferta de apoio adicional
 * ou pergunta de fechamento (ex.: "Precisa de mais algum apoio neste atendimento?").
 */
export function isFollowUpOfferInLastMessage(lastHumanMessageText?: string): boolean {
  if (!lastHumanMessageText) return false;
  const norm = normalizeText(lastHumanMessageText);
  return (
    norm.includes("precisa de mais algum apoio") ||
    norm.includes("posso ajudar em mais alguma") ||
    norm.includes("mais alguma duvida") ||
    norm.includes("alguma outra duvida") ||
    norm.includes("deseja tratar de outro assunto") ||
    norm.includes("posso apoiar em algo mais")
  );
}

/**
 * Classifica a intenção de respostas curtas considerando o contexto da conversa.
 */
export function classifyUserIntent(
  userText: string,
  lastHumanMessageText?: string
): ShortIntent {
  const norm = normalizeText(userText);
  if (!norm) return "content_message";

  if (EXPLICIT_CLOSE_PATTERNS.has(norm)) {
    return "explicit_close";
  }

  // Frases curtas com "pode encerrar" / "nao obrigado"
  if (
    norm.startsWith("nao ") &&
    (norm.includes("obrigad") ||
      norm.includes("precis") ||
      norm.includes("encerrar") ||
      norm.includes("finalizar") ||
      norm.includes("so isso") ||
      norm.includes("tudo certo"))
  ) {
    return "close_or_decline_more_help";
  }

  if (NEGATIVE_SHORT_PATTERNS.has(norm)) {
    return "close_or_decline_more_help";
  }

  if (AFFIRMATIVE_SHORT_PATTERNS.has(norm)) {
    return "accept_more_help";
  }

  if (GRATITUDE_SHORT_PATTERNS.has(norm)) {
    // Se houve oferta de ajuda adicional e o aluno respondeu apenas "obrigada", trata como agradecimento / pré-encerramento
    return isFollowUpOfferInLastMessage(lastHumanMessageText)
      ? "close_or_decline_more_help"
      : "gratitude_only";
  }

  return "content_message";
}

/**
 * Retorna o nome de exibição do orientador, identificando claramente como SIMULADO quando DEMO_MODE estiver ativo.
 */
export function getSimulatedAttendantName(demoMode: boolean = true): string {
  return demoMode
    ? "Orientador Carlos (SIMULADO — Modo Demonstração) — Secretaria Acadêmica (ASA/FECAP)"
    : "Orientador Carlos — Secretaria Acadêmica (ASA/FECAP)";
}

/**
 * Extrai a última dúvida substantiva do estudante no histórico para vincular ao protocolo,
 * ignorando respostas curtas como "sim", "não", "obrigada", "encerrar".
 */
export function extractRelevantSubjectQuery(
  userMessages: string[],
  fallbackReason: string
): string {
  for (let i = userMessages.length - 1; i >= 0; i--) {
    const candidate = (userMessages[i] || "").trim();
    if (!candidate) continue;
    const intent = classifyUserIntent(candidate);
    if (intent === "content_message" && candidate.length > 4) {
      return candidate;
    }
  }
  return fallbackReason || "Orientações gerais sobre procedimentos acadêmicos";
}

/**
 * Gera a resposta contextualizada do Orientador Simulado sem afirmar validações reais na FECAP.
 */
export function buildSimulatedHumanReply(
  ctx: SimulatedHumanContext
): SimulatedHumanReplyResult {
  const studentName = ctx.studentName || "Ana";
  const demoMode = ctx.demoMode !== undefined ? ctx.demoMode : true;
  const protocol = ctx.protocol || "#PROTOCOLO-2026-0000";
  const subject = ctx.subject || "Orientação Acadêmica";
  const conversationId = ctx.conversationId || "conv-local";
  const turnCount = ctx.turnCount || 0;

  const agentName = getSimulatedAttendantName(demoMode);
  const intent = classifyUserIntent(ctx.userText, ctx.lastHumanMessageText);
  const lower = normalizeText(ctx.userText);

  // 1. Estudante respondeu "não" à oferta de ajuda adicional ou pediu para encerrar
  if (intent === "close_or_decline_more_help" || intent === "explicit_close") {
    const demoNotice = demoMode
      ? " (Atendimento humano SIMULADO para fins de demonstração acadêmica)."
      : "";
    const replyText =
      `Perfeito, ${studentName}! Como não há outras dúvidas no momento, podemos concluir este atendimento referente a "${subject}" (Protocolo ${protocol}).${demoNotice}\n\n` +
      `Para finalizar e reativar o Assistente Virtual de IA (SecretarIA), clique no botão "Encerrar Atendimento" logo acima ou avalie o atendimento na janela que foi aberta.`;

    return {
      replyText,
      agentName,
      intent,
      shouldOfferClose: true,
      shouldAutoPromptSurvey: intent === "explicit_close" || isFollowUpOfferInLastMessage(ctx.lastHumanMessageText),
      protocol,
      subject,
      conversationId,
    };
  }

  // 2. Estudante respondeu "sim" à oferta de apoio adicional
  if (intent === "accept_more_help") {
    const replyText =
      `Claro, ${studentName}! Continuo à disposição neste atendimento simulado sob o protocolo ${protocol} (Assunto: "${subject}").\n\n` +
      `Por favor, descreva qual é a sua próxima dúvida ou qual procedimento acadêmico você gostaria de consultar.`;

    return {
      replyText,
      agentName,
      intent,
      shouldOfferClose: false,
      shouldAutoPromptSurvey: false,
      protocol,
      subject,
      conversationId,
    };
  }

  // 3. Estudante enviou agradecimento curto ("obrigada", "ok", "entendi")
  if (intent === "gratitude_only") {
    const replyText =
      `Disponha, ${studentName}! Fico feliz em ajudar com as orientações sobre "${subject}" (Protocolo ${protocol}).\n\n` +
      `Precisa de mais algum apoio neste atendimento simulado ou deseja encerrar para retornar ao Assistente de IA?`;

    return {
      replyText,
      agentName,
      intent,
      shouldOfferClose: true,
      shouldAutoPromptSurvey: false,
      protocol,
      subject,
      conversationId,
    };
  }

  // 4. Mensagens com conteúdo específico (sem afirmar que processos/documentos reais foram validados pela FECAP)
  let replyText = "";

  if (
    lower.includes("boleto") ||
    lower.includes("pagamento") ||
    lower.includes("mensalidade") ||
    lower.includes("pix") ||
    lower.includes("financeiro")
  ) {
    replyText =
      `${studentName}, para questões de boletos, mensalidades ou acordos financeiros (Protocolo ${protocol}), a orientação é acessar o Portal do Aluno > Menu Financeiro > Boletos e Mensalidades.\n\n` +
      `Nota de transparência: como este é um atendimento humano SIMULADO (Modo Demonstração), nenhuma baixa financeira, isenção ou envio de boleto real foi efetuado nos sistemas institucionais da FECAP. Precisa de mais algum apoio neste atendimento?`;
  } else if (
    lower.includes("trancar") ||
    lower.includes("trancamento") ||
    lower.includes("cancelar") ||
    lower.includes("suspensao")
  ) {
    replyText =
      `${studentName}, sobre o trancamento de matrícula vinculado ao protocolo ${protocol}: o procedimento oficial prevê a abertura de requerimento no Portal do Aluno > Requerimentos > Solicitação de Trancamento dentro do prazo do Calendário Acadêmico.\n\n` +
      `Nota de transparência: este atendimento é SIMULADO (Modo Demonstração) e não realiza o protocolo nem a validação real do trancamento na Secretaria Geral da FECAP. Precisa de mais algum apoio neste atendimento?`;
  } else if (
    lower.includes("historico") ||
    lower.includes("declaracao") ||
    lower.includes("comprovante") ||
    lower.includes("atestado") ||
    lower.includes("documento")
  ) {
    replyText =
      `${studentName}, para emissão de Declaração de Matrícula ou Histórico Escolar (Protocolo ${protocol}), utilize o autoatendimento no Portal do Aluno > Menu Documentos.\n\n` +
      `Nota de transparência: este é um orientador SIMULADO (Modo Demonstração); nenhum documento oficial foi emitido ou autenticado junto à Secretaria Acadêmica real da FECAP. Precisa de mais algum apoio neste atendimento?`;
  } else if (
    lower.includes("aproveitamento") ||
    lower.includes("equivalencia") ||
    lower.includes("dispensa") ||
    lower.includes("transferencia")
  ) {
    replyText =
      `${studentName}, para solicitação de aproveitamento de estudos/equivalência (Protocolo ${protocol}), é necessário anexar o Histórico Escolar e as ementas detalhadas no Portal do Aluno > Requerimentos.\n\n` +
      `Nota de transparência: por se tratar de ambiente SIMULADO de demonstração, a análise curricular não foi submetida à coordenação real da FECAP. Posso ajudar em mais alguma dúvida?`;
  } else {
    // Variações contextuais não-repetitivas e sem afirmar validação institucional real
    const contextualTemplates = [
      `${studentName}, registrei sua dúvida no atendimento simulado do protocolo ${protocol} (Assunto: "${subject}"). Para efetivar solicitações oficiais, utilize sempre o Portal do Aluno > Requerimentos ou os canais oficiais da Secretaria Acadêmica (ASA/FECAP), pois este ambiente de demonstração não executa validações nos sistemas internos da instituição. Precisa de mais algum apoio neste atendimento?`,
      `${studentName}, compreendi seu questionamento referente a "${subject}" sob o protocolo ${protocol}. Lembramos que este orientador opera em modo SIMULADO (Demonstração Acadêmica) e não valida documentos ou processos reais na Secretaria Geral da FECAP. Você gostaria de revisar o passo a passo de algum requerimento ou deseja encerrar o atendimento?`,
      `${studentName}, suas observações foram anotadas no histórico simulado do protocolo ${protocol}. Caso precise formalizar o pedido junto à FECAP, recomendamos protocolar diretamente no Portal do Aluno. Posso apoiar em algo mais neste atendimento ou podemos finalizar?`,
    ];
    replyText = contextualTemplates[turnCount % contextualTemplates.length];
  }

  return {
    replyText,
    agentName,
    intent: "content_message",
    shouldOfferClose: false,
    shouldAutoPromptSurvey: false,
    protocol,
    subject,
    conversationId,
  };
}
