import { describe, expect, it, vi } from "vitest";
import {
  buildPdfDownloadUrl,
  downloadDemoPdfDocument,
  extractFilenameFromContentDisposition,
} from "./pdfDownloadService";

function createSampleValidPdfBytes(): Uint8Array {
  const sample =
    "%PDF-1.4\n" +
    "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n" +
    "DOCUMENTO FICTICIO - DEMONSTRACAO ACADEMICA - SEM VALIDADE OFICIAL\n" +
    "%%EOF\n";
  return new TextEncoder().encode(sample);
}

describe("pdfDownloadService — Download Real e Verificação de PDFs no Frontend", () => {
  it("1. Extrai corretamente o filename do header Content-Disposition", () => {
    const disp = 'attachment; filename="Comprovante_Matricula_2026_1_FECAP.pdf"';
    expect(extractFilenameFromContentDisposition(disp, "fallback.pdf")).toBe(
      "Comprovante_Matricula_2026_1_FECAP.pdf"
    );
    expect(extractFilenameFromContentDisposition(null, "fallback.pdf")).toBe("fallback.pdf");
  });

  it("2. Baixa um PDF válido somente quando status=200, Content-Type=application/pdf e cabeçalho %PDF-", async () => {
    const validBytes = createSampleValidPdfBytes();
    const mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      headers: {
        get: (name: string) => {
          if (name.toLowerCase() === "content-type") return "application/pdf";
          if (name.toLowerCase() === "content-disposition") {
            return 'attachment; filename="Comprovante_Matricula_2026_1_FECAP.pdf"';
          }
          return null;
        },
      },
      arrayBuffer: async () => validBytes.buffer,
    } as unknown as Response);

    const triggered: Array<{ filename: string; size: number; type: string }> = [];

    const result = await downloadDemoPdfDocument("Comprovante_Matricula_2026_1_FECAP.pdf", {
      fetchImpl: mockFetch,
      triggerBrowserDownload: (blob, filename) => {
        triggered.push({ filename, size: blob.size, type: blob.type });
      },
    });

    expect(result.ok).toBe(true);
    expect(result.status).toBe(200);
    expect(result.filename).toBe("Comprovante_Matricula_2026_1_FECAP.pdf");
    expect(result.sizeBytes).toBeGreaterThan(64);
    expect(triggered).toHaveLength(1);
    expect(triggered[0].type).toBe("application/pdf");
  });

  it("3. Trata erro de autenticação (401/403) sem disparar download nem falso sucesso", async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: false,
      status: 401,
      json: async () => ({ detail: "Token de acesso invalido ou expirado." }),
    } as unknown as Response);

    const triggerSpy = vi.fn();
    const result = await downloadDemoPdfDocument("Comprovante_Matricula_2026_1_FECAP.pdf", {
      accessToken: "expired_token",
      fetchImpl: mockFetch,
      triggerBrowserDownload: triggerSpy,
    });

    expect(result.ok).toBe(false);
    expect(result.status).toBe(401);
    expect(result.errorMessage).toContain("Token de acesso invalido");
    expect(triggerSpy).not.toHaveBeenCalled();
  });

  it("4. Trata arquivo inexistente (404) sem exibir sucesso falso", async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: false,
      status: 404,
      json: async () => ({ detail: "Documento PDF não encontrado." }),
    } as unknown as Response);

    const triggerSpy = vi.fn();
    const result = await downloadDemoPdfDocument("Inexistente.pdf", {
      fetchImpl: mockFetch,
      triggerBrowserDownload: triggerSpy,
    });

    expect(result.ok).toBe(false);
    expect(result.status).toBe(404);
    expect(result.errorMessage).toContain("não encontrado");
    expect(triggerSpy).not.toHaveBeenCalled();
  });

  it("5. Trata falha de rede (fetch rejeitado) e Content-Type incorreto", async () => {
    const networkFailFetch = vi.fn().mockRejectedValue(new Error("Network Error"));
    const triggerSpy = vi.fn();

    const netResult = await downloadDemoPdfDocument("Boleto_Mensalidade_Marco_2026.pdf", {
      fetchImpl: networkFailFetch,
      triggerBrowserDownload: triggerSpy,
    });

    expect(netResult.ok).toBe(false);
    expect(netResult.status).toBe(0);
    expect(netResult.errorMessage).toContain("Falha de conexão");
    expect(triggerSpy).not.toHaveBeenCalled();

    // Caso o servidor retorne text/html (ex.: SPA fallback) em vez de application/pdf
    const htmlFallbackFetch = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      headers: {
        get: (name: string) => (name.toLowerCase() === "content-type" ? "text/html" : null),
      },
      arrayBuffer: async () => new TextEncoder().encode("<html></html>").buffer,
    } as unknown as Response);

    const htmlResult = await downloadDemoPdfDocument("Boleto_Mensalidade_Marco_2026.pdf", {
      fetchImpl: htmlFallbackFetch,
      triggerBrowserDownload: triggerSpy,
    });

    expect(htmlResult.ok).toBe(false);
    expect(htmlResult.errorMessage).toContain("Content-Type inesperado");
    expect(triggerSpy).not.toHaveBeenCalled();
    expect(buildPdfDownloadUrl("Boleto_Mensalidade_Marco_2026.pdf")).toBe(
      "/api/v1/documents/download/Boleto_Mensalidade_Marco_2026.pdf"
    );
  });
});
