/**
 * Instancia Axios configurada para o FECAP Guia.
 * Inclui interceptors de autenticacao e renovacao de token.
 */
import axios from "axios";

/**
 * Define a URL base da API:
 * - Se VITE_API_URL for informada e não for "/" nem vazia, usa o valor configurado.
 * - Se VITE_API_URL for vazia ou "/", usa caminho relativo "" (roteado via proxy reverso /api/v1).
 * - Caso não definida em desenvolvimento local fora de proxy, usa "" se estiver em domínio público
 *   ou http://localhost:8000 apenas como fallback em ambiente de testes Node/Vitest.
 */
function resolveApiBaseUrl(): string {
  const envUrl = import.meta.env.VITE_API_URL;
  if (typeof envUrl === "string") {
    const trimmed = envUrl.trim();
    if (trimmed === "" || trimmed === "/") {
      return "";
    }
    return trimmed.replace(/\/$/, "");
  }
  if (typeof window !== "undefined" && window.location && window.location.origin) {
    // No navegador (local via Nginx 5173 ou produção Azure via 80/443), usa caminho relativo /api/v1
    return "";
  }
  return "http://localhost:8000";
}

const BASE_URL = resolveApiBaseUrl();

export const api = axios.create({
  baseURL: `${BASE_URL}/api/v1`,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 30000,
});

// Interceptor de request: adiciona token JWT
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("access_token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Interceptor de response: trata 401 e renova token se refresh_token existir
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // Evitar loop infinito no endpoint de login/refresh
    if (
      error.response?.status === 401 &&
      !originalRequest._retry &&
      !originalRequest.url?.includes("/auth/")
    ) {
      originalRequest._retry = true;
      const refreshToken = localStorage.getItem("refresh_token");

      if (refreshToken) {
        try {
          const res = await axios.post(`${BASE_URL}/api/v1/auth/refresh`, {
            refresh_token: refreshToken,
          });
          const { access_token, refresh_token: newRefresh } = res.data;
          localStorage.setItem("access_token", access_token);
          if (newRefresh) {
            localStorage.setItem("refresh_token", newRefresh);
          }
          originalRequest.headers.Authorization = `Bearer ${access_token}`;
          return api(originalRequest);
        } catch (refreshErr) {
          localStorage.removeItem("access_token");
          localStorage.removeItem("refresh_token");
          if (window.location.pathname !== "/login" && window.location.pathname !== "/admin/login") {
            window.location.href = "/login";
          }
          return Promise.reject(refreshErr);
        }
      } else {
        localStorage.removeItem("access_token");
        if (window.location.pathname !== "/login" && window.location.pathname !== "/admin/login") {
          window.location.href = "/login";
        }
      }
    }
    return Promise.reject(error);
  }
);

export default api;
