import { describe, it, expect } from "vitest";
import { detectBoletoIntent, formatBRL, sumSelected, competenceMonth } from "./boletoIntent";

describe("boletoIntent", () => {
  it.each([
    "Quais boletos estão pendentes?",
    "Quero minha segunda via de boleto.",
    "Tenho mensalidades em aberto?",
    "Como emitir segunda via de boleto?",
  ])("reconhece: %s", (q) => {
    expect(detectBoletoIntent(q).matched).toBe(true);
  });

  it("extrai o mês citado", () => {
    expect(detectBoletoIntent("Quero emitir o boleto de setembro.")).toEqual({ matched: true, month: 9 });
  });

  it("não confunde outras perguntas", () => {
    expect(detectBoletoIntent("Como solicitar declaração de matrícula?").matched).toBe(false);
  });

  it("calcula total selecionado e formata BRL", () => {
    const list = [
      { id: "a", amount_cents: 85000 },
      { id: "b", amount_cents: 85000 },
      { id: "c", amount_cents: 92050 },
    ];
    expect(sumSelected(list, new Set(["a", "c"]))).toBe(177050);
    expect(sumSelected(list, new Set())).toBe(0);
    expect(formatBRL(85000)).toBe("R$ 850,00");
    expect(competenceMonth("2026-09")).toBe(9);
  });
});
