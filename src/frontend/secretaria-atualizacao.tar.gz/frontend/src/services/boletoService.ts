/**
 * Cliente da API de segunda via de boleto (dados FICTÍCIOS). O estudante é sempre
 * derivado do JWT no backend; nenhum ID de estudante é enviado.
 */
import { api } from "./api";
import { downloadFromPath } from "./pdfDownloadService";

export interface BoletoItem {
  id: string;
  competence: string;
  competence_label: string;
  due_date: string;
  amount_cents: number;
  amount_label: string;
  status: "pendente" | "vencido" | "pago";
  status_label: string;
  document_id: string;
}

export interface PendingBoletos {
  boletos: BoletoItem[];
  count: number;
  total_cents: number;
  disclaimer: string;
}

export function describeBoletoError(err: unknown): string {
  const e = err as { response?: { status?: number; data?: { detail?: string } } };
  const s = e?.response?.status;
  if (s === 401) return "Sua sessão expirou ou você não está autenticado. Faça login para consultar seus boletos.";
  if (s === 403) return "Seu perfil não possui acesso a boletos de estudante.";
  if (s === 404) return "Boleto não encontrado para sua conta.";
  if (!s) return "Falha de conexão com o servidor. Tente novamente.";
  return e?.response?.data?.detail || `Erro inesperado (HTTP ${s}).`;
}

export async function fetchPendingBoletos(): Promise<PendingBoletos> {
  const res = await api.get<PendingBoletos>("/boletos/pending");
  return res.data;
}

export async function issueSecondCopies(ids: string[]) {
  const res = await api.post<{
    documents: Array<{ id: string; filename: string; download_url: string; competence_label: string }>;
  }>("/boletos/issue", { boleto_ids: ids });
  return res.data.documents;
}

export async function downloadBoletoPdf(boletoId: string) {
  return downloadFromPath(`/api/v1/boletos/${encodeURIComponent(boletoId)}/pdf`, `${boletoId}.pdf`, {
    accessToken: typeof localStorage !== "undefined" ? localStorage.getItem("access_token") : null,
  });
}

export async function simulatePayment(boletoId: string): Promise<string> {
  const res = await api.post<{ message: string }>(`/boletos/${encodeURIComponent(boletoId)}/simulate-payment`, {
    confirm: true,
  });
  return res.data.message;
}
