/**
 * Detecção de intenção "segunda via de boleto" e utilitários puros (sem rede).
 */

export interface BoletoIntent {
  matched: boolean;
  /** Número do mês (1-12) citado na pergunta, se houver. */
  month?: number;
}

const MONTHS = [
  "janeiro", "fevereiro", "marco", "abril", "maio", "junho",
  "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
];

function normalize(text: string): string {
  return (text || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

export function detectBoletoIntent(text: string): BoletoIntent {
  const t = normalize(text);
  const mentionsBoleto = /boleto/.test(t);
  const mentionsDebt = /(mensalidade|parcela)s?.*(aberto|pendente|atraso|atrasad|vencid)|(aberto|pendente|atraso|vencid).*(mensalidade|parcela)|em aberto/.test(t);
  const matched = mentionsBoleto || mentionsDebt;
  if (!matched) return { matched: false };
  const idx = MONTHS.findIndex((m) => new RegExp(`\\b${m}\\b`).test(t));
  return idx >= 0 ? { matched: true, month: idx + 1 } : { matched: true };
}

export function competenceMonth(competence: string): number {
  return Number(competence.split("-")[1]);
}

export function formatBRL(cents: number): string {
  const reais = Math.floor(cents / 100);
  const c = String(cents % 100).padStart(2, "0");
  return `R$ ${reais.toLocaleString("pt-BR")},${c}`;
}

export function sumSelected(
  boletos: Array<{ id: string; amount_cents: number }>,
  selected: Set<string>
): number {
  return boletos.reduce((acc, b) => (selected.has(b.id) ? acc + b.amount_cents : acc), 0);
}
