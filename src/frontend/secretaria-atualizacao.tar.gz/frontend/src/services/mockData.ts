/**
 * Dados de mock para o Frontend FECAP Guia
 * Dados de teste com formato realista
 */

import type { StudentProfile, KnowledgeDocument, HistoryItem, DashboardMetrics, AuditLog, AgentResponse } from "@/types";

export const MOCK_STUDENT: StudentProfile = {
  id: "std-202612345",
  name: "Ana Silva",
  ra: "202612345",
  course: "Administração",
  period: "3º Semestre",
  email: "ana.silva@exemplo.com",
};

export const MOCK_DOCUMENTS: KnowledgeDocument[] = [
  {
    id: "doc-1",
    title: "Como Acessar o Portal do Aluno",
    category: "portal_sistemas",
    origin: "Secretaria Acadêmica",
    version: "1.0",
    status: "active",
    published_at: "2024-01-15",
    updated_at: "2024-06-10",
    created_by: "Secretaria",
  },
  {
    id: "doc-2",
    title: "Solicitação de Documentos Acadêmicos",
    category: "documentos_certidoes",
    origin: "Secretaria Acadêmica",
    version: "1.0",
    status: "active",
    published_at: "2024-01-15",
    updated_at: "2024-06-10",
    created_by: "Secretaria",
  },
  {
    id: "doc-3",
    title: "Declaração de Matrícula — Procedimento",
    category: "documentos_certidoes",
    origin: "Secretaria Acadêmica",
    version: "1.0",
    status: "active",
    published_at: "2024-01-15",
    updated_at: "2024-06-10",
    created_by: "Secretaria",
  },
  {
    id: "doc-4",
    title: "Atendimento Acadêmico e Canais de Suporte",
    category: "atendimento_suporte",
    origin: "Central de Atendimento",
    version: "1.0",
    status: "active",
    published_at: "2024-01-15",
    updated_at: "2024-06-10",
    created_by: "Atendimento",
  },
  {
    id: "doc-5",
    title: "Procedimentos de Estágio e Convênios",
    category: "estagios",
    origin: "Setor de Carreiras",
    version: "1.0",
    status: "active",
    published_at: "2024-02-01",
    updated_at: "2024-06-01",
    created_by: "Carreiras",
  },
];

export const MOCK_AGENT_RESPONSES: Record<string, AgentResponse> = {
  matricula: {
    id: "run-101",
    answer: "A Declaração de Matrícula pode ser solicitada diretamente pelo Portal do Aluno em formato digital.",
    steps: [
      "Acesse o Portal do Aluno com seu RA e senha cadastrados.",
      "Navegue no menu principal em: Documentos > Declaração de Matrícula.",
      "Selecione o semestre letivo corrente.",
      "Clique em 'Emitir Declaração' para gerar o documento em PDF.",
      "Faça o download do arquivo para utilização."
    ],
    next_action: "Acesse a seção de Documentos no Portal do Aluno para efetuar a emissão imediata.",
    source: "Secretaria Acadêmica — Guia de Procedimentos",
    requires_human: false,
  },
  portal: {
    id: "run-102",
    answer: "Para acessar o Portal do Aluno, utilize seu Registro Acadêmico (RA) e a senha cadastrada.",
    steps: [
      "Acesse o endereço oficial do Portal do Aluno.",
      "No campo de usuário, digite seu RA de estudante.",
      "Digite sua senha pessoal de acesso.",
      "Caso seja o primeiro acesso, clique em 'Primeiro Acesso' para cadastrar sua senha.",
      "Em caso de esquecimento, utilize a opção 'Esqueci minha senha' para redefinição."
    ],
    next_action: "Em caso de instabilidade técnica ou bloqueio, entre em contato com o suporte de TI.",
    source: "Central de Atendimento — Manuais do Sistema",
    requires_human: false,
  },
  canais: {
    id: "run-103",
    answer: "O atendimento acadêmico está disponível tanto em canais digitais quanto de forma presencial.",
    steps: [
      "Portal do Aluno: aba 'Atendimento / Solicitações' disponível 24 horas.",
      "Secretaria Acadêmica: atendimento presencial e via chamado no portal.",
      "Coordenação de Curso: atendimento presencial mediante agendamento prévio.",
      "Central Financeira: consultas e solicitações pelo portal ou presencialmente."
    ],
    next_action: "Utilize o canal digital no portal para registrar sua solicitação com protocolo de acompanhamento.",
    source: "Secretaria Acadêmica — Guia de Atendimento",
    requires_human: false,
  },
  segunda_via: {
    id: "run-104",
    answer: "A solicitação de segunda via de documentos acadêmicos pode ser protocolada via Portal do Aluno ou na Secretaria.",
    steps: [
      "Acesse o Portal do Aluno na seção 'Documentos'.",
      "Selecione o tipo de documento desejado (Histórico, Carteirinha, etc.).",
      "Informe o motivo do pedido e confirme o requerimento.",
      "Documentos digitais possuem emissão gratuita pelo portal.",
      "Para vias impressas oficiais, consulte os prazos e orientações da Secretaria."
    ],
    next_action: "Verifique na seção de Documentos se o documento desejado aceita emissão digital instantânea.",
    source: "Secretaria Acadêmica — Guia de Documentos",
    requires_human: false,
  },
  notas: {
    id: "run-105",
    answer: "A consulta de notas e frequência das disciplinas cursadas é realizada na área acadêmica do portal.",
    steps: [
      "Acesse o Portal do Aluno com seus dados de login.",
      "No menu principal, selecione 'Acadêmico' > 'Notas e Frequência'.",
      "Selecione a disciplina desejada para ver o detalhamento de avaliações.",
      "Caso identifique divergência nas avaliações, contate o professor responsável ou a Coordenação."
    ],
    next_action: "Consulte o calendário acadêmico para verificar o período de divulgação oficial de notas.",
    source: "Secretaria Acadêmica — Guia do Aluno",
    requires_human: false,
  },
  calendario: {
    id: "run-106",
    answer: "O Calendário Acadêmico traz as datas oficiais de início e término de aulas, avaliações, feriados e rematrícula.",
    steps: [
      "Acesse o Portal do Aluno ou o site da instituição.",
      "Navegue em 'Acadêmico' > 'Calendário Acadêmico'.",
      "Faça o download do PDF oficial do semestre vigente."
    ],
    next_action: "Mantenha atenção aos prazos de trancamento e rematrícula indicados no calendário.",
    source: "Secretaria Acadêmica — Calendário Institucional",
    requires_human: false,
  },
  financeiro: {
    id: "run-107",
    answer: "Dúvidas sobre mensalidades, boletos, bolsas e negociação devem ser tratadas junto à Central Financeira.",
    steps: [
      "Acesse o Portal do Aluno na seção 'Financeiro'.",
      "Consulte seus boletos e histórico de pagamentos.",
      "Para solicitar negociação ou tirar dúvidas sobre acordos, abra um atendimento financeiro no portal."
    ],
    next_action: "Para casos específicos de bolsas ou financiamento, agende um atendimento na Central Financeira.",
    source: "Central Financeira — Guia de Serviços",
    requires_human: false,
  },
  biblioteca: {
    id: "run-108",
    answer: "A Biblioteca oferece acervo físico e digital para consulta e empréstimos de livros e artigos.",
    steps: [
      "Acesse o sistema da Biblioteca pelo Portal do Aluno.",
      "Pesquise obras no acervo online ou acesse a biblioteca digital.",
      "Para renovação de empréstimos físicos, acesse 'Meus Empréstimos' antes da data de vencimento."
    ],
    next_action: "Consulte os horários de funcionamento presencial da Biblioteca no portal.",
    source: "Biblioteca Institucional — Regulamento",
    requires_human: false,
  },
  estagio: {
    id: "run-109",
    answer: "Para validação de Termo de Compromisso de Estágio (TCE), o documento deve ser submetido ao Setor de Carreiras.",
    steps: [
      "Acesse a área de 'Estágios e Carreiras' no portal.",
      "Anexe o Termo de Compromisso assinado pela concedente e pelo estudante.",
      "Aguarde a análise e assinatura da instituição (prazo de até 5 dias úteis).",
      "Após aprovação, faça o download do documento assinado."
    ],
    next_action: "Submeta o termo com antecedência em relação ao início das atividades de estágio.",
    source: "Setor de Carreiras — Manual de Estágios",
    requires_human: false,
  },
  fallback: {
    id: "run-999",
    answer: "Não encontrei informação oficial suficiente na base de conhecimento para responder a esta solicitação específica com total precisão.",
    steps: [
      "Recomendo encaminhar sua solicitação para a equipe de Atendimento Humano.",
      "Nossa equipe da Secretaria analisará seu caso individualmente."
    ],
    next_action: "Clique no botão abaixo para encaminhar sua solicitação diretamente ao atendimento presencial ou online.",
    source: "Central de Orientação Acadêmica",
    requires_human: true,
  },
};

export const MOCK_HISTORY: HistoryItem[] = [
  {
    id: "hist-1",
    question: "Como solicitar declaração de matrícula?",
    answer: "A Declaração de Matrícula pode ser solicitada diretamente pelo Portal do Aluno em formato digital.",
    requires_human: false,
    created_at: "2026-09-05T14:30:00Z",
    feedback: "positive",
  },
  {
    id: "hist-2",
    question: "Qual o procedimento para aproveitamento de disciplinas de outra faculdade?",
    answer: "Não encontrei informação oficial suficiente na base de conhecimento para responder a esta solicitação específica.",
    requires_human: true,
    created_at: "2026-09-04T10:15:00Z",
    handoff_protocol: "PROT-2026-4829",
  },
];

export const MOCK_DASHBOARD: DashboardMetrics = {
  total_questions: 142,
  total_answers: 128,
  answers_with_evidence_rate: 90.1,
  positive_feedback_rate: 94.5,
  handoffs_count: 14,
  unanswered_count: 5,
  avg_response_time_ms: 1250,
  top_categories: [
    { category: "Documentos e Certidões", count: 58 },
    { category: "Portal e Sistemas", count: 42 },
    { category: "Atendimento e Suporte", count: 24 },
    { category: "Procedimentos Acadêmicos", count: 18 },
  ],
  questions_per_day: [
    { date: "01/09", count: 18 },
    { date: "02/09", count: 24 },
    { date: "03/09", count: 30 },
    { date: "04/09", count: 22 },
    { date: "05/09", count: 28 },
    { date: "06/09", count: 20 },
  ],
};

export const MOCK_AUDIT_LOGS: AuditLog[] = [
  {
    id: "audit-1",
    user_id: "std-202612345",
    action: "AGENT_QUERY",
    resource: "/api/agent/query",
    detail: "Consulta efetuada: Como solicitar declaração de matrícula?",
    created_at: "2026-09-05T14:30:00Z",
  },
  {
    id: "audit-2",
    user_id: "std-202612345",
    action: "FEEDBACK_SUBMIT",
    resource: "/api/feedback",
    detail: "Avaliação: POSITIVE | Orientação aprovada",
    created_at: "2026-09-05T14:31:00Z",
  },
  {
    id: "audit-3",
    user_id: "adm-1001",
    action: "DOCUMENT_UPDATE",
    resource: "/api/knowledge/doc-1",
    detail: "Atualização de procedimento: 'Como Acessar o Portal do Aluno'",
    created_at: "2026-09-04T09:00:00Z",
  },
];