"""
Pipeline RAG — Agente 3: Orientacao ao Estudante (FECAP Guia)

Fluxo:
  1. Validar a pergunta.
  2. Consultar o ChromaDB (Top-K configuravel).
  3. Filtrar evidencias relevantes (score >= agent_min_evidence_score).
  4. Calcular confianca composta (mediana dos scores + bonus de cobertura).
  5. Se confianca >= agent_confidence_threshold:
     a. Modo "gemini": chamar o Gemini com prompt contendo os chunks.
     b. Modo "demo":   construir resposta estruturada apenas com chunks.
  6. Se confianca insuficiente: abstencao responsavel com requires_human=True.

Garantias:
  - Nenhum fato inventado: resposta construida apenas com conteudo recuperado.
  - Limiar 0.4 e parametro inicial sujeito a calibracao (config.py).
  - Logs estruturados de cada etapa do pipeline.
  - Documentos marcados como demo sao identificados na resposta.
"""
from __future__ import annotations

import re
import statistics
import unicodedata
import uuid
from datetime import datetime, timezone
from typing import List, Optional

from app.core.config import settings
from app.core.logging import get_logger
from app.knowledge.vector_store import VectorStoreService
from app.schemas.schemas import AgentEvidence, AgentQuery, AgentResponse

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Utilitario para respostas curtas / conversacionais (sim, nao, obrigada, etc.)
# ---------------------------------------------------------------------------
_NEGATIVE_CLOSE_UTTERANCES = {
    "nao",
    "n",
    "nao preciso",
    "nao quero",
    "nao obrigada",
    "nao obrigado",
    "so isso",
    "era so isso",
    "mais nada",
    "nada mais",
}

_AFFIRMATIVE_UTTERANCES = {
    "sim",
    "s",
    "claro",
    "quero",
    "preciso",
    "por favor",
    "pode ser",
    "sim por favor",
    "tenho outra duvida",
    "outra duvida",
}

_THANKS_UTTERANCES = {
    "obrigada",
    "obrigado",
    "muito obrigada",
    "muito obrigado",
    "valeu",
    "agradecida",
    "agradecido",
    "grata",
    "grato",
    "ok obrigada",
    "ok obrigado",
    "tudo certo obrigada",
    "tudo certo obrigado",
}

_CLOSE_UTTERANCES = {
    "encerrar",
    "finalizar",
    "fechar",
    "concluir",
    "pode encerrar",
    "quero encerrar",
    "encerrar atendimento",
    "finalizar atendimento",
    "tchau",
    "ate logo",
}


def _normalize_short_text(raw: str) -> str:
    txt = unicodedata.normalize("NFD", (raw or "").strip().lower())
    txt = "".join(ch for ch in txt if unicodedata.category(ch) != "Mn")
    txt = re.sub(r"[!?.:;,\-\"'()\[\]]+", " ", txt)
    return re.sub(r"\s+", " ", txt).strip()


def _detect_conversational_reply(question: str) -> Optional[AgentResponse]:
    """
    Se a entrada do estudante for uma resposta curta conversacional ("nao", "sim",
    "obrigada", "encerrar"), retorna uma resposta contextual imediata sem consultar
    o ChromaDB e sem afirmar qualquer validacao institucional.
    """
    norm = _normalize_short_text(question)
    if not norm or len(norm.split()) > 5:
        return None

    run_id = str(uuid.uuid4())
    now_iso = datetime.now(timezone.utc).isoformat()

    if norm in _NEGATIVE_CLOSE_UTTERANCES or norm in _CLOSE_UTTERANCES:
        return AgentResponse(
            id=run_id,
            answer=(
                "Perfeito! Entendi que você não precisa de apoio adicional neste momento e deseja encerrar.\n\n"
                "Seu atendimento pode ser finalizado com segurança. Caso surja uma nova dúvida acadêmica sobre "
                "matrícula, histórico, boletos ou requerimentos, basta digitar sua pergunta aqui no chat.\n\n"
                "---\n"
                "_Nota: orientação em modo de demonstração acadêmica. Nenhum documento ou solicitação foi validado "
                "automaticamente junto à FECAP._"
            ),
            steps=[
                "contexto_conversacional: resposta curta de encerramento/negativa detectada",
                "acao: encerramento cordial sem consulta vetorial desnecessaria",
            ],
            next_action="close",
            source="agent",
            version=settings.agent_version,
            updated_at=now_iso,
            evidence=[],
            confidence=1.0,
            requires_human=False,
        )

    if norm in _THANKS_UTTERANCES:
        return AgentResponse(
            id=run_id,
            answer=(
                "Por nada! Fico à disposição para auxiliar com orientações baseadas nos manuais acadêmicos.\n\n"
                "Se precisar consultar outro procedimento, basta enviar sua dúvida, ou finalize o atendimento quando desejar.\n\n"
                "---\n"
                "_Nota: orientação em modo de demonstração acadêmica (sem validação institucional real)._"
            ),
            steps=[
                "contexto_conversacional: agradecimento detectado",
                "acao: resposta de cortesia e disponibilidade",
            ],
            next_action="none",
            source="agent",
            version=settings.agent_version,
            updated_at=now_iso,
            evidence=[],
            confidence=1.0,
            requires_human=False,
        )

    if norm in _AFFIRMATIVE_UTTERANCES:
        return AgentResponse(
            id=run_id,
            answer=(
                "Claro! Por favor, descreva qual é a sua dúvida ou procedimento acadêmico que deseja consultar "
                "(por exemplo: *Como emitir histórico escolar?*, *Como trancar disciplina?* ou *Segunda via de boleto*).\n\n"
                "---\n"
                "_Nota: orientação em modo de demonstração acadêmica._"
            ),
            steps=[
                "contexto_conversacional: confirmacao curta ('sim') detectada",
                "acao: solicitacao do tema especifico ao estudante",
            ],
            next_action="none",
            source="agent",
            version=settings.agent_version,
            updated_at=now_iso,
            evidence=[],
            confidence=1.0,
            requires_human=False,
        )

    return None

# ---------------------------------------------------------------------------
# Constantes de prompt
# ---------------------------------------------------------------------------
_SYSTEM_PROMPT = """\
Voce e o Agente de Orientacao ao Estudante da FECAP.
Responda SOMENTE com base nos trechos de documentos fornecidos abaixo.
Nao invente procedimentos, prazos, links ou valores.
Se os trechos nao forem suficientes para responder, diga que nao encontrou
informacao oficial e sugira atendimento humano.
Os documentos sao ficticio/demonstracao — informe isso ao estudante.
Responda em portugues claro e objetivo.
"""

_DEMO_DISCLAIMER = (
    "\n\n---\n"
    "_Nota: as orientacoes acima sao baseadas em conteudo de demonstracao "
    "(nao representam normas oficiais verificadas da FECAP). "
    "Confirme as informacoes com a Secretaria Academica._"
)

_ABSTENTION_DISCLAIMER = (
    "\n\n---\n"
    "_Nota: nenhuma informacao suficiente foi encontrada na base de "
    "demonstracao. Encaminhe sua duvida ao atendimento humano._"
)


# ---------------------------------------------------------------------------
# Funcoes auxiliares
# ---------------------------------------------------------------------------

def _build_context_block(evidence: List[AgentEvidence]) -> str:
    """Constroi bloco de contexto a partir das evidencias selecionadas."""
    lines: List[str] = []
    for i, ev in enumerate(evidence, 1):
        lines.append(f"[{i}] Documento: {ev.document}")
        lines.append(ev.chunk)
        lines.append("")
    return "\n".join(lines)


def _compute_confidence(scores: List[float]) -> float:
    """
    Confianca composta = mediana dos scores de similaridade.
    Usar mediana (em vez de media) e mais robusto contra outliers como o
    caso FAQ/senha que retornou score alto para uma query nao relacionada.
    """
    if not scores:
        return 0.0
    med = statistics.median(scores)
    # Bonus leve pelo numero de evidencias convergentes (max +0.05)
    coverage_bonus = min(0.05, len(scores) * 0.01)
    return round(min(1.0, med + coverage_bonus), 4)


def _filter_evidence(raw_results: List[dict]) -> List[AgentEvidence]:
    """
    Converte resultados brutos do ChromaDB em AgentEvidence,
    descartando chunks abaixo do limiar minimo.
    """
    threshold = settings.agent_min_evidence_score
    evidence: List[AgentEvidence] = []
    for r in raw_results:
        score = r.get("similarity_score", 0.0)
        if score < threshold:
            continue
        meta = r.get("metadata", {})
        doc_label = meta.get("title", meta.get("document_id", "Desconhecido"))
        evidence.append(
            AgentEvidence(
                chunk=r["text"],
                document=doc_label,
                relevance_score=round(score, 4),
            )
        )
    return evidence


# ---------------------------------------------------------------------------
# Integracao Gemini
# ---------------------------------------------------------------------------

def _call_gemini(question: str, context_block: str) -> str:
    """
    Chama a API Gemini usando o SDK google-genai.
    Retorna o texto gerado ou lanca RuntimeError em caso de falha.
    Esta funcao e substituida por mock nos testes unitarios.
    """
    from google import genai  # type: ignore

    client = genai.Client(api_key=settings.google_api_key)
    prompt = (
        f"{_SYSTEM_PROMPT}\n\n"
        f"Trechos de referencia:\n{context_block}\n\n"
        f"Pergunta do estudante: {question}"
    )
    response = client.models.generate_content(
        model=settings.gemini_model,
        contents=prompt,
    )
    return response.text


# ---------------------------------------------------------------------------
# Construtor de resposta demo
# ---------------------------------------------------------------------------

_STOPWORDS = {
    "como", "posso", "para", "uma", "umas", "uns", "que", "qual", "quais", "onde",
    "quando", "por", "com", "dos", "das", "nos", "nas", "meu", "minha", "sobre",
    "preciso", "quero", "fazer", "solicitar", "solicito", "pode", "ser", "tem",
}


def _keywords(text: str) -> set:
    norm = unicodedata.normalize("NFKD", text.lower())
    norm = "".join(c for c in norm if not unicodedata.combining(c))
    return {w for w in re.findall(r"[a-z0-9]{4,}", norm) if w not in _STOPWORDS}


def _clean_line(line: str) -> str:
    line = re.sub(r"\s*\(DEMONSTRACAO[^)]*\)", "", line, flags=re.I)
    return line.rstrip()


def _extract_relevant_excerpt(question: str, chunk: str, max_chars: int = 700) -> str:
    """Seleciona do chunk apenas as linhas relevantes (com contexto), sem alterar o texto."""
    kws = _keywords(question)
    raw = [l for l in chunk.splitlines()]
    keep = set()
    for idx, l in enumerate(raw):
        if kws & _keywords(l):
            for j in range(max(0, idx - 1), min(len(raw), idx + 5)):
                keep.add(j)
    selected = [raw[j] for j in sorted(keep)] if keep else raw
    cleaned = [
        _clean_line(l) for l in selected
        if l.strip() and not re.fullmatch(r"[=\-\s]+", l)
    ]
    text = "\n".join(cleaned).strip()
    if len(text) > max_chars:
        text = text[:max_chars].rstrip() + "..."
    return text


def _build_demo_answer(question: str, evidence: List[AgentEvidence]) -> str:
    """
    Constroi uma resposta apenas a partir dos trechos relevantes recuperados,
    sem chamar nenhuma LLM externa. Nenhum fato inventado.
    """
    lines: List[str] = [
        "Encontrei as seguintes orientacoes na documentacao disponivel "
        "(base de demonstracao):\n"
    ]
    seen_docs = set()
    n = 0
    for ev in evidence:
        if ev.document in seen_docs:
            continue
        excerpt = _extract_relevant_excerpt(question, ev.chunk)
        if not excerpt:
            continue
        seen_docs.add(ev.document)
        n += 1
        lines.append(f"**{ev.document}**\n{excerpt}\n")
        if n >= 3:
            break

    lines.append(
        "Se a documentacao acima nao resolver sua duvida, posso encaminhar "
        "voce para atendimento humano (simulado nesta demonstracao)."
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Pipeline principal
# ---------------------------------------------------------------------------

class RAGPipeline:
    """
    Pipeline RAG para o Agente de Orientacao ao Estudante.

    Parametros lidos de app.core.config.settings:
      - agent_top_k_documents    : numero de chunks recuperados do ChromaDB
      - agent_min_evidence_score : score minimo para incluir um chunk
      - agent_confidence_threshold: confianca minima para gerar resposta
      - llm_mode                 : "demo" | "gemini"
    """

    def __init__(self, vector_store: Optional[VectorStoreService] = None):
        self._vs = vector_store  # injecao para facilitar testes

    @property
    def vector_store(self) -> VectorStoreService:
        if self._vs is None:
            self._vs = VectorStoreService()
        return self._vs

    # ------------------------------------------------------------------
    def run(self, query: AgentQuery) -> AgentResponse:
        """
        Executa o pipeline RAG de forma sincrona.
        FastAPI chama este metodo num executor de thread (run_in_executor)
        a partir do endpoint async — ver agent.py.
        """
        run_id = str(uuid.uuid4())
        question = (query.question or "").strip()

        logger.info(
            "RAG pipeline iniciado",
            run_id=run_id,
            student_id=query.student_id,
            question_len=len(question),
        )

        # --- Etapa 1: validar pergunta ----------------------------------
        if not question:
            logger.warning("Pergunta vazia recebida", run_id=run_id)
            return AgentResponse(
                id=run_id,
                answer="Por favor, envie uma pergunta valida.",
                steps=["validacao: pergunta vazia"],
                next_action="retry",
                source="agent",
                version=settings.agent_version,
                updated_at=datetime.now(timezone.utc).isoformat(),
                evidence=[],
                confidence=0.0,
                requires_human=False,
            )

        # --- Etapa 1b: verificar se e resposta curta conversacional -----
        short_reply = _detect_conversational_reply(question)
        if short_reply is not None:
            logger.info(
                "Resposta curta conversacional tratada diretamente",
                run_id=run_id,
                next_action=short_reply.next_action,
            )
            return short_reply

        # --- Etapa 2: recuperar chunks do ChromaDB ----------------------
        top_k = settings.agent_top_k_documents
        raw_results = self.vector_store.query_similar(question, top_k=top_k)

        logger.info(
            "Chunks recuperados",
            run_id=run_id,
            total_raw=len(raw_results),
            top_k=top_k,
        )

        # --- Etapa 3: filtrar evidencias relevantes ---------------------
        evidence = _filter_evidence(raw_results)
        scores = [ev.relevance_score for ev in evidence if ev.relevance_score is not None]

        logger.info(
            "Evidencias apos filtro",
            run_id=run_id,
            evidence_count=len(evidence),
            min_score=settings.agent_min_evidence_score,
        )

        # --- Etapa 4: calcular confianca composta -----------------------
        confidence = _compute_confidence(scores)

        logger.info(
            "Confianca calculada",
            run_id=run_id,
            confidence=confidence,
            threshold=settings.agent_confidence_threshold,
        )

        # --- Etapa 5: abstencao responsavel ----------------------------
        if confidence < settings.agent_confidence_threshold or not evidence:
            logger.info(
                "Abstencao ativada — confianca insuficiente",
                run_id=run_id,
                confidence=confidence,
            )
            return AgentResponse(
                id=run_id,
                answer=settings.agent_fallback_message + _ABSTENTION_DISCLAIMER,
                steps=[
                    "recuperacao: " + str(len(raw_results)) + " chunks",
                    "filtragem: " + str(len(evidence)) + " evidencias validas",
                    "confianca: " + str(confidence) + " < limiar " + str(settings.agent_confidence_threshold),
                    "abstencao: encaminhamento humano recomendado",
                ],
                next_action="handoff",
                source="agent",
                version=settings.agent_version,
                updated_at=datetime.now(timezone.utc).isoformat(),
                evidence=evidence,
                confidence=confidence,
                requires_human=True,
            )

        # --- Etapa 6a/6b: gerar resposta --------------------------------
        context_block = _build_context_block(evidence)
        mode = settings.llm_mode.lower()
        steps: List[str] = [
            "recuperacao: " + str(len(raw_results)) + " chunks",
            "filtragem: " + str(len(evidence)) + " evidencias validas",
            "confianca: " + str(confidence),
            "modo: " + mode,
        ]

        try:
            if mode == "gemini" and settings.google_api_key:
                answer = _call_gemini(question, context_block)
                steps.append("geracao: Gemini " + settings.gemini_model)
            else:
                answer = _build_demo_answer(question, evidence)
                steps.append("geracao: modo demo (sem LLM externo)")

            answer += _DEMO_DISCLAIMER

        except Exception as exc:  # pylint: disable=broad-except
            logger.error(
                "Erro na geracao de resposta — fallback para demo",
                run_id=run_id,
                error=str(exc),
            )
            answer = _build_demo_answer(question, evidence) + _DEMO_DISCLAIMER
            steps.append("geracao: fallback para demo apos erro Gemini")

        logger.info("RAG pipeline concluido", run_id=run_id)

        return AgentResponse(
            id=run_id,
            answer=answer,
            steps=steps,
            next_action="none",
            source="rag_pipeline",
            version=settings.agent_version,
            updated_at=datetime.now(timezone.utc).isoformat(),
            evidence=evidence,
            confidence=confidence,
            requires_human=False,
        )
