﻿"""
Gerenciador do ChromaDB e embeddings com all-MiniLM-L6-v2.
Garante colecao persistente, IDs deterministicos, busca semantica Top-K e cálculo de similaridade por cosseno.
"""
import os
from typing import List, Dict, Any, Optional
import chromadb
from chromadb.config import Settings as ChromaSettings
from sentence_transformers import SentenceTransformer

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

# Instancia singleton para evitar recarga pesada do modelo MiniLM em memoria
_embedding_model: Optional[SentenceTransformer] = None


def get_embedding_model() -> SentenceTransformer:
    global _embedding_model
    if _embedding_model is None:
        logger.info(
            "Carregando modelo de embeddings",
            model=settings.embedding_model,
            device=settings.embedding_device,
        )
        _embedding_model = SentenceTransformer(
            settings.embedding_model,
            device=settings.embedding_device
        )
    return _embedding_model


class VectorStoreService:
    def __init__(
        self,
        persist_directory: Optional[str] = None,
        collection_name: Optional[str] = None,
    ):
        self.persist_directory = persist_directory or settings.chroma_persist_directory
        self.collection_name = collection_name or settings.chroma_collection_name
        
        # Garantir diretorio absoluto ou relativo correto
        os.makedirs(self.persist_directory, exist_ok=True)
        
        self.client = chromadb.PersistentClient(
            path=self.persist_directory,
            settings=ChromaSettings(anonymized_telemetry=False)
        )
        
        # Colecao configurada com metrica de distancia por cosseno
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine", "description": "FECAP Guia Base de Conhecimento"}
        )

    def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """Gera vetores normalizados para os textos fornecidos."""
        model = get_embedding_model()
        embeddings = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
        return embeddings.tolist()

    def upsert_chunks(self, chunks: List[Dict[str, Any]]) -> int:
        """
        Insere ou atualiza fragmentos na colecao persistente com IDs deterministicos.
        Evita duplicacao de dados em caso de reindexacao.
        """
        if not chunks:
            return 0

        ids = [c["id"] for c in chunks]
        documents = [c["text"] for c in chunks]
        metadatas = [c["metadata"] for c in chunks]
        embeddings = self.embed_texts(documents)

        self.collection.upsert(
            ids=ids,
            documents=documents,
            metadatas=metadatas,
            embeddings=embeddings,
        )
        return len(chunks)

    def delete_document_chunks(self, document_id: str) -> int:
        """
        Remove todos os fragmentos associados a um documento especifico.
        Utilizado quando um documento e excluido ou desativado.
        ChromaDB suporta exclusao direta via filtro where.
        """
        doc_id_str = str(document_id)
        existing = self.collection.get(
            where={"document_id": doc_id_str}
        )
        ids_to_delete = existing.get("ids", [])
        if ids_to_delete:
            self.collection.delete(ids=ids_to_delete)
            return len(ids_to_delete)
        return 0

    def query_similar(
        self,
        query: str,
        top_k: int = 5,
        status_filter: str = "active",
    ) -> List[Dict[str, Any]]:
        """
        Executa busca semantica no ChromaDB.
        Diferencia distancia por cosseno de score de similaridade:
        similaridade = 1.0 - distancia_cosseno (com vetores normalizados).
        """
        if not query or not query.strip():
            return []

        query_embedding = self.embed_texts([query])
        
        where_filter = {"status": status_filter} if status_filter else None

        results = self.collection.query(
            query_embeddings=query_embedding,
            n_results=top_k,
            where=where_filter,
            include=["documents", "metadatas", "distances"],
        )

        formatted_results = []
        if results and results.get("ids") and results["ids"][0]:
            for idx in range(len(results["ids"][0])):
                chunk_id = results["ids"][0][idx]
                doc_text = results["documents"][0][idx]
                meta = results["metadatas"][0][idx]
                distance = results["distances"][0][idx]

                # Similaridade de cosseno a partir da distancia (distancia varia tipicamente de 0 a 2)
                # Para distancia cosseno normalizada: similaridade = 1 - (dist / 2) ou 1 - dist
                similarity_score = max(0.0, 1.0 - distance)

                formatted_results.append({
                    "id": chunk_id,
                    "text": doc_text,
                    "metadata": meta,
                    "cosine_distance": round(float(distance), 4),
                    "similarity_score": round(float(similarity_score), 4),
                })

        return formatted_results

    def count(self) -> int:
        """Retorna o total de fragmentos armazenados na colecao."""
        return self.collection.count()

    def reset_collection(self) -> None:
        """Limpa a colecao persistente."""
        self.client.delete_collection(self.collection_name)
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            metadata={"hnsw:space": "cosine"}
        )
