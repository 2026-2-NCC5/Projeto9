﻿"""
Modulo knowledge do FECAP Guia.
Exporta utilitarios de chunking, vector store e indexador.
"""
from app.knowledge.chunker import split_text_into_chunks, prepare_document_chunks
from app.knowledge.vector_store import VectorStoreService, get_embedding_model
from app.knowledge.indexer import index_all_active_documents, sync_document_to_vector_store

__all__ = [
    "split_text_into_chunks",
    "prepare_document_chunks",
    "VectorStoreService",
    "get_embedding_model",
    "index_all_active_documents",
    "sync_document_to_vector_store",
]
