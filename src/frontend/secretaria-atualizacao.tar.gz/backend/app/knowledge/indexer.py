"""
Serviço de indexação e sincronização entre SQLite e ChromaDB.
Varre documentos ativos no SQLite, fragmenta, gera vetores e atualiza chunks_count.
"""
from typing import Dict, Any, List
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import AsyncSessionLocal
from app.core.config import settings
from app.models.entities import KnowledgeDocument
from app.knowledge.chunker import prepare_document_chunks
from app.knowledge.vector_store import VectorStoreService


async def index_all_active_documents(
    session: AsyncSession,
    vector_service: VectorStoreService = None,
) -> Dict[str, Any]:
    """
    Indexa todos os documentos marcados como 'active' no SQLite para o ChromaDB.
    Atualiza chunks_count de cada documento no SQLite.
    """
    if vector_service is None:
        vector_service = VectorStoreService()

    stmt = select(KnowledgeDocument).where(KnowledgeDocument.status == "active")
    result = await session.execute(stmt)
    active_docs = result.scalars().all()

    total_chunks_indexed = 0
    docs_processed = 0
    details = []

    for doc in active_docs:
        if not doc.content:
            continue

        chunks = prepare_document_chunks(
            doc_id=doc.id,
            title=doc.title,
            category=doc.category,
            origin=doc.origin,
            version=doc.version,
            status=doc.status,
            content=doc.content,
            chunk_size=settings.chunk_size,
            chunk_overlap=settings.chunk_overlap,
            is_demo=doc.is_demo,
        )

        # Upsert no ChromaDB (idempotente com IDs deterministicos)
        count = vector_service.upsert_chunks(chunks)
        doc.chunks_count = count
        total_chunks_indexed += count
        docs_processed += 1

        details.append({
            "title": doc.title,
            "category": doc.category,
            "chunks": count,
        })

    await session.commit()

    return {
        "status": "success",
        "documents_processed": docs_processed,
        "total_chunks_indexed": total_chunks_indexed,
        "collection_total": vector_service.count(),
        "details": details,
    }


async def sync_document_to_vector_store(
    doc_id: str,
    session: AsyncSession,
    vector_service: VectorStoreService = None,
) -> Dict[str, Any]:
    """
    Sincroniza um documento individual:
    - Se status == 'active': atualiza chunks e embeddings no ChromaDB.
    - Se status != 'active': remove os chunks do ChromaDB.
    """
    if vector_service is None:
        vector_service = VectorStoreService()

    stmt = select(KnowledgeDocument).where(KnowledgeDocument.id == doc_id)
    result = await session.execute(stmt)
    doc = result.scalar_one_or_none()

    if not doc:
        return {"status": "error", "message": "Documento não encontrado"}

    if doc.status == "active" and doc.content:
        # Remove chunks antigos antes do upsert caso o novo texto gere menos fragmentos
        vector_service.delete_document_chunks(doc.id)
        chunks = prepare_document_chunks(
            doc_id=doc.id,
            title=doc.title,
            category=doc.category,
            origin=doc.origin,
            version=doc.version,
            status=doc.status,
            content=doc.content,
            chunk_size=settings.chunk_size,
            chunk_overlap=settings.chunk_overlap,
            is_demo=doc.is_demo,
        )
        count = vector_service.upsert_chunks(chunks)
        doc.chunks_count = count
        await session.commit()
        return {"status": "synced", "chunks": count}
    else:
        removed = vector_service.delete_document_chunks(doc.id)
        doc.chunks_count = 0
        await session.commit()
        return {"status": "deindexed", "chunks_removed": removed}

