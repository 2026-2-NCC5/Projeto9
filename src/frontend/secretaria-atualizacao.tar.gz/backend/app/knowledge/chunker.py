﻿"""
Serviço de particionamento (chunking) de documentos para o FECAP Guia.
Implementa fatiamento de tamanho fixo com sobreposição e quebra em fronteiras naturais de parágrafo/sentença.
"""
from typing import List, Dict, Any


def split_text_into_chunks(
    text: str,
    chunk_size: int = 500,
    chunk_overlap: int = 50,
) -> List[str]:
    """
    Divide o texto em fragmentos (chunks) respeitando tamanho maximo e sobreposicao.
    Tenta quebrar em quebras de linha ou espacos para nao truncar palavras no meio.
    """
    if not text or not text.strip():
        return []

    cleaned_text = text.strip()
    if len(cleaned_text) <= chunk_size:
        return [cleaned_text]

    chunks = []
    start = 0
    text_len = len(cleaned_text)

    while start < text_len:
        end = min(start + chunk_size, text_len)
        
        # Se nao estamos no fim do texto, tentar recuar para a ultima quebra de linha ou espaco
        if end < text_len:
            last_break = cleaned_text.rfind("\n", start + chunk_overlap, end)
            if last_break == -1:
                last_break = cleaned_text.rfind(" ", start + chunk_overlap, end)
            
            if last_break != -1:
                end = last_break

        chunk = cleaned_text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        # Proximo inicio com sobreposicao
        if end >= text_len:
            break
        start = max(start + 1, end - chunk_overlap)

    return chunks


def prepare_document_chunks(
    doc_id: str,
    title: str,
    category: str,
    origin: str,
    version: str,
    status: str,
    content: str,
    chunk_size: int = 500,
    chunk_overlap: int = 50,
    is_demo: bool = True,
) -> List[Dict[str, Any]]:
    """
    Gera fragmentos enriquecidos com metadados e IDs deterministicos.
    O ID deterministico permite idempotencia completa e reindexacao sem duplicatas.
    """
    raw_chunks = split_text_into_chunks(content, chunk_size, chunk_overlap)
    prepared = []

    for idx, chunk_text in enumerate(raw_chunks):
        chunk_id = f"{doc_id}_chunk_{idx}"
        metadata = {
            "document_id": str(doc_id),
            "title": str(title),
            "category": str(category),
            "origin": str(origin),
            "version": str(version),
            "status": str(status),
            "chunk_index": int(idx),
            "total_chunks": int(len(raw_chunks)),
            "is_demo": bool(is_demo),
        }
        prepared.append({
            "id": chunk_id,
            "text": chunk_text,
            "metadata": metadata,
        })

    return prepared
